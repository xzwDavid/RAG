Therefore, the
        data schema is forced to be fully nullable, which might be different from the one user provided.</li>
      </ul>
    </td>
    <td>function <code>from_avro</code></td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td><code>datetimeRebaseMode</code></td>
    <td>(value of <code>spark.sql.avro.datetimeRebaseModeInRead</code> configuration)</td>
    <td>The <code>datetimeRebaseMode</code> option allows to specify the rebasing mode for the values of the <code>date</code>, <code>timestamp-micros</code>, <code>timestamp-millis</code> logical types from the Julian to Proleptic Gregorian calendar.<br>
      Currently supported modes are:
      <ul>
        <li><code>EXCEPTION</code>: fails in reads of ancient dates/timestamps that are ambiguous between the two calendars.</li>
        <li><code>CORRECTED</code>: loads dates/timestamps without rebasing.</li>
        <li><code>LEGACY</code>: performs rebasing of ancient dates/timestamps from the Julian to Proleptic Gregorian calendar.</li>
      </ul>
    </td>
    <td>read and function <code>from_avro</code></td>
    <td>3.2.0</td>
  </tr>
  <tr>
    <td><code>positionalFieldMatching</code></td>
    <td>false</td>
    <td>This can be used in tandem with the `avroSchema` option to adjust the behavior for matching the fields in the provided Avro schema with those in the SQL schema. By default, the matching will be performed using field names, ignoring their positions. If this option is set to "true", the matching will be based on the position of the fields.</td>
    <td>read and write</td>
    <td>3.2.0</td>
  </tr>
  <tr>
    <td><code>enableStableIdentifiersForUnionType</code></td>
    <td>false</td>
    <td>If it is set to true, Avro schema is deserialized into Spark SQL schema, and the Avro Union type is transformed into a structure where the field names remain consistent with their respective types. The resulting field names are converted to lowercase, e.g. member_int or member_string. If two user-defined type names or a user-defined type name and a built-in type name are identical regardless of case, an exception will be raised. However, in other cases, the field names can be uniquely identified.</td>
    <td>read</td>
    <td>3.5.0</td>
  </tr>
  <tr>
    <td><code>stableIdentifierPrefixForUnionType</code></td>
    <td>member_</td>
    <td>When `enableStableIdentifiersForUnionType` is enabled, the option allows to configure the prefix for fields of Avro Union type.</td>
    <td>read</td>
    <td>4.0.0</td>
  </tr>
  <tr>
    <td><code>recursiveFieldMaxDepth</code></td>
    <td>-1</td>
    <td>If this option is specified to negative or is set to 0, recursive fields are not permitted. Setting it to 1 drops all recursive fields, 2 allows recursive fields to be recursed once, and 3 allows it to be recursed twice and so on, up to 15. Values larger than 15 are not allowed in order to avoid inadvertently creating very large schemas. If an avro message has depth beyond this limit, the Spark struct returned is truncated after the recursion limit.