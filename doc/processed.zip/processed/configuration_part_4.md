</td>
  <td>3.0.0</td>
</tr>
<tr>
 <td><code>spark.driver.resource.{resourceName}.discoveryScript</code></td>
  <td>None</td>
  <td>
    A script for the driver to run to discover a particular resource type. This should
    write to STDOUT a JSON string in the format of the ResourceInformation class. This has a
    name and an array of addresses. For a client-submitted driver, discovery script must assign
    different resource addresses to this driver comparing to other drivers on the same host. </td>
  <td>3.0.0</td>
</tr>
<tr>
 <td><code>spark.driver.resource.{resourceName}.vendor</code></td>
  <td>None</td>
  <td>
    Vendor of the resources to use for the driver. This option is currently
    only supported on Kubernetes and is actually both the vendor and domain following
    the Kubernetes device plugin naming convention. (e.g. For GPUs on Kubernetes
    this config would be set to nvidia.com or amd.com)
  </td>
  <td>3.0.0</td>
</tr>
<tr>
 <td><code>spark.resources.discoveryPlugin</code></td>
  <td>org.apache.spark.resource.ResourceDiscoveryScriptPlugin</td>
  <td>
    Comma-separated list of class names implementing
    org.apache.spark.api.resource.ResourceDiscoveryPlugin to load into the application. This is for advanced users to replace the resource discovery class with a
    custom implementation. Spark will try each class specified until one of them
    returns the resource information for that resource. It tries the discovery
    script last if none of the plugins return information for that resource. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.memory</code></td>
  <td>1g</td>
  <td>
    Amount of memory to use per executor process, in the same format as JVM memory strings with
    a size unit suffix ("k", "m", "g" or "t") (e.g. <code>512m</code>, <code>2g</code>). </td>
  <td>0.7.0</td>
</tr>
<tr>
 <td><code>spark.executor.pyspark.memory</code></td>
  <td>Not set</td>
  <td>
    The amount of memory to be allocated to PySpark in each executor, in MiB
    unless otherwise specified. If set, PySpark memory for an executor will be
    limited to this amount. If not set, Spark will not limit Python's memory use
    and it is up to the application to avoid exceeding the overhead memory space
    shared with other non-JVM processes. When PySpark is run in YARN or Kubernetes, this memory
    is added to executor resource requests. <br/>
    <em>Note:</em> This feature is dependent on Python's <code>resource</code> module; therefore, the behaviors and
    limitations are inherited. For instance, Windows does not support resource limiting and actual
    resource is not limited on MacOS. </td>
  <td>2.4.0</td>
</tr>
<tr>
 <td><code>spark.executor.memoryOverhead</code></td>
  <td>executorMemory * <code>spark.executor.memoryOverheadFactor</code>, with minimum of <code>spark.executor.minMemoryOverhead</code></td>
  <td>
    Amount of additional memory to be allocated per executor process, in MiB unless otherwise specified. This is memory that accounts for things like VM overheads, interned strings, other native overheads, etc. This tends to grow with the executor size (typically 6-10%). This option is currently supported on YARN and Kubernetes.