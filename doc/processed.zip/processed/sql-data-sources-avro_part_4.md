Note that when using this option with
          <code>from_avro</code>, you still need to pass the actual Avro schema as a parameter to the function. </li>
        <li>
          When writing Avro, this option can be set if the expected output Avro schema doesn't match the
          schema converted by Spark. For example, the expected schema of one column is of "enum" type,
          instead of "string" type in the default converted schema. </li>
      </ul>
    </td>
    <td> read, write and function <code>from_avro</code></td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td><code>recordName</code></td>
    <td>topLevelRecord</td>
    <td>Top level record name in write result, which is required in Avro spec.</td>
    <td>write</td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td><code>recordNamespace</code></td>
    <td>""</td>
    <td>Record namespace in write result.</td>
    <td>write</td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td><code>ignoreExtension</code></td>
    <td>true</td>
    <td>The option controls ignoring of files without <code>.avro</code> extensions in read.<br> If the option is enabled, all files (with and without <code>.avro</code> extension) are loaded.<br> The option has been deprecated, and it will be removed in the future releases. Please use the general data source option <a href="./sql-data-sources-generic-options.html#path-glob-filter">pathGlobFilter</a> for filtering file names.</td>
    <td>read</td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td><code>compression</code></td>
    <td>snappy</td>
    <td>The <code>compression</code> option allows to specify a compression codec used in write.<br>
  Currently supported codecs are <code>uncompressed</code>, <code>snappy</code>, <code>deflate</code>, <code>bzip2</code>, <code>xz</code> and <code>zstandard</code>.<br> If the option is not set, the configuration <code>spark.sql.avro.compression.codec</code> config is taken into account.</td>
    <td>write</td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td><code>mode</code></td>
    <td>FAILFAST</td>
    <td>The <code>mode</code> option allows to specify parse mode for function <code>from_avro</code>.<br>
      Currently supported modes are:
      <ul>
        <li><code>FAILFAST</code>: Throws an exception on processing corrupted record.</li>
        <li><code>PERMISSIVE</code>: Corrupt records are processed as null result.