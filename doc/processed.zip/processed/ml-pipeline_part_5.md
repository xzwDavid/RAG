{% include_example scala/org/apache/spark/examples/ml/PipelineExample.scala %}
</div>

<div data-lang="java" markdown="1">


Refer to the [`Pipeline` Java docs](api/java/org/apache/spark/ml/Pipeline.html) for details on the API. {% include_example java/org/apache/spark/examples/ml/JavaPipelineExample.java %}
</div>

</div>

## Model selection (hyperparameter tuning)

A big benefit of using ML Pipelines is hyperparameter optimization. See the [ML Tuning Guide](ml-tuning.html) for more information on automatic model selection. 