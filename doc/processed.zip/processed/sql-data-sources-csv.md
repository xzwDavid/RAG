

Spark SQL provides `spark.read().csv("file_name")` to read a file or directory of files in CSV format into Spark DataFrame, and `dataframe.write().csv("path")` to write to a CSV file. Function `option()` can be used to customize the behavior of reading or writing, such as controlling behavior of the header, delimiter character, character set, and so on. <div class="codetabs">

<div data-lang="python"  markdown="1">
{% include_example csv_dataset python/sql/datasource.py %}
</div>

<div data-lang="scala"  markdown="1">
{% include_example csv_dataset scala/org/apache/spark/examples/sql/SQLDataSourceExample.scala %}
</div>

<div data-lang="java"  markdown="1">
{% include_example csv_dataset java/org/apache/spark/examples/sql/JavaSQLDataSourceExample.java %}
</div>

</div>

## Data Source Option

Data source options of CSV can be set via:
* the `.option`/`.options` methods of
  * `DataFrameReader`
  * `DataFrameWriter`
  * `DataStreamReader`
  * `DataStreamWriter`
* the built-in functions below
  * `from_csv`
  * `to_csv`
  * `schema_of_csv`
* `OPTIONS` clause at [CREATE TABLE USING DATA_SOURCE](sql-ref-syntax-ddl-create-table-datasource.html)


<table>
  <thead><tr><th><b>Property Name</b></th><th><b>Default</b></th><th><b>Meaning</b></th><th><b>Scope</b></th></tr></thead>
  <tr>
    <td><code>sep</code><br><code>delimiter</code></td>
    <td>,</td>
    <td>Sets a separator for each field and value. This separator can be one or more characters.</td>
    <td>read/write</td>
  </tr>
  <tr>
    <td><code>encoding</code><br><code>charset</code></td>
    <td>UTF-8</td>
    <td>For reading, decodes the CSV files by the given encoding type. For writing, specifies encoding (charset) of saved CSV files. CSV built-in functions ignore this option.</td>
    <td>read/write</td>
  </tr>
  <tr>
    <td><code>quote</code></td>
    <td>"</td>
    <td>Sets a single character used for escaping quoted values where the separator can be part of the value. For reading, if you would like to turn off quotations, you need to set not <code>null</code> but an empty string. For writing, if an empty string is set, it uses <code>u0000</code> (null character).</td>
    <td>read/write</td>
  </tr>
  <tr>
    <td><code>quoteAll</code></td>
    <td>false</td>
    <td>A flag indicating whether all values should always be enclosed in quotes. Default is to only escape values containing a quote character.</td>
    <td>write</td>
  </tr>
  <tr>
    <td><code>escape</code></td>
    <td>\</td>
    <td>Sets a single character used for escaping quotes inside an already quoted value.</td>
    <td>read/write</td>
  </tr>
  <tr>
    <td><code>escapeQuotes</code></td>
    <td>true</td>
    <td>A flag indicating whether values containing quotes should always be enclosed in quotes.