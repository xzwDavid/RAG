</td>
    <td>3.2.0</td>
  </tr>
  <tr>
    <td><code>spark.sql.orc.filterPushdown</code></td>
    <td><code>true</code></td>
    <td>
      When true, enable filter pushdown for ORC files. </td>
    <td>1.4.0</td>
  </tr>
  <tr>
    <td><code>spark.sql.orc.aggregatePushdown</code></td>
    <td><code>false</code></td>
    <td>
      If true, aggregates will be pushed down to ORC for optimization. Support MIN, MAX and
      COUNT as aggregate expression. For MIN/MAX, support boolean, integer, float and date
      type. For COUNT, support all data types. If statistics is missing from any ORC file
      footer, exception would be thrown. </td>
    <td>3.3.0</td>
  </tr>
  <tr>
  <td><code>spark.sql.orc.mergeSchema</code></td>
  <td>false</td>
  <td>
    <p>
      When true, the ORC data source merges schemas collected from all data files,
      otherwise the schema is picked from a random data file. </p>
  </td>
  <td>3.0.0</td>
  </tr>
  <tr>
  <td><code>spark.sql.hive.convertMetastoreOrc</code></td>
  <td>true</td>
  <td>
    When set to false, Spark SQL will use the Hive SerDe for ORC tables instead of the built in
    support. </td>
  <td>2.0.0</td>
  </tr>
</table>

## Data Source Option

Data source options of ORC can be set via:
* the `.option`/`.options` methods of
  * `DataFrameReader`
  * `DataFrameWriter`
  * `DataStreamReader`
  * `DataStreamWriter`
* `OPTIONS` clause at [CREATE TABLE USING DATA_SOURCE](sql-ref-syntax-ddl-create-table-datasource.html)

<table>
  <thead><tr><th><b>Property Name</b></th><th><b>Default</b></th><th><b>Meaning</b></th><th><b>Scope</b></th></tr></thead>
  <tr>
    <td><code>mergeSchema</code></td>
    <td><code>false</code></td>
    <td>sets whether we should merge schemas collected from all ORC part-files. This will override <code>spark.sql.orc.mergeSchema</code>. The default value is specified in <code>spark.sql.orc.mergeSchema</code>.</td>
    <td>read</td>
  </tr>
  <tr>
    <td><code>compression</code></td>
    <td><code>zstd</code></td>
    <td>compression codec to use when saving to file. This can be one of the known case-insensitive shorten names (none, snappy, zlib, lzo, zstd, lz4 and brotli). This will override <code>orc.compress</code> and <code>spark.sql.orc.compression.codec</code>. Note that <code>brotli</code> requires <code>brotli4j</code> to be installed.</td>
    <td>write</td>
  </tr>
</table>
Other generic options can be found in <a href="https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html"> Generic File Source Options</a>. 