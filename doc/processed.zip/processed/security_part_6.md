</td>
  <td>2.0.0</td>
</tr>
</table>

On YARN, the view and modify ACLs are provided to the YARN service when submitting applications, and
control who has the respective privileges via YARN interfaces. ## Spark History Server ACLs

Authentication for the SHS Web UI is enabled the same way as for regular applications, using
servlet filters. To enable authorization in the SHS, a few extra options are used:

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.history.ui.acls.enable</code></td>
  <td>false</td>
  <td>
    Specifies whether ACLs should be checked to authorize users viewing the applications in
    the history server. If enabled, access control checks are performed regardless of what the
    individual applications had set for <code>spark.ui.acls.enable</code>. The application owner
    will always have authorization to view their own application and any users specified via
    <code>spark.ui.view.acls</code> and groups specified via <code>spark.ui.view.acls.groups</code>
    when the application was run will also have authorization to view that application. If disabled, no access control checks are made for any application UIs available through
    the history server. </td>
  <td>1.0.1</td>
</tr>
<tr>
  <td><code>spark.history.ui.admin.acls</code></td>
  <td>None</td>
  <td>
    Comma separated list of users that have view access to all the Spark applications in history
    server. </td>
  <td>2.1.1</td>
</tr>
<tr>
  <td><code>spark.history.ui.admin.acls.groups</code></td>
  <td>None</td>
  <td>
    Comma separated list of groups that have view access to all the Spark applications in history
    server. </td>
  <td>2.1.1</td>
</tr>
</table>

The SHS uses the same options to configure the group mapping provider as regular applications. In this case, the group mapping provider will apply to all UIs server by the SHS, and individual
application configurations will be ignored. ## SSL Configuration

Configuration for SSL is organized hierarchically. The user can configure the default SSL settings
which will be used for all the supported communication protocols unless they are overwritten by
protocol-specific settings. This way the user can easily provide the common settings for all the
protocols without disabling the ability to configure each one individually. Note that all settings 
are inherited this way, *except* for `spark.ssl.rpc.enabled` which must be explicitly set. The following table describes the SSL configuration namespaces:

<table>
  <thead>
  <tr>
    <th>Config Namespace</th>
    <th>Component</th>
  </tr>
  </thead>
  <tr>
    <td><code>spark.ssl</code></td>
    <td>
      The default SSL configuration. These values will apply to all namespaces below, unless
      explicitly overridden at the namespace level.