For Spark applications, the Oozie workflow must be set up for Oozie to request all tokens which
the application needs, including:

- The YARN resource manager. - The local Hadoop filesystem. - Any remote Hadoop filesystems used as a source or destination of I/O. - Hive —if used. - HBase —if used. - The YARN timeline server, if the application interacts with this. To avoid Spark attempting —and then failing— to obtain Hive, HBase and remote HDFS tokens,
the Spark configuration must be set to disable token collection for the services. The Spark configuration must include the lines:

```
spark.security.credentials.hive.enabled   false
spark.security.credentials.hbase.enabled  false
```

The configuration option `spark.kerberos.access.hadoopFileSystems` must be unset. # Using the Spark History Server to replace the Spark Web UI

It is possible to use the Spark History Server application page as the tracking URL for running
applications when the application UI is disabled. This may be desirable on secure clusters, or to
reduce the memory usage of the Spark driver. To set up tracking through the Spark History Server,
do the following:

- On the application side, set <code>spark.yarn.historyServer.allowTracking=true</code> in Spark's
  configuration. This will tell Spark to use the history server's URL as the tracking URL if
  the application's UI is disabled. - On the Spark History Server, add <code>org.apache.spark.deploy.yarn.YarnProxyRedirectFilter</code>
  to the list of filters in the <code>spark.ui.filters</code> configuration. Be aware that the history server information may not be up-to-date with the application's state. # Running multiple versions of the Spark Shuffle Service

Please note that this section only applies when running on YARN versions >= 2.9.0. In some cases it may be desirable to run multiple instances of the Spark Shuffle Service which are
using different versions of Spark. This can be helpful, for example, when running a YARN cluster
with a mixed workload of applications running multiple Spark versions, since a given version of
the shuffle service is not always compatible with other versions of Spark. YARN versions since 2.9.0
support the ability to run shuffle services within an isolated classloader
(see [YARN-4577](https://issues.apache.org/jira/browse/YARN-4577)), meaning multiple Spark versions
can coexist within a single NodeManager. The
`yarn.nodemanager.aux-services.<service-name>.classpath` and, starting from YARN 2.10.2/3.1.1/3.2.0,
`yarn.nodemanager.aux-services.<service-name>.remote-classpath` options can be used to configure
this. Note that YARN 3.3.0/3.3.1 have an issue which requires setting
`yarn.nodemanager.aux-services.<service-name>.system-classes` as a workaround. See
[YARN-11053](https://issues.apache.org/jira/browse/YARN-11053) for details. In addition to setting
up separate classpaths, it's necessary to ensure the two versions advertise to different ports. This can be achieved using the `spark-shuffle-site.xml` file described above.