</td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.metrics.fileSystemSchemes</code></td>
  <td>file,hdfs</td>
  <td>
    The file system schemes to report in executor metrics. </td>
  <td>3.1.0</td>
</tr>
</table>

### Networking

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.rpc.message.maxSize</code></td>
  <td>128</td>
  <td>
    Maximum message size (in MiB) to allow in "control plane" communication; generally only applies to map
    output size information sent between executors and the driver. Increase this if you are running
    jobs with many thousands of map and reduce tasks and see messages about the RPC message size. </td>
  <td>2.0.0</td>
</tr>
<tr>
  <td><code>spark.blockManager.port</code></td>
  <td>(random)</td>
  <td>
    Port for all block managers to listen on. These exist on both the driver and the executors. </td>
  <td>1.1.0</td>
</tr>
<tr>
  <td><code>spark.driver.blockManager.port</code></td>
  <td>(value of spark.blockManager.port)</td>
  <td>
    Driver-specific port for the block manager to listen on, for cases where it cannot use the same
    configuration as executors. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.driver.bindAddress</code></td>
  <td>(value of spark.driver.host)</td>
  <td>
    Hostname or IP address where to bind listening sockets. This config overrides the SPARK_LOCAL_IP
    environment variable (see below). <br />It also allows a different address from the local one to be advertised to executors or external systems. This is useful, for example, when running containers with bridged networking. For this to properly work,
    the different ports used by the driver (RPC, block manager and UI) need to be forwarded from the
    container's host. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.driver.host</code></td>
  <td>(local hostname)</td>
  <td>
    Hostname or IP address for the driver. This is used for communicating with the executors and the standalone Master. </td>
  <td>0.7.0</td>
</tr>
<tr>
  <td><code>spark.driver.port</code></td>
  <td>(random)</td>
  <td>
    Port for the driver to listen on. This is used for communicating with the executors and the standalone Master. </td>
  <td>0.7.0</td>
</tr>
<tr>
  <td><code>spark.rpc.io.backLog</code></td>
  <td>64</td>
  <td>
    Length of the accept queue for the RPC server. For large applications, this value may
    need to be increased, so that incoming connections are not dropped when a large number of
    connections arrives in a short period of time. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.network.timeout</code></td>
  <td>120s</td>
  <td>
    Default timeout for all network interactions.