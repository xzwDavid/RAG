

A literal (also known as a constant) represents a fixed data value. Spark SQL supports the following literals:

 * [String Literal](#string-literal)
 * [Binary Literal](#binary-literal)
 * [Null Literal](#null-literal)
 * [Boolean Literal](#boolean-literal)
 * [Numeric Literal](#numeric-literal)
 * [Datetime Literal](#datetime-literal)
 * [Interval Literal](#interval-literal)

### String Literal

A string literal is used to specify a character string value. #### Syntax

```sql
[ r ] { 'char [ ... ]' | "char [ ... ]" }
```

#### Parameters

* **char**

    One character from the character set. Use `\` to escape special characters (e.g., `'` or `\`). To represent unicode characters, use 16-bit or 32-bit unicode escape of the form `\uxxxx` or `\Uxxxxxxxx`,
    where xxxx and xxxxxxxx are 16-bit and 32-bit code points in hexadecimal respectively (e.g., `\u3042` for `あ` and `\U0001F44D` for `👍`). * **r**

    Case insensitive, indicates `RAW`. If a string literal starts with `r` prefix, neither special characters nor unicode characters are escaped by `\`. The following escape sequences are recognized in regular string literals (without the `r` prefix), and replaced according to the following rules:
- `\0` -> `\u0000`, unicode character with the code 0;
- `\b` -> `\u0008`, backspace;
- `\n` -> `\u000a`, linefeed;
- `\r` -> `\u000d`, carriage return;
- `\t` -> `\u0009`, horizontal tab;
- `\Z` -> `\u001A`, substitute;
- `\%` -> `\%`;
- `\_` -> `\_`;
- `\<other char>` -> `<other char>`, skip the slash and leave the character as is. The unescaping rules above can be turned off by setting the SQL config `spark.sql.parser.escapedStringLiterals` to `true`. #### Examples

```sql
SELECT 'Hello, World!' AS col;
+