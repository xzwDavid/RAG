

* Table of contents
{:toc}


The Spark SQL CLI is a convenient interactive command tool to run the Hive metastore service and execute SQL
queries input from the command line. Note that the Spark SQL CLI cannot talk to the Thrift JDBC server. To start the Spark SQL CLI, run the following in the Spark directory:

    ./bin/spark-sql

Configuration of Hive is done by placing your `hive-site.xml`, `core-site.xml` and `hdfs-site.xml` files in `conf/`. ## Spark SQL Command Line Options

You may run `./bin/spark-sql --help` for a complete list of all available options. CLI options:
     -d,--define <key=value>          Variable substitution to apply to Hive
                                      commands. e.g. -d A=B or --define A=B
        --database <databasename>     Specify the database to use
     -e <quoted-query-string>         SQL from command line
     -f <filename>                    SQL from files
     -H,--help                        Print help information
        --hiveconf <property=value>   Use value for given property
        --hivevar <key=value>         Variable substitution to apply to Hive
                                      commands. e.g. --hivevar A=B
     -i <filename>                    Initialization SQL file
     -S,--silent                      Silent mode in interactive shell
     -v,--verbose                     Verbose mode (echo executed SQL to the
                                      console)

## The hiverc File

When invoked without the `-i`, the Spark SQL CLI will attempt to load `$HIVE_HOME/bin/.hiverc` and `$HOME/.hiverc` as initialization files. ## Path interpretation

Spark SQL CLI supports running SQL from initialization script file(`-i`) or normal SQL file(`-f`), If path url don't have a scheme component, the path will be handled as local file. For example: `/path/to/spark-sql-cli.sql` equals to `file:///path/to/spark-sql-cli.sql`. User also can use Hadoop supported filesystems such as `s3://<mys3bucket>/path/to/spark-sql-cli.sql` or `hdfs://<namenode>:<port>/path/to/spark-sql-cli.sql`. ## Supported comment types

<table>
<thead><tr><th>Comment</th><th>Example</th></tr></thead>
<tr>
  <td>simple comment</td>
  <td>
  <code>
      -- This is a simple comment. <br>
      SELECT 1;
  </code>
  </td>
</tr>
<tr>
  <td>bracketed comment</td>
  <td>
    <code>
        /* This is a bracketed comment.