

### Description

The `TABLESAMPLE` statement is used to sample the table. It supports the following sampling methods:
  * `TABLESAMPLE`(x `ROWS`): Sample the table down to the given number of rows. * `TABLESAMPLE`(x `PERCENT`): Sample the table down to the given percentage. Note that percentages are defined as a number between 0 and 100. * `TABLESAMPLE`(`BUCKET` x `OUT OF` y): Sample the table down to a `x` out of `y` fraction. **Note:** `TABLESAMPLE` returns the approximate number of rows or fraction requested. ### Syntax

```sql
TABLESAMPLE ({ integer_expression | decimal_expression } PERCENT)
    | TABLESAMPLE ( integer_expression ROWS )
    | TABLESAMPLE ( BUCKET integer_expression OUT OF integer_expression )
```

### Examples

```sql
SELECT * FROM test;
+--+