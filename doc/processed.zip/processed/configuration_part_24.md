</td>
  <td>2.2.3</td>
</tr>
<tr>
  <td><code>spark.ui.timelineEnabled</code></td>
  <td>true</td>
  <td>
    Whether to display event timeline data on UI pages. </td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.ui.timeline.executors.maximum</code></td>
  <td>250</td>
  <td>
    The maximum number of executors shown in the event timeline. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.ui.timeline.jobs.maximum</code></td>
  <td>500</td>
  <td>
    The maximum number of jobs shown in the event timeline. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.ui.timeline.stages.maximum</code></td>
  <td>500</td>
  <td>
    The maximum number of stages shown in the event timeline. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.ui.timeline.tasks.maximum</code></td>
  <td>1000</td>
  <td>
    The maximum number of tasks shown in the event timeline. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.appStatusStore.diskStoreDir</code></td>
  <td>None</td>
  <td>
    Local directory where to store diagnostic information of SQL executions. This configuration is only for live UI. </td>
  <td>3.4.0</td>
</tr>
</table>

### Compression and Serialization

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.broadcast.compress</code></td>
  <td>true</td>
  <td>
    Whether to compress broadcast variables before sending them. Generally a good idea. Compression will use <code>spark.io.compression.codec</code>. </td>
  <td>0.6.0</td>
</tr>
<tr>
  <td><code>spark.checkpoint.dir</code></td>
  <td>(none)</td>
  <td>
    Set the default directory for checkpointing. It can be overwritten by
    SparkContext.setCheckpointDir. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.checkpoint.compress</code></td>
  <td>false</td>
  <td>
    Whether to compress RDD checkpoints. Generally a good idea. Compression will use <code>spark.io.compression.codec</code>. </td>
  <td>2.2.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.codec</code></td>
  <td>lz4</td>
  <td>
    The codec used to compress internal data such as RDD partitions, event log, broadcast variables
    and shuffle outputs. By default, Spark provides four codecs: <code>lz4</code>, <code>lzf</code>,
    <code>snappy</code>, and <code>zstd</code>. You can also use fully qualified class names to specify the codec,
    e.g.