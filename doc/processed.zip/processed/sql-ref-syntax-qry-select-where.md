

### Description

The `WHERE` clause is used to limit the results of the `FROM`
clause of a query or a subquery based on the specified condition. ### Syntax

```sql
WHERE boolean_expression
```

### Parameters

* **boolean_expression**

    Specifies any expression that evaluates to a result type `boolean`. Two or
    more expressions may be combined together using the logical
    operators ( `AND`, `OR` ). ### Examples

```sql
CREATE TABLE person (id INT, name STRING, age INT);
INSERT INTO person VALUES
    (100, 'John', 30),
    (200, 'Mary', NULL),
    (300, 'Mike', 80),
    (400, 'Dan',  50);

-- Comparison operator in `WHERE` clause. SELECT * FROM person WHERE id > 200 ORDER BY id;
+