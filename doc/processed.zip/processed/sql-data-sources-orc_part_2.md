<div class="codetabs">
<div data-lang="SQL"  markdown="1">
{% highlight sql %}
CREATE TABLE encrypted (
  ssn STRING,
  email STRING,
  name STRING
)
USING ORC
OPTIONS (
  hadoop.security.key.provider.path "kms://http@localhost:9600/kms",
  orc.key.provider "hadoop",
  orc.encrypt "pii:ssn,email",
  orc.mask "nullify:ssn;sha256:email"
)
{% endhighlight %}
</div>
</div>

### Hive metastore ORC table conversion

When reading from Hive metastore ORC tables and inserting to Hive metastore ORC tables, Spark SQL will try to use its own ORC support instead of Hive SerDe for better performance. For CTAS statement, only non-partitioned Hive metastore ORC tables are converted. This behavior is controlled by the `spark.sql.hive.convertMetastoreOrc` configuration, and is turned on by default. ### Configuration

<table class="spark-config">
  <thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
  <tr>
    <td><code>spark.sql.orc.impl</code></td>
    <td><code>native</code></td>
    <td>
      The name of ORC implementation. It can be one of <code>native</code> and <code>hive</code>. <code>native</code> means the native ORC support. <code>hive</code> means the ORC library
      in Hive. </td>
    <td>2.3.0</td>
  </tr>
  <tr>
    <td><code>spark.sql.orc.enableVectorizedReader</code></td>
    <td><code>true</code></td>
    <td>
      Enables vectorized orc decoding in <code>native</code> implementation. If <code>false</code>,
      a new non-vectorized ORC reader is used in <code>native</code> implementation. For <code>hive</code> implementation, this is ignored. </td>
    <td>2.3.0</td>
  </tr>
  <tr>
    <td><code>spark.sql.orc.columnarReaderBatchSize</code></td>
    <td><code>4096</code></td>
    <td>
      The number of rows to include in an orc vectorized reader batch. The number should
      be carefully chosen to minimize overhead and avoid OOMs in reading data. </td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td><code>spark.sql.orc.columnarWriterBatchSize</code></td>
    <td><code>1024</code></td>
    <td>
      The number of rows to include in an orc vectorized writer batch. The number should
      be carefully chosen to minimize overhead and avoid OOMs in writing data. </td>
    <td>3.4.0</td>
  </tr>
  <tr>
    <td><code>spark.sql.orc.enableNestedColumnVectorizedReader</code></td>
    <td><code>true</code></td>
    <td>
      Enables vectorized orc decoding in <code>native</code> implementation for nested data types
      (array, map and struct). If <code>spark.sql.orc.enableVectorizedReader</code> is set to
      <code>false</code>, this is ignored.