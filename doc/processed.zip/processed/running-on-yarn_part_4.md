Please note that this feature can be used only with YARN 3.0+
    For reference, see <a href="https://hadoop.apache.org/docs/current/hadoop-yarn/hadoop-yarn-site/ResourceModel.html">YARN Resource Model documentation</a>
    <p/>
    Example:
    To request GPU resources from YARN, use: <code>spark.yarn.am.resource.yarn.io/gpu.amount</code>
  </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.yarn.applicationType</code></td>
  <td><code>SPARK</code></td>
  <td>
    Defines more specific application types, e.g. <code>SPARK</code>, <code>SPARK-SQL</code>, <code>SPARK-STREAMING</code>,
    <code>SPARK-MLLIB</code> and <code>SPARK-GRAPH</code>. Please be careful not to exceed 20 characters. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.yarn.driver.resource.{resource-type}.amount</code></td>
  <td><code>(none)</code></td>
  <td>
    Amount of resource to use for the YARN Application Master in cluster mode. Please note that this feature can be used only with YARN 3.0+
    For reference, see <a href="https://hadoop.apache.org/docs/current/hadoop-yarn/hadoop-yarn-site/ResourceModel.html">YARN Resource Model documentation</a>
    <p/>
    Example:
    To request GPU resources from YARN, use: <code>spark.yarn.driver.resource.yarn.io/gpu.amount</code>
  </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.yarn.executor.resource.{resource-type}.amount</code></td>
  <td><code>(none)</code></td>
  <td>
    Amount of resource to use per executor process. Please note that this feature can be used only with YARN 3.0+
    For reference, see <a href="https://hadoop.apache.org/docs/current/hadoop-yarn/hadoop-yarn-site/ResourceModel.html">YARN Resource Model documentation</a>
    <p/>
    Example:
    To request GPU resources from YARN, use: <code>spark.yarn.executor.resource.yarn.io/gpu.amount</code>
  </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.yarn.resourceGpuDeviceName</code></td>
  <td><code>yarn.io/gpu</code></td>
  <td>
    Specify the mapping of the Spark resource type of <code>gpu</code> to the YARN resource
    representing a GPU. By default YARN uses <code>yarn.io/gpu</code> but if YARN has been
    configured with a custom resource type, this allows remapping it. Applies when using the <code>spark.{driver/executor}.resource.gpu.*</code> configs. </td>
  <td>3.2.1</td>
</tr>
<tr>
  <td><code>spark.yarn.resourceFpgaDeviceName</code></td>
  <td><code>yarn.io/fpga</code></td>
  <td>
    Specify the mapping of the Spark resource type of <code>fpga</code> to the YARN resource
    representing a FPGA.