`predictProbability` is made public in all the Classification models except `LinearSVCModel`
([SPARK-30358](https://issues.apache.org/jira/browse/SPARK-30358)). # Migration Guide

The migration guide is now archived [on this page](ml-migration-guide.html). 