{% include_example scala/org/apache/spark/examples/mllib/IsotonicRegressionExample.scala %}
</div>
<div data-lang="java" markdown="1">
Data are read from a file where each line has a format label,feature
i.e. 4710.28,500.00. The data are split to training and testing set. Model is created using the training set and a mean squared error is calculated from the predicted
labels and real labels in the test set. Refer to the [`IsotonicRegression` Java docs](api/java/org/apache/spark/mllib/regression/IsotonicRegression.html) and [`IsotonicRegressionModel` Java docs](api/java/org/apache/spark/mllib/regression/IsotonicRegressionModel.html) for details on the API. {% include_example java/org/apache/spark/examples/mllib/JavaIsotonicRegressionExample.java %}
</div>

</div>
