</td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.dynamicAllocation.deleteGracePeriod</code></td>
  <td><code>5s</code></td>
  <td>
    How long to wait for executors to shut down gracefully before a forceful kill. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.file.upload.path</code></td>
  <td>(none)</td>
  <td>
    Path to store files at the spark submit side in cluster mode. For example:
    <code>spark.kubernetes.file.upload.path=s3a://&lt;s3-bucket&gt;/path</code>
    File should specified as <code>file://path/to/file </code> or absolute path. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.executor.decommissionLabel</code></td>
  <td>(none)</td>
  <td>
    Label to be applied to pods which are exiting or being decommissioned. Intended for use
    with pod disruption budgets, deletion costs, and similar. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.executor.decommissionLabelValue</code></td>
  <td>(none)</td>
  <td>
    Value to be applied with the label when
    <code>spark.kubernetes.executor.decommissionLabel</code> is enabled. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.executor.scheduler.name</code></td>
  <td>(none)</td>
  <td>
	Specify the scheduler name for each executor pod. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.scheduler.name</code></td>
  <td>(none)</td>
  <td>
    Specify the scheduler name for driver pod. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.scheduler.name</code></td>
  <td>(none)</td>
  <td>
    Specify the scheduler name for driver and executor pods. If `spark.kubernetes.driver.scheduler.name` or
    `spark.kubernetes.executor.scheduler.name` is set, will override this. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.configMap.maxSize</code></td>
  <td><code>1572864</code></td>
  <td>
    Max size limit for a config map. This is configurable as per <a href="https://etcd.io/docs/latest/dev-guide/limit/">limit</a> on k8s server end. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.executor.missingPodDetectDelta</code></td>
  <td><code>30s</code></td>
  <td>
    When a registered executor's POD is missing from the Kubernetes API server's polled
    list of PODs then this delta time is taken as the accepted time difference between the
    registration time and the time of the polling. After this time the POD is considered
    missing from the cluster and the executor will be removed.