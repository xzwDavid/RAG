- namespace=JVMCPU
  - jvmCpuTime

- namespace=NettyBlockTransfer
  - shuffle-client.usedDirectMemory
  - shuffle-client.usedHeapMemory
  - shuffle-server.usedDirectMemory
  - shuffle-server.usedHeapMemory

- namespace=HiveExternalCatalog
  - **note:** these metrics are conditional to a configuration parameter:
    `spark.metrics.staticSources.enabled` (default is true)
  - fileCacheHits.count
  - filesDiscovered.count
  - hiveClientCalls.count
  - parallelListingJobCount.count
  - partitionsFetched.count

- namespace=CodeGenerator
  - **note:** these metrics are conditional to a configuration parameter:
    `spark.metrics.staticSources.enabled` (default is true)
  - compilationTime (histogram)
  - generatedClassSize (histogram)
  - generatedMethodSize (histogram)
  - sourceCodeSize (histogram)

- namespace=plugin.\<Plugin Class Name>
  - Optional namespace(s). Metrics in this namespace are defined by user-supplied code, and
  configured using the Spark plugin API. See "Advanced Instrumentation" below for how to load
  custom plugins into Spark. ### Source = JVM Source
Notes:
  - Activate this source by setting the relevant `metrics.properties` file entry or the
  configuration parameter:`spark.metrics.conf.*.source.jvm.class=org.apache.spark.metrics.source.JvmSource`
  - These metrics are conditional to a configuration parameter:
    `spark.metrics.staticSources.enabled` (default is true)
  - This source is available for driver and executor instances and is also available for other instances. - This source provides information on JVM metrics using the
  [Dropwizard/Codahale Metric Sets for JVM instrumentation](https://metrics.dropwizard.io/4.2.0/manual/jvm.html)
   and in particular the metric sets BufferPoolMetricSet, GarbageCollectorMetricSet and MemoryUsageGaugeSet. ### Component instance = applicationMaster
Note: applies when running on YARN

- numContainersPendingAllocate
- numExecutorsFailed
- numExecutorsRunning
- numLocalityAwareTasks
- numReleasedContainers

### Component instance = master
Note: applies when running in Spark standalone as master

- workers
- aliveWorkers
- apps
- waitingApps

### Component instance = ApplicationSource
Note: applies when running in Spark standalone as master

- status
- runtime_ms
- cores

### Component instance = worker
Note: applies when running in Spark standalone as worker

- executors
- coresUsed
- memUsed_MB
- coresFree
- memFree_MB

### Component instance = shuffleService
Note: applies to the shuffle service

- blockTransferRate (meter) - rate of blocks being transferred
- blockTransferMessageRate (meter) - rate of block transfer messages,
  i.e.