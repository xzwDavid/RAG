#### Syntax

```sql
ALTER TABLE table_identifier [ partition_spec ] REPLACE COLUMNS  
  [ ( ] qualified_col_type_with_position_list [ ) ]
```

#### Parameters

* **table_identifier**

  Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **partition_spec**

  Partition to be replaced. Note that one can use a typed literal (e.g., date'2019-01-02') in the partition spec. **Syntax:** `PARTITION ( partition_col_name  = partition_col_val [ , ... ] )`

* **qualified_col_type_with_position_list**

  The list of the column(s) to be added

  **Syntax:** `col_name col_type [ col_comment ] [ col_position ] [ , ... ]`

### ADD AND DROP PARTITION

#### ADD PARTITION

`ALTER TABLE ADD` statement adds partition to the partitioned table. If the table is cached, the command clears cached data of the table and all its dependents that refer to it. The cache will be lazily filled when the next time the table or the dependents are accessed. ##### Syntax

```sql
ALTER TABLE table_identifier ADD [IF NOT EXISTS] 
    ( partition_spec [ partition_spec ... ] )
```
     
##### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **partition_spec**

    Partition to be added. Note that one can use a typed literal (e.g., date'2019-01-02') in the partition spec. **Syntax:** `PARTITION ( partition_col_name  = partition_col_val [ , ... ] )`

#### DROP PARTITION

`ALTER TABLE DROP` statement drops the partition of the table. If the table is cached, the command clears cached data of the table and all its dependents that refer to it. The cache will be lazily filled when the next time the table or the dependents are accessed. ##### Syntax

```sql
ALTER TABLE table_identifier DROP [ IF EXISTS ] partition_spec [PURGE]
```
     
##### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **partition_spec**

    Partition to be dropped. Note that one can use a typed literal (e.g., date'2019-01-02') in the partition spec. **Syntax:** `PARTITION ( partition_col_name  = partition_col_val [ , ... ] )`

#### CLUSTER BY

`ALTER TABLE CLUSTER BY` command can also be used for changing or removing the clustering columns for existing tables. ##### Syntax

```sql
-- Changing Clustering Columns
ALTER TABLE table_identifier CLUSTER BY ( col_name [ , ... ] )

-- Removing Clustering Columns
ALTER TABLE table_identifier CLUSTER BY NONE
```

#### Parameters

* **table_identifier**

  Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **col_name**

  Specifies the name of the column. ### SET AND UNSET

#### SET PROPERTIES

`ALTER TABLE SET` command is used for setting the table properties. If a particular property was already set, 
this overrides the old value with the new one. ##### Syntax

```sql
-- Set Properties
ALTER TABLE table_identifier SET TBLPROPERTIES ( key1 = val1, key2 = val2, ... )
```

#### UNSET PROPERTIES

`ALTER TABLE UNSET` command is used to drop the table property.