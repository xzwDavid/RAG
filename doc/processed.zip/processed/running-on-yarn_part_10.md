</td>
  <td>2.0.0</td>
</tr>
<tr>
  <td><code>spark.yarn.rolledLog.excludePattern</code></td>
  <td>(none)</td>
  <td>
  Java Regex to filter the log files which match the defined exclude pattern
  and those log files will not be aggregated in a rolling fashion. If the log file
  name matches both the include and the exclude pattern, this file will be excluded eventually. </td>
  <td>2.0.0</td>
</tr>
<tr>
  <td><code>spark.yarn.executor.launch.excludeOnFailure.enabled</code></td>
  <td>false</td>
  <td>
  Flag to enable exclusion of nodes having YARN resource allocation problems. The error limit for excluding can be configured by
  <code>spark.excludeOnFailure.application.maxFailedExecutorsPerNode</code>. </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.yarn.exclude.nodes</code></td>
  <td>(none)</td>
  <td>
  Comma-separated list of YARN node names which are excluded from resource allocation. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.yarn.metrics.namespace</code></td>
  <td>(none)</td>
  <td>
  The root namespace for AM metrics reporting. If it is not set then the YARN application ID is used. </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.yarn.report.interval</code></td>
  <td><code>1s</code></td>
  <td>
    Interval between reports of the current Spark job status in cluster mode. </td>
  <td>0.9.0</td>
</tr>
<tr>
  <td><code>spark.yarn.report.loggingFrequency</code></td>
  <td><code>30</code></td>
  <td>
    Maximum number of application reports processed until the next application status
    is logged. If there is a change of state, the application status will be logged regardless
    of the number of application reports processed. </td>
  <td>3.5.0</td>
</tr>
<tr>
  <td><code>spark.yarn.clientLaunchMonitorInterval</code></td>
  <td><code>1s</code></td>
  <td>
    Interval between requests for status the client mode AM when starting the app. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.yarn.includeDriverLogsLink</code></td>
  <td><code>false</code></td>
  <td>
    In cluster mode, whether the client application report includes links to the driver
    container's logs. This requires polling the ResourceManager's REST API, so it
    places some additional load on the RM. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.yarn.unmanagedAM.enabled</code></td>
  <td><code>false</code></td>
  <td>
    In client mode, whether to launch the Application Master service as part of the client
    using unmanaged am. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.yarn.shuffle.server.recovery.disabled</code></td>
  <td>false</td>
  <td>
    Set to true for applications that have higher security requirements and prefer that their
    secret is not saved in the db. The shuffle data of such applications wll not be recovered after
    the External Shuffle Service restarts.