

### Description

The `CREATE TABLE` statement defines a new table using Hive format. ### Syntax

```sql
CREATE [ EXTERNAL ] TABLE [ IF NOT EXISTS ] table_identifier
    [ ( col_name1[:] col_type1 [ COMMENT col_comment1 ], ... ) ]
    [ COMMENT table_comment ]
    [ PARTITIONED BY ( col_name2[:] col_type2 [ COMMENT col_comment2 ], ... ) 
        | ( col_name1, col_name2, ... ) ]
    [ CLUSTERED BY ( col_name1, col_name2, ...) 
        [ SORTED BY ( col_name1 [ ASC | DESC ], col_name2 [ ASC | DESC ], ... ) ] 
        INTO num_buckets BUCKETS ]
    [ ROW FORMAT row_format ]
    [ STORED AS file_format ]
    [ LOCATION path ]
    [ TBLPROPERTIES ( key1=val1, key2=val2, ... ) ]
    [ AS select_statement ]
```

Note that, the clauses between the columns definition clause and the AS SELECT clause can come in
as any order. For example, you can write COMMENT table_comment after TBLPROPERTIES. ### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **EXTERNAL**

    Table is defined using the path provided as `LOCATION`, does not use default location for this table. * **PARTITIONED BY**

    Partitions are created on the table, based on the columns specified. * **CLUSTERED BY**

    Partitions created on the table will be bucketed into fixed buckets based on the column specified for bucketing. **NOTE:** Bucketing is an optimization technique that uses buckets (and bucketing columns) to determine data partitioning and avoid data shuffle. * **SORTED BY**

    Specifies an ordering of bucket columns. Optionally, one can use ASC for an ascending order or DESC for a descending order after any column names in the SORTED BY clause. If not specified, ASC is assumed by default. * **INTO num_buckets BUCKETS**

    Specifies buckets numbers, which is used in `CLUSTERED BY` clause. * **row_format** 

    Specifies the row format for input and output. See [HIVE FORMAT](sql-ref-syntax-hive-format.html) for more syntax details. * **STORED AS**

    File format for table storage, could be TEXTFILE, ORC, PARQUET, etc. * **LOCATION**

    Path to the directory where table data is stored, which could be a path on distributed storage like HDFS, etc. * **COMMENT**

    A string literal to describe the table. * **TBLPROPERTIES**

    A list of key-value pairs that is used to tag the table definition. * **AS select_statement**

    The table is populated using the data from the select statement.