

### Description

`UNCACHE TABLE` removes the entries and associated data from the in-memory and/or on-disk cache for a given table or view. The
underlying entries should already have been brought to cache by previous `CACHE TABLE` operation. `UNCACHE TABLE` on a non-existent table throws an exception if `IF EXISTS` is not specified. ### Syntax

```sql
UNCACHE TABLE [ IF EXISTS ] table_identifier
```

### Parameters

* **table_identifier**

    Specifies the table or view name to be uncached. The table or view name may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

### Examples

```sql
UNCACHE TABLE t1;
```

### Related Statements

* [CACHE TABLE](sql-ref-syntax-aux-cache-cache-table.html)
* [CLEAR CACHE](sql-ref-syntax-aux-cache-clear-cache.html)
* [REFRESH TABLE](sql-ref-syntax-aux-cache-refresh-table.html)
* [REFRESH](sql-ref-syntax-aux-cache-refresh.html)
* [REFRESH FUNCTION](sql-ref-syntax-aux-cache-refresh-function.html)