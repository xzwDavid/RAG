#### Spark Properties

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.kubernetes.context</code></td>
  <td><code>(none)</code></td>
  <td>
    The context from the user Kubernetes configuration file used for the initial
    auto-configuration of the Kubernetes client library. When not specified then
    the users current context is used. <strong>NB:</strong> Many of the
    auto-configured settings can be overridden by the use of other Spark
    configuration properties e.g. <code>spark.kubernetes.namespace</code>. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.master</code></td>
  <td><code>https://kubernetes.default.svc</code></td>
  <td>
    The internal Kubernetes master (API server) address to be used for driver to request executors or
    'local[*]' for driver-pod-only mode. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.namespace</code></td>
  <td><code>default</code></td>
  <td>
    The namespace that will be used for running the driver and executor pods. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.container.image</code></td>
  <td><code>(none)</code></td>
  <td>
    Container image to use for the Spark application. This is usually of the form <code>example.com/repo/spark:v1.0.0</code>. This configuration is required and must be provided by the user, unless explicit
    images are provided for each different container type. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.container.image</code></td>
  <td><code>(value of spark.kubernetes.container.image)</code></td>
  <td>
    Custom container image to use for the driver. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.executor.container.image</code></td>
  <td><code>(value of spark.kubernetes.container.image)</code></td>
  <td>
    Custom container image to use for executors. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.container.image.pullPolicy</code></td>
  <td><code>IfNotPresent</code></td>
  <td>
    Container image pull policy used when pulling images within Kubernetes. Valid values are <code>Always</code>, <code>Never</code>, and <code>IfNotPresent</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.container.image.pullSecrets</code></td>
  <td><code></code></td>
  <td>
    Comma separated list of Kubernetes secrets used to pull images from private image registries. </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.allocation.batch.size</code></td>
  <td><code>5</code></td>
  <td>
    Number of pods to launch at once in each round of executor pod allocation.