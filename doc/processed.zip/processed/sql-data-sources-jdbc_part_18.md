<table>
  <thead>
    <tr>
      <th><b>Spark SQL Data Type</b></th>
      <th><b>Oracle Data Type</b></th>
      <th><b>Remarks</b></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>BooleanType</td>
      <td>NUMBER(1, 0)</td>
      <td>BooleanType maps to NUMBER(1, 0) as BOOLEAN is introduced since Oracle Release 23c</td>
    </tr>
    <tr>
      <td>ByteType</td>
      <td>NUMBER(3)</td>
      <td></td>
    </tr>
    <tr>
      <td>ShortType</td>
      <td>NUMBER(5)</td>
      <td></td>
    </tr>
    <tr>
      <td>IntegerType</td>
      <td>NUMBER(10)</td>
      <td></td>
    </tr>
    <tr>
      <td>LongType</td>
      <td>NUMBER(19)</td>
      <td></td>
    </tr>
    <tr>
      <td>FloatType</td>
      <td>NUMBER(19, 4)</td>
      <td></td>
    </tr>
    <tr>
      <td>DoubleType</td>
      <td>NUMBER(19, 4)</td>
      <td></td>
    </tr>
    <tr>
      <td>DecimalType(p, s)</td>
      <td>NUMBER(p,s)</td>
      <td></td>
    </tr>
    <tr>
      <td>DateType</td>
      <td>DATE</td>
      <td></td>
    </tr>
    <tr>
      <td>TimestampType</td>
      <td>TIMESTAMP WITH LOCAL TIME ZONE</td>
      <td></td>
    </tr>
    <tr>
      <td>TimestampNTZType</td>
      <td>TIMESTAMP</td>
      <td></td>
    </tr>
    <tr>
      <td>StringType</td>
      <td>VARCHAR2(255)</td>
      <td>For historical reason, a string value has maximum 255 characters</td>
    </tr>
    <tr>
      <td>BinaryType</td>
      <td>BLOB</td>
      <td></td>
    </tr>
    <tr>
      <td>CharType(n)</td>
      <td>CHAR(n)</td>
      <td></td>
    </tr>
    <tr>
      <td>VarcharType(n)</td>
      <td>VARCHAR2(n)</td>
      <td></td>
    </tr>
  </tbody>
</table>

The Spark Catalyst data types below are not supported with suitable Oracle types.