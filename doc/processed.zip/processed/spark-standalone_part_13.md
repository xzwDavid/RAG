Note that the directory should be clearly manually if <code>spark.deploy.recoveryMode</code>
      or <code>spark.deploy.recoveryCompressionCodec</code> is changed. </td>
    <td>0.8.1</td>
  </tr>
  <tr>
    <td><code>spark.deploy.recoveryCompressionCodec</code></td>
    <td>(none)</td>
    <td>A compression codec for persistence engines. none (default), lz4, lzf, snappy, and zstd. Currently, only FILESYSTEM mode supports this configuration.</td>
    <td>4.0.0</td>
  </tr>
  <tr>
    <td><code>spark.deploy.recoveryTimeout</code></td>
    <td>(none)</td>
    <td>
      The timeout for recovery process. The default value is the same with
      <code>spark.worker.timeout</code>. </td>
    <td>4.0.0</td>
  </tr>
  <tr>
    <td><code>spark.deploy.recoveryMode.factory</code></td>
    <td>""</td>
    <td>A class to implement <code>StandaloneRecoveryModeFactory</code> interface</td>
    <td>1.2.0</td>
  </tr>
  <tr>
    <td><code>spark.deploy.zookeeper.url</code></td>
    <td>None</td>
    <td>When `spark.deploy.recoveryMode` is set to ZOOKEEPER, this configuration is used to set the zookeeper URL to connect to.</td>
    <td>0.8.1</td>
  </tr>
  <tr>
    <td><code>spark.deploy.zookeeper.dir</code></td>
    <td>None</td>
    <td>When `spark.deploy.recoveryMode` is set to ZOOKEEPER, this configuration is used to set the zookeeper directory to store recovery state.</td>
    <td>0.8.1</td>
  </tr>
</table>

**Details**

* This solution can be used in tandem with a process monitor/manager like [monit](https://mmonit.com/monit/), or just to enable manual recovery via restart. * While filesystem recovery seems straightforwardly better than not doing any recovery at all, this mode may be suboptimal for certain development or experimental purposes. In particular, killing a master via stop-master.sh does not clean up its recovery state, so whenever you start a new Master, it will enter recovery mode. This could increase the startup time by up to 1 minute if it needs to wait for all previously-registered Workers/clients to timeout. * While it's not officially supported, you could mount an NFS directory as the recovery directory. If the original Master node dies completely, you could then start a Master on a different node, which would correctly recover all previously registered Workers/applications (equivalent to ZooKeeper recovery). Future applications will have to be able to find the new Master, however, in order to register. 