

### Syntax

#### Overview

Apache Spark supports SQL pipe syntax which allows composing queries from combinations of operators. * Any query can have zero or more pipe operators as a suffix, delineated by the pipe character `|>`. * Each pipe operator starts with one or more SQL keywords followed by its own grammar as described
  in the table below. * Most of these operators reuse existing grammar for standard SQL clauses. * Operators can apply in any order, any number of times. `FROM <tableName>` is now a supported standalone query which behaves the same as
`TABLE <tableName>`. This provides a convenient starting place to begin a chained pipe SQL query,
although it is possible to add one or more pipe operators to the end of any valid Spark SQL query
with the same consistent behavior as written here. Please refer to the table at the end of this document for a full list of all supported operators
and their semantics. #### Example

For example, this is query 13 from the TPC-H benchmark:

```sql
SELECT c_count, COUNT(*) AS custdist
FROM
  (SELECT c_custkey, COUNT(o_orderkey) c_count
   FROM customer
   LEFT OUTER JOIN orders ON c_custkey = o_custkey
     AND o_comment NOT LIKE '%unusual%packages%' GROUP BY c_custkey
  ) AS c_orders
GROUP BY c_count
ORDER BY custdist DESC, c_count DESC;
```

To write the same logic using SQL pipe operators, we express it like this:

```sql
FROM customer
|> LEFT OUTER JOIN orders ON c_custkey = o_custkey
   AND o_comment NOT LIKE '%unusual%packages%'
|> AGGREGATE COUNT(o_orderkey) c_count
   GROUP BY c_custkey
|> AGGREGATE COUNT(*) AS custdist
   GROUP BY c_count
|> ORDER BY custdist DESC, c_count DESC;
```

#### Source Tables

To start a new query using SQL pipe syntax, use the `FROM <tableName>` or `TABLE <tableName>`
clause, which creates a relation comprising all rows from the source table. Then append one or more
pipe operators to the end of this clause to perform further transformations. #### Projections

SQL pipe syntax supports composable ways to evaluate expressions. A major advantage of these
projection features is that they support computing new expressions based on previous ones in an
incremental way. No lateral column references are needed here since each operator applies
independently on its input table, regardless of the order in which the operators appear. Each of
these computed columns then becomes visible to use with the following operator. `SELECT` produces a new table by evaluating the provided expressions.<br>
It is possible to use `DISTINCT` and `*` as needed.<br>
This works like the outermost `SELECT` in a table subquery in regular Spark SQL. `EXTEND` adds new columns to the input table by evaluating the provided expressions.<br>
This also preserves table aliases.<br>
This works like `SELECT *, new_column` in regular Spark SQL. `DROP` removes columns from the input table.<br>
This is similar to `SELECT * EXCEPT (column)` in regular Spark SQL. `SET` replaces column values from the input table.<br>
This is similar to `SELECT * REPLACE (expression AS column)` in regular Spark SQL. `AS` forwards the input table and introduces a new alias for each row. #### Aggregations

In general, aggregation takes place differently using SQL pipe syntax as opposed to regular Spark
SQL. To perform full-table aggregation, use the `AGGREGATE` operator with a list of aggregate
expressions to evaluate. This returns one single row in the output table. To perform aggregation with grouping, use the `AGGREGATE` operator with a `GROUP BY` clause. This returns one row for each unique combination of values of the grouping expressions. The output
table contains the evaluated grouping expressions followed by the evaluated aggregate functions. Grouping expressions support assigning aliases for purposes of referring to them in future
operators. In this way, it is not necessary to repeat entire expressions between `GROUP BY` and
`SELECT`, since `AGGREGATE` is a single operator that performs both. #### Other Transformations

The remaining operators are used for other transformations, such as filtering, joining, sorting,
sampling, and set operations.