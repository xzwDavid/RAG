> When fitting LinearRegressionModel without intercept on dataset with constant nonzero column by "l-bfgs" solver, Spark MLlib outputs zero coefficients for constant nonzero columns. This behavior is the same as R glmnet but different from LIBSVM. **Examples**

The following
example demonstrates training an elastic net regularized linear
regression model and extracting model summary statistics. <div class="codetabs">

<div data-lang="python" markdown="1">
<!