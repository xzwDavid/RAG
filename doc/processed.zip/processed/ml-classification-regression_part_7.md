A feature's value is the frequency of the term (in Multinomial or Complement Naive Bayes) or
a zero or one indicating whether the term was found in the document (in Bernoulli Naive Bayes). Feature values for Multinomial and Bernoulli models must be *non-negative*. The model type is selected with an optional parameter
"multinomial", "complement", "bernoulli" or "gaussian", with "multinomial" as the default. For document classification, the input feature vectors should usually be sparse vectors. Since the training data is only used once, it is not necessary to cache it. [Additive smoothing](http://en.wikipedia.org/wiki/Lidstone_smoothing) can be used by
setting the parameter $\lambda$ (default to $1.0$). **Examples**

<div class="codetabs">

<div data-lang="python" markdown="1">

Refer to the [Python API docs](api/python/reference/api/pyspark.ml.classification.NaiveBayes.html) for more details. {% include_example python/ml/naive_bayes_example.py %}
</div>

<div data-lang="scala" markdown="1">

Refer to the [Scala API docs](api/scala/org/apache/spark/ml/classification/NaiveBayes.html) for more details. {% include_example scala/org/apache/spark/examples/ml/NaiveBayesExample.scala %}
</div>

<div data-lang="java" markdown="1">

Refer to the [Java API docs](api/java/org/apache/spark/ml/classification/NaiveBayes.html) for more details. {% include_example java/org/apache/spark/examples/ml/JavaNaiveBayesExample.java %}
</div>

<div data-lang="r" markdown="1">

Refer to the [R API docs](api/R/reference/spark.naiveBayes.html) for more details. {% include_example r/ml/naiveBayes.R %}
</div>

</div>


## Factorization machines classifier

For more background and more details about the implementation of factorization machines,
refer to the [Factorization Machines section](ml-classification-regression.html#factorization-machines). **Examples**

The following examples load a dataset in LibSVM format, split it into training and test sets,
train on the first dataset, and then evaluate on the held-out test set. We scale features to be between 0 and 1 to prevent the exploding gradient problem. <div class="codetabs">

<div data-lang="python" markdown="1">

Refer to the [Python API docs](api/python/reference/api/pyspark.ml.classification.FMClassifier.html) for more details. {% include_example python/ml/fm_classifier_example.py %}
</div>

<div data-lang="scala" markdown="1">

Refer to the [Scala API docs](api/scala/org/apache/spark/ml/classification/FMClassifier.html) for more details. {% include_example scala/org/apache/spark/examples/ml/FMClassifierExample.scala %}
</div>

<div data-lang="java" markdown="1">

Refer to the [Java API docs](api/java/org/apache/spark/ml/classification/FMClassifier.html) for more details. {% include_example java/org/apache/spark/examples/ml/JavaFMClassifierExample.java %}
</div>

<div data-lang="r" markdown="1">

Refer to the [R API docs](api/R/reference/spark.fmClassifier.html) for more details. Note: At the moment SparkR doesn't support feature scaling. {% include_example r/ml/fmClassifier.R %}
</div>

</div>


# Regression

## Linear regression

The interface for working with linear regression models and model
summaries is similar to the logistic regression case.