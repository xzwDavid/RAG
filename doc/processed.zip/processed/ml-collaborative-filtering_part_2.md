This can be useful in a production system, since it indicates 
a new user or item, and so the system can make a decision on some fallback to use as the prediction. However, this is undesirable during cross-validation, since any `NaN` predicted values will result
in `NaN` results for the evaluation metric (for example when using `RegressionEvaluator`). This makes model selection impossible. Spark allows users to set the `coldStartStrategy` parameter
to "drop" in order to drop any rows in the `DataFrame` of predictions that contain `NaN` values. The evaluation metric will then be computed over the non-`NaN` data and will be valid. Usage of this parameter is illustrated in the example below. **Note:** currently the supported cold start strategies are "nan" (the default behavior mentioned 
above) and "drop". Further strategies may be supported in future. **Examples**

<div class="codetabs">

<div data-lang="python" markdown="1">

In the following example, we load ratings data from the
[MovieLens dataset](http://grouplens.org/datasets/movielens/), each row
consisting of a user, a movie, a rating and a timestamp. We then train an ALS model which assumes, by default, that the ratings are
explicit (`implicitPrefs` is `False`). We evaluate the recommendation model by measuring the root-mean-square error of
rating prediction. Refer to the [`ALS` Python docs](api/python/reference/api/pyspark.ml.recommendation.ALS.html)
for more details on the API. {% include_example python/ml/als_example.py %}

If the rating matrix is derived from another source of information (i.e. it is
inferred from other signals), you can set `implicitPrefs` to `True` to get
better results:

{% highlight python %}
als = ALS(maxIter=5, regParam=0.01, implicitPrefs=True,
          userCol="userId", itemCol="movieId", ratingCol="rating")
{% endhighlight %}

</div>

<div data-lang="scala" markdown="1">

In the following example, we load ratings data from the
[MovieLens dataset](http://grouplens.org/datasets/movielens/), each row
consisting of a user, a movie, a rating and a timestamp. We then train an ALS model which assumes, by default, that the ratings are
explicit (`implicitPrefs` is `false`). We evaluate the recommendation model by measuring the root-mean-square error of
rating prediction. Refer to the [`ALS` Scala docs](api/scala/org/apache/spark/ml/recommendation/ALS.html)
for more details on the API. {% include_example scala/org/apache/spark/examples/ml/ALSExample.scala %}

If the rating matrix is derived from another source of information (i.e. it is
inferred from other signals), you can set `implicitPrefs` to `true` to get
better results:

{% highlight scala %}
val als = new ALS()
  .setMaxIter(5)
  .setRegParam(0.01)
  .setImplicitPrefs(true)
  .setUserCol("userId")
  .setItemCol("movieId")
  .setRatingCol("rating")
{% endhighlight %}

</div>

<div data-lang="java" markdown="1">

In the following example, we load ratings data from the
[MovieLens dataset](http://grouplens.org/datasets/movielens/), each row
consisting of a user, a movie, a rating and a timestamp. We then train an ALS model which assumes, by default, that the ratings are
explicit (`implicitPrefs` is `false`). We evaluate the recommendation model by measuring the root-mean-square error of
rating prediction. Refer to the [`ALS` Java docs](api/java/org/apache/spark/ml/recommendation/ALS.html)
for more details on the API.