For any additional jars that your application depends on, you
should specify them through the `--jars` flag using comma as a delimiter (e.g. `--jars jar1,jar2`). To control the application's configuration or execution environment, see
[Spark Configuration](configuration.html). Additionally, standalone `cluster` mode supports restarting your application automatically if it
exited with non-zero exit code. To use this feature, you may pass in the `--supervise` flag to
`spark-submit` when launching your application. Then, if you wish to kill an application that is
failing repeatedly, you may do so through:

    ./bin/spark-class org.apache.spark.deploy.Client kill <master url> <driver ID>

You can find the driver ID through the standalone Master web UI at `http://<master url>:8080`. ## REST API

If `spark.master.rest.enabled` is enabled, Spark master provides additional REST API
via <code>http://[host:port]/[version]/submissions/[action]</code> where
<code>host</code> is the master host, and
<code>port</code> is the port number specified by `spark.master.rest.port` (default: 6066), and 
<code>version</code> is a protocol version, <code>v1</code> as of today, and
<code>action</code> is one of the following supported actions. <table class="spark-config">
  <thead><tr><th>Command</th><th>Description</th><th>HTTP METHOD</th><th>Since Version</th></tr></thead>
  <tr>
    <td><code>create</code></td>
    <td>Create a Spark driver via <code>cluster</code> mode. Since 4.0.0, Spark master supports server-side
      variable replacements for the values of Spark properties and environment variables. </td>
    <td>POST</td>
    <td>1.3.0</td>
  </tr>
  <tr>
    <td><code>kill</code></td>
    <td>Kill a single Spark driver.</td>
    <td>POST</td>
    <td>1.3.0</td>
  </tr>
  <tr>
    <td><code>killall</code></td>
    <td>Kill all running Spark drivers.</td>
    <td>POST</td>
    <td>4.0.0</td>
  </tr>
  <tr>
    <td><code>status</code></td>
    <td>Check the status of a Spark job.</td>
    <td>GET</td>
    <td>1.3.0</td>
  </tr>
  <tr>
    <td><code>clear</code></td>
    <td>Clear the completed drivers and applications.</td>
    <td>POST</td>
    <td>4.0.0</td>
  </tr>
</table>

The following is a <code>curl</code> CLI command example with the `pi.py` and REST API.