<code>org.apache.spark.io.LZ4CompressionCodec</code>,
    <code>org.apache.spark.io.LZFCompressionCodec</code>,
    <code>org.apache.spark.io.SnappyCompressionCodec</code>,
    and <code>org.apache.spark.io.ZStdCompressionCodec</code>. </td>
  <td>0.8.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.lz4.blockSize</code></td>
  <td>32k</td>
  <td>
    Block size used in LZ4 compression, in the case when LZ4 compression codec
    is used. Lowering this block size will also lower shuffle memory usage when LZ4 is used. Default unit is bytes, unless otherwise specified. This configuration only applies to
    <code>spark.io.compression.codec</code>. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.snappy.blockSize</code></td>
  <td>32k</td>
  <td>
    Block size in Snappy compression, in the case when Snappy compression codec is used. Lowering this block size will also lower shuffle memory usage when Snappy is used. Default unit is bytes, unless otherwise specified. This configuration only applies
    to <code>spark.io.compression.codec</code>. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.zstd.level</code></td>
  <td>1</td>
  <td>
    Compression level for Zstd compression codec. Increasing the compression level will result in better
    compression at the expense of more CPU and memory. This configuration only applies to
    <code>spark.io.compression.codec</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.zstd.bufferSize</code></td>
  <td>32k</td>
  <td>
    Buffer size in bytes used in Zstd compression, in the case when Zstd compression codec
    is used. Lowering this size will lower the shuffle memory usage when Zstd is used, but it
    might increase the compression cost because of excessive JNI call overhead. This
    configuration only applies to <code>spark.io.compression.codec</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.zstd.bufferPool.enabled</code></td>
  <td>true</td>
  <td>
    If true, enable buffer pool of ZSTD JNI library. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.zstd.workers</code></td>
  <td>0</td>
  <td>
    Thread size spawned to compress in parallel when using Zstd. When value is 0
    no worker is spawned, it works in single-threaded mode. When value > 0, it triggers
    asynchronous mode, corresponding number of threads are spawned. More workers improve
    performance, but also increase memory cost. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.io.compression.lzf.parallel.enabled</code></td>
  <td>false</td>
  <td>
    When true, LZF compression will use multiple threads to compress data in parallel.