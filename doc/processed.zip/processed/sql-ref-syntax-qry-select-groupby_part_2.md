For example,
    `GROUP BY warehouse, product WITH CUBE` or `GROUP BY CUBE(warehouse, product)` is equivalent to 
    `GROUP BY GROUPING SETS((warehouse, product), (warehouse), (product), ())`. `GROUP BY CUBE(warehouse, product, (warehouse, location))` is equivalent to
    `GROUP BY GROUPING SETS((warehouse, product, location), (warehouse, product), (warehouse, location),
     (product, warehouse, location), (warehouse), (product), (warehouse, product), ())`. The N elements of a `CUBE` specification results in 2^N `GROUPING SETS`. * **Mixed/Nested Grouping Analytics**

    A GROUP BY clause can include multiple `group_expression`s and multiple `CUBE|ROLLUP|GROUPING SETS`s. `GROUPING SETS` can also have nested `CUBE|ROLLUP|GROUPING SETS` clauses, e.g. `GROUPING SETS(ROLLUP(warehouse, location), CUBE(warehouse, location))`,
    `GROUPING SETS(warehouse, GROUPING SETS(location, GROUPING SETS(ROLLUP(warehouse, location), CUBE(warehouse, location))))`. `CUBE|ROLLUP` is just a syntax sugar for `GROUPING SETS`, please refer to the sections above for
    how to translate `CUBE|ROLLUP` to `GROUPING SETS`. `group_expression` can be treated as a single-group
    `GROUPING SETS` under this context. For multiple `GROUPING SETS` in the `GROUP BY` clause, we generate
    a single `GROUPING SETS` by doing a cross-product of the original `GROUPING SETS`s. For nested `GROUPING SETS` in the `GROUPING SETS` clause,
    we simply take its grouping sets and strip it. For example,
    `GROUP BY warehouse, GROUPING SETS((product), ()), GROUPING SETS((location, size), (location), (size), ())`
    and `GROUP BY warehouse, ROLLUP(product), CUBE(location, size)` is equivalent to 
    `GROUP BY GROUPING SETS(
        (warehouse, product, location, size), 
        (warehouse, product, location),
        (warehouse, product, size), 
        (warehouse, product),
        (warehouse, location, size),
        (warehouse, location),
        (warehouse, size),
        (warehouse))`. `GROUP BY GROUPING SETS(GROUPING SETS(warehouse), GROUPING SETS((warehouse, product)))` is equivalent to 
    `GROUP BY GROUPING SETS((warehouse), (warehouse, product))`. * **aggregate_name**

    Specifies an aggregate function name (MIN, MAX, COUNT, SUM, AVG, etc.). * **DISTINCT**

    Removes duplicates in input rows before they are passed to aggregate functions. * **FILTER**

    Filters the input rows for which the `boolean_expression` in the `WHERE` clause evaluates
    to true are passed to the aggregate function; other rows are discarded. ### Examples

```sql
CREATE TABLE dealer (id INT, city STRING, car_model STRING, quantity INT);
INSERT INTO dealer VALUES
    (100, 'Fremont', 'Honda Civic', 10),
    (100, 'Fremont', 'Honda Accord', 15),
    (100, 'Fremont', 'Honda CRV', 7),
    (200, 'Dublin', 'Honda Civic', 20),
    (200, 'Dublin', 'Honda Accord', 10),
    (200, 'Dublin', 'Honda CRV', 3),
    (300, 'San Jose', 'Honda Civic', 5),
    (300, 'San Jose', 'Honda Accord', 8);

-- Sum of quantity per dealership.