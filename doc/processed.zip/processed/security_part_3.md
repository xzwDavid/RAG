For encryption to be enabled, RPC
authentication must also be enabled and properly configured. AES encryption uses the
[Apache Commons Crypto](https://commons.apache.org/proper/commons-crypto/) library, and Spark's
configuration system allows access to that library's configuration for advanced users. This legacy protocol has two mutually incompatible versions. Version 1 omits applying key derivation function
(KDF) to the key exchange protocol's output, while version 2 applies a KDF to ensure that the derived session
key is uniformly distributed. Version 1 is default for backward compatibility. It is **recommended to use version 2**
for better security properties. The version can be configured by setting `spark.network.crypto.authEngineVersion` to
1 or 2 respectively. There is also support for SASL-based encryption, although it should be considered deprecated. It
is still required when talking to shuffle services from Spark versions older than 2.2.0. The following table describes the different options available for configuring this feature. <table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.network.crypto.enabled</code></td>
  <td>false</td>
  <td>
    Enable AES-based RPC encryption, including the new authentication protocol added in 2.2.0. </td>
  <td>2.2.0</td>
</tr>
<tr>
  <td><code>spark.network.crypto.cipher</code></td>
  <td>AES/CTR/NoPadding</td>
  <td>
    Cipher mode to use. Defaults "AES/CTR/NoPadding" for backward compatibility, which is not authenticated. Recommended to use "AES/GCM/NoPadding", which is an authenticated encryption mode. </td>
  <td>4.0.0, 3.5.2, 3.4.4</td>
</tr>
<tr>
  <td><code>spark.network.crypto.authEngineVersion</code></td>
  <td>1</td>
  <td>Version of AES-based RPC encryption to use. Valid versions are 1 or 2. Version 2 is recommended.</td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.network.crypto.config.*</code></td>
  <td>None</td>
  <td>
    Configuration values for the commons-crypto library, such as which cipher implementations to
    use. The config name should be the name of commons-crypto configuration without the
    <code>commons.crypto</code> prefix. </td>
  <td>2.2.0</td>
</tr>
<tr>
  <td><code>spark.network.crypto.saslFallback</code></td>
  <td>true</td>
  <td>
    Whether to fall back to SASL authentication if authentication fails using Spark's internal
    mechanism. This is useful when the application is connecting to old shuffle services that
    do not support the internal Spark authentication protocol. On the shuffle service side,
    disabling this feature will block older clients from authenticating. </td>
  <td>2.2.0</td>
</tr>
<tr>
  <td><code>spark.authenticate.enableSaslEncryption</code></td>
  <td>false</td>
  <td>
    Enable SASL-based encrypted communication. </td>
  <td>2.2.0</td>
</tr>
<tr>
  <td><code>spark.network.sasl.serverAlwaysEncrypt</code></td>
  <td>false</td>
  <td>
    Disable unencrypted connections for ports using SASL authentication. This will deny connections
    from clients that have authentication enabled, but do not request SASL-based encryption. </td>
  <td>1.4.0</td>
</tr>
</table>

# Local Storage Encryption

Spark supports encrypting temporary data written to local disks.