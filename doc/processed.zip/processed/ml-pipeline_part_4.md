I.e., if you save an ML
model or Pipeline in one version of Spark, then you should be able to load it back and use it in a
future version of Spark. However, there are rare exceptions, described below. Model persistence: Is a model or Pipeline saved using Apache Spark ML persistence in Spark
version X loadable by Spark version Y? * Major versions: No guarantees, but best-effort. * Minor and patch versions: Yes; these are backwards compatible. * Note about the format: There are no guarantees for a stable persistence format, but model loading itself is designed to be backwards compatible. Model behavior: Does a model or Pipeline in Spark version X behave identically in Spark version Y? * Major versions: No guarantees, but best-effort. * Minor and patch versions: Identical behavior, except for bug fixes. For both model persistence and model behavior, any breaking changes across a minor version or patch
version are reported in the Spark version release notes. If a breakage is not reported in release
notes, then it should be treated as a bug to be fixed. # Code examples

This section gives code examples illustrating the functionality discussed above. For more info, please refer to the API documentation
([Python](api/python/reference/pyspark.ml.html),
[Scala](api/scala/org/apache/spark/ml/package.html),
and [Java](api/java/org/apache/spark/ml/package-summary.html)). ## Example: Estimator, Transformer, and Param

This example covers the concepts of `Estimator`, `Transformer`, and `Param`. <div class="codetabs">

<div data-lang="python" markdown="1">

Refer to the [`Estimator` Python docs](api/python/reference/api/pyspark.ml.Estimator.html),
the [`Transformer` Python docs](api/python/reference/api/pyspark.ml.Transformer.html) and
the [`Params` Python docs](api/python/reference/api/pyspark.ml.param.Params.html) for more details on the API. {% include_example python/ml/estimator_transformer_param_example.py %}
</div>

<div data-lang="scala" markdown="1">

Refer to the [`Estimator` Scala docs](api/scala/org/apache/spark/ml/Estimator.html),
the [`Transformer` Scala docs](api/scala/org/apache/spark/ml/Transformer.html) and
the [`Params` Scala docs](api/scala/org/apache/spark/ml/param/Params.html) for details on the API. {% include_example scala/org/apache/spark/examples/ml/EstimatorTransformerParamExample.scala %}
</div>

<div data-lang="java" markdown="1">

Refer to the [`Estimator` Java docs](api/java/org/apache/spark/ml/Estimator.html),
the [`Transformer` Java docs](api/java/org/apache/spark/ml/Transformer.html) and
the [`Params` Java docs](api/java/org/apache/spark/ml/param/Params.html) for details on the API. {% include_example java/org/apache/spark/examples/ml/JavaEstimatorTransformerParamExample.java %}
</div>

</div>

## Example: Pipeline

This example follows the simple text document `Pipeline` illustrated in the figures above. <div class="codetabs">

<div data-lang="python" markdown="1">

Refer to the [`Pipeline` Python docs](api/python/reference/api/pyspark.ml.Pipeline.html) for more details on the API. {% include_example python/ml/pipeline_example.py %}
</div>

<div data-lang="scala" markdown="1">

Refer to the [`Pipeline` Scala docs](api/scala/org/apache/spark/ml/Pipeline.html) for details on the API.