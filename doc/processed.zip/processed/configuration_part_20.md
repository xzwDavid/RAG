</td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.eventLog.rolling.enabled</code></td>
  <td>false</td>
  <td>
    Whether rolling over event log files is enabled. If set to true, it cuts down each event
    log file to the configured size. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.eventLog.rolling.maxFileSize</code></td>
  <td>128m</td>
  <td>
    When <code>spark.eventLog.rolling.enabled=true</code>, specifies the max size of event log file before it's rolled over. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.ui.dagGraph.retainedRootRDDs</code></td>
  <td>Int.MaxValue</td>
  <td>
    How many DAG graph nodes the Spark UI and status APIs remember before garbage collecting. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.ui.groupSQLSubExecutionEnabled</code></td>
  <td>true</td>
  <td>
    Whether to group sub executions together in SQL UI when they belong to the same root execution
  </td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.ui.enabled</code></td>
  <td>true</td>
  <td>
    Whether to run the web UI for the Spark application. </td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.ui.store.path</code></td>
  <td>None</td>
  <td>
    Local directory where to cache application information for live UI. By default this is not set, meaning all application information will be kept in memory. </td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.ui.killEnabled</code></td>
  <td>true</td>
  <td>
    Allows jobs and stages to be killed from the web UI. </td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.ui.threadDumpsEnabled</code></td>
  <td>true</td>
  <td>
    Whether to show a link for executor thread dumps in Stages and Executor pages. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.ui.threadDump.flamegraphEnabled</code></td>
  <td>true</td>
  <td>
    Whether to render the Flamegraph for executor thread dumps. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.ui.heapHistogramEnabled</code></td>
  <td>true</td>
  <td>
    Whether to show a link for executor heap histogram in Executor page. </td>
  <td>3.5.0</td>
</tr>
<tr>
  <td><code>spark.ui.liveUpdate.period</code></td>
  <td>100ms</td>
  <td>
    How often to update live entities. -1 means "never update" when replaying applications,
    meaning only the last write will happen. For live applications, this avoids a few
    operations that we can live without when rapidly processing incoming task events.