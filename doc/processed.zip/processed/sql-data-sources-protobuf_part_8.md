Setting this option to <code>true</code>, <code>LongType</code> is used for <code>uint32</code> and <code>Decimal(20, 0)</code> is used for <code>uint64</code>, so their representation can contain large unsigned values without overflow.</td>
    <td>read</td>
  </tr>
  <tr>
    <td><code>unwrap.primitive.wrapper.types</code></td>
    <td><code>false</code></td>
    <td>Whether to unwrap the struct representation for well-known primitive wrapper types when deserializing. By default, the wrapper types for primitives (i.e. google.protobuf.Int32Value, google.protobuf.Int64Value, etc.) will get deserialized as structs.</td>
    <td>read</td>
  </tr>
  <tr>
    <td><code>retain.empty.message.types</code></td>
    <td><code>false</code></td>
    <td>Whether to retain fields of the empty proto message type in Schema. Since Spark doesn't allow writing empty <code>StructType</code>, the empty proto message type will be dropped by default. Setting this option to <code>true</code> will insert a dummy column(<code>__dummy_field_in_empty_struct</code>) to the empty proto message so that the empty message fields will be retained.</td>
    <td>read</td>
  </tr>
</table>
