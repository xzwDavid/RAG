{% include_example java/org/apache/spark/examples/ml/JavaALSExample.java %}

If the rating matrix is derived from another source of information (i.e. it is
inferred from other signals), you can set `implicitPrefs` to `true` to get
better results:

{% highlight java %}
ALS als = new ALS()
  .setMaxIter(5)
  .setRegParam(0.01)
  .setImplicitPrefs(true)
  .setUserCol("userId")
  .setItemCol("movieId")
  .setRatingCol("rating");
{% endhighlight %}

</div>

<div data-lang="r" markdown="1">

Refer to the [R API docs](api/R/reference/spark.als.html) for more details. {% include_example r/ml/als.R %}
</div>

</div>
