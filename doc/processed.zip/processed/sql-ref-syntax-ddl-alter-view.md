

### Description

The `ALTER VIEW` statement can alter metadata associated with the view. It can change the definition of the view, change
the name of a view to a different name, set and unset the metadata of the view by setting `TBLPROPERTIES`. #### RENAME View
Renames the existing view. If the new view name already exists in the source database, a `TableAlreadyExistsException` is thrown. This operation
does not support moving the views across databases. If the view is cached, the command clears cached data of the view and all its dependents that refer to it. View's cache will be lazily filled when the next time the view is accessed. The command leaves view's dependents as uncached. #### Syntax
```sql
ALTER VIEW view_identifier RENAME TO view_identifier
```

#### Parameters
* **view_identifier**

    Specifies a view name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] view_name`

#### SET View Properties
Set one or more properties of an existing view. The properties are the key value pairs. If the properties' keys exist, 
the values are replaced with the new values. If the properties' keys do not exist, the key value pairs are added into
the properties. #### Syntax
```sql
ALTER VIEW view_identifier SET TBLPROPERTIES ( property_key = property_val [ , ... ] )
```

#### Parameters
* **view_identifier**

    Specifies a view name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] view_name`

* **property_key**

    Specifies the property key. The key may consists of multiple parts separated by dot. **Syntax:** `[ key_part1 ] [ .key_part2 ] [ ... ]`

#### UNSET View Properties
Drop one or more properties of an existing view. If the specified keys do not exist, an exception is thrown. Use 
`IF EXISTS` to avoid the exception. #### Syntax
```sql
ALTER VIEW view_identifier UNSET TBLPROPERTIES [ IF EXISTS ]  ( property_key [ , ... ] )
```

#### Parameters
* **view_identifier**

    Specifies a view name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] view_name`

* **property_key**

    Specifies the property key. The key may consists of multiple parts separated by dot. **Syntax:** `[ key_part1 ] [ .key_part2 ] [ ... ]`

#### ALTER View AS SELECT
`ALTER VIEW view_identifier AS SELECT` statement changes the definition of a view. The `SELECT` statement must be valid,
and the `view_identifier` must exist. #### Syntax
```sql
ALTER VIEW view_identifier AS select_statement
```

Note that `ALTER VIEW` statement does not support `SET SERDE` or `SET SERDEPROPERTIES` properties. #### Parameters
* **view_identifier**

    Specifies a view name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] view_name`

* **select_statement**

    Specifies the definition of the view. Check [select_statement](sql-ref-syntax-qry-select.html) for details. #### ALTER View WITH SCHEMA

Changes the view's schema binding behavior. If the view is cached, the command clears cached data of the view and all its dependents that refer to it. View's cache will be lazily filled when the next time the view is accessed. The command leaves view's dependents as uncached. This statement is not supported for `TEMPORARY` views. #### Syntax
```sql
ALTER VIEW view_identifier WITH SCHEMA { BINDING | COMPENSATION | [ TYPE ] EVOLUTION }
```

#### Parameters
* **view_identifier**

  Specifies a view name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] view_name`

* **BINDING** - The view can tolerate only type changes in the underlying schema requiring safe up-casts.