

### Description

`SHOW TABLE EXTENDED` will show information for all tables matching the given regular expression. Output includes basic table information and file system information like `Last Access`, 
`Created By`, `Type`, `Provider`, `Table Properties`, `Location`, `Serde Library`, `InputFormat`, 
`OutputFormat`, `Storage Properties`, `Partition Provider`, `Partition Columns` and `Schema`. If a partition specification is present, it outputs the given partition's file-system-specific 
information such as `Partition Parameters` and `Partition Statistics`. Note that a table regex 
cannot be used with a partition specification. ### Syntax

```sql
SHOW TABLE EXTENDED [ { IN | FROM } database_name ] LIKE regex_pattern
    [ partition_spec ]
```

### Parameters

* **{ IN`|`FROM } database_name**

    Specifies database name. If not provided, will use the current database. * **regex_pattern**

    Specifies the regular expression pattern that is used to filter out unwanted tables. * Except for `*` and `|` character, the pattern works like a regular expression. * `*` alone matches 0 or more characters and `|` is used to separate multiple different regular expressions,
      any of which can match. * The leading and trailing blanks are trimmed in the input pattern before processing. The pattern match is case-insensitive. * **partition_spec**

    An optional parameter that specifies a comma separated list of key and value pairs
    for partitions. Note that a table regex cannot be used with a partition specification. **Syntax:** `PARTITION ( partition_col_name = partition_col_val [ , ... ] )`

### Examples

```sql
-- Assumes `employee` table created with partitioned by column `grade`
CREATE TABLE employee(name STRING, grade INT) PARTITIONED BY (grade);
INSERT INTO employee PARTITION (grade = 1) VALUES ('sam');
INSERT INTO employee PARTITION (grade = 2) VALUES ('suj');

 -- Show the details of the table
SHOW TABLE EXTENDED LIKE 'employee';
+