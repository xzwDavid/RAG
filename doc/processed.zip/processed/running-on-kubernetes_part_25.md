</td>
  <td>3.1.1</td>
</tr>
<tr>
  <td><code>spark.kubernetes.decommission.script</code></td>
  <td><code>/opt/decom.sh</code></td>
  <td>
    The location of the script to use for graceful decommissioning. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.service.deleteOnTermination</code></td>
  <td><code>true</code></td>
  <td>
    If true, driver service will be deleted on Spark application termination. If false, it will be cleaned up when the driver pod is deletion. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.service.ipFamilyPolicy</code></td>
  <td><code>SingleStack</code></td>
  <td>
    K8s IP Family Policy for Driver Service. Valid values are
    <code>SingleStack</code>, <code>PreferDualStack</code>, and <code>RequireDualStack</code>. </td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.service.ipFamilies</code></td>
  <td><code>IPv4</code></td>
  <td>
    A list of IP families for K8s Driver Service. Valid values are
    <code>IPv4</code> and <code>IPv6</code>. </td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.ownPersistentVolumeClaim</code></td>
  <td><code>true</code></td>
  <td>
    If true, driver pod becomes the owner of on-demand persistent volume claims instead of the executor pods
  </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.reusePersistentVolumeClaim</code></td>
  <td><code>true</code></td>
  <td>
    If true, driver pod tries to reuse driver-owned on-demand persistent volume claims
    of the deleted executor pods if exists. This can be useful to reduce executor pod
    creation delay by skipping persistent volume creations. Note that a pod in
    `Terminating` pod status is not a deleted pod by definition and its resources
    including persistent volume claims are not reusable yet. Spark will create new
    persistent volume claims when there exists no reusable one. In other words, the total
    number of persistent volume claims can be larger than the number of running executors
    sometimes. This config requires <code>spark.kubernetes.driver.ownPersistentVolumeClaim=true.</code>
  </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.waitToReusePersistentVolumeClaim</code></td>
  <td><code>false</code></td>
  <td>
    If true, driver pod counts the number of created on-demand persistent volume claims
    and wait if the number is greater than or equal to the total number of volumes which
    the Spark job is able to have.