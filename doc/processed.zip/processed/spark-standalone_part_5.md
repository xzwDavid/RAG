Older drivers will be dropped from the UI to maintain this limit.<br/>
  </td>
  <td>1.1.0</td>
</tr>
<tr>
  <td><code>spark.deploy.spreadOutDrivers</code></td>
  <td>true</td>
  <td>
    Whether the standalone cluster manager should spread drivers out across nodes or try
    to consolidate them onto as few nodes as possible. Spreading out is usually better for
    data locality in HDFS, but consolidating is more efficient for compute-intensive workloads. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.deploy.spreadOutApps</code></td>
  <td>true</td>
  <td>
    Whether the standalone cluster manager should spread applications out across nodes or try
    to consolidate them onto as few nodes as possible. Spreading out is usually better for
    data locality in HDFS, but consolidating is more efficient for compute-intensive workloads. <br/>
  </td>
  <td>0.6.1</td>
</tr>
<tr>
  <td><code>spark.deploy.defaultCores</code></td>
  <td>Int.MaxValue</td>
  <td>
    Default number of cores to give to applications in Spark's standalone mode if they don't
    set <code>spark.cores.max</code>. If not set, applications always get all available
    cores unless they configure <code>spark.cores.max</code> themselves. Set this lower on a shared cluster to prevent users from grabbing
    the whole cluster by default. <br/>
  </td>
  <td>0.9.0</td>
</tr>
<tr>
  <td><code>spark.deploy.maxExecutorRetries</code></td>
  <td>10</td>
  <td>
    Limit on the maximum number of back-to-back executor failures that can occur before the
    standalone cluster manager removes a faulty application. An application will never be removed
    if it has any running executors. If an application experiences more than
    <code>spark.deploy.maxExecutorRetries</code> failures in a row, no executors
    successfully start running in between those failures, and the application has no running
    executors then the standalone cluster manager will remove the application and mark it as failed. To disable this automatic removal, set <code>spark.deploy.maxExecutorRetries</code> to
    <code>-1</code>. <br/>
  </td>
  <td>1.6.3</td>
</tr>
<tr>
  <td><code>spark.deploy.maxDrivers</code></td>
  <td>Int.MaxValue</td>
  <td>
    The maximum number of running drivers. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.deploy.appNumberModulo</code></td>
  <td>(None)</td>
  <td>
    The modulo for app number. By default, the next of `app-yyyyMMddHHmmss-9999` is
    `app-yyyyMMddHHmmss-10000`. If we have 10000 as modulo, it will be `app-yyyyMMddHHmmss-0000`. In most cases, the prefix `app-yyyyMMddHHmmss` is increased already during creating 10000 applications. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.deploy.driverIdPattern</code></td>
  <td>driver-%s-%04d</td>
  <td>
    The pattern for driver ID generation based on Java `String.format` method. The default value is `driver-%s-%04d` which represents the existing driver id string, e.g., `driver-20231031224459-0019`. Please be careful to generate unique IDs.