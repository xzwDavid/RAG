</td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.scheduler.mode</code></td>
  <td>FIFO</td>
  <td>
    The <a href="job-scheduling.html#scheduling-within-an-application">scheduling mode</a> between
    jobs submitted to the same SparkContext. Can be set to <code>FAIR</code>
    to use fair sharing instead of queueing jobs one after another. Useful for
    multi-user services. </td>
  <td>0.8.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.revive.interval</code></td>
  <td>1s</td>
  <td>
    The interval length for the scheduler to revive the worker resource offers to run tasks. </td>
  <td>0.8.1</td>
</tr>
<tr>
  <td><code>spark.scheduler.listenerbus.eventqueue.capacity</code></td>
  <td>10000</td>
  <td>
    The default capacity for event queues. Spark will try to initialize an event queue
    using capacity specified by <code>spark.scheduler.listenerbus.eventqueue.queueName.capacity</code>
    first. If it's not configured, Spark will use the default capacity specified by this
    config. Note that capacity must be greater than 0. Consider increasing value (e.g. 20000)
    if listener events are dropped. Increasing this value may result in the driver using more memory. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.listenerbus.eventqueue.shared.capacity</code></td>
  <td><code>spark.scheduler.listenerbus.eventqueue.capacity</code></td>
  <td>
    Capacity for shared event queue in Spark listener bus, which hold events for external listener(s)
    that register to the listener bus. Consider increasing value, if the listener events corresponding
    to shared queue are dropped. Increasing this value may result in the driver using more memory. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.listenerbus.eventqueue.appStatus.capacity</code></td>
  <td><code>spark.scheduler.listenerbus.eventqueue.capacity</code></td>
  <td>
    Capacity for appStatus event queue, which hold events for internal application status listeners. Consider increasing value, if the listener events corresponding to appStatus queue are dropped. Increasing this value may result in the driver using more memory. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.listenerbus.eventqueue.executorManagement.capacity</code></td>
  <td><code>spark.scheduler.listenerbus.eventqueue.capacity</code></td>
  <td>
    Capacity for executorManagement event queue in Spark listener bus, which hold events for internal
    executor management listeners. Consider increasing value if the listener events corresponding to
    executorManagement queue are dropped. Increasing this value may result in the driver using more memory. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.listenerbus.eventqueue.eventLog.capacity</code></td>
  <td><code>spark.scheduler.listenerbus.eventqueue.capacity</code></td>
  <td>
    Capacity for eventLog queue in Spark listener bus, which hold events for Event logging listeners
    that write events to eventLogs. Consider increasing value if the listener events corresponding to eventLog queue
    are dropped. Increasing this value may result in the driver using more memory.