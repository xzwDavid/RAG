</td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.io.numConnectionsPerPeer</code></td>
  <td>1</td>
  <td>
    (Netty only) Connections between hosts are reused in order to reduce connection buildup for
    large clusters. For clusters with many hard disks and few hosts, this may result in insufficient
    concurrency to saturate all disks, and so users may consider increasing this value. </td>
  <td>1.2.1</td>
</tr>
<tr>
  <td><code>spark.shuffle.io.preferDirectBufs</code></td>
  <td>true</td>
  <td>
    (Netty only) Off-heap buffers are used to reduce garbage collection during shuffle and cache
    block transfer. For environments where off-heap memory is tightly limited, users may wish to
    turn this off to force all allocations from Netty to be on-heap. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.io.retryWait</code></td>
  <td>5s</td>
  <td>
    (Netty only) How long to wait between retries of fetches. The maximum delay caused by retrying
    is 15 seconds by default, calculated as <code>maxRetries * retryWait</code>. </td>
  <td>1.2.1</td>
</tr>
<tr>
  <td><code>spark.shuffle.io.backLog</code></td>
  <td>-1</td>
  <td>
    Length of the accept queue for the shuffle service. For large applications, this value may
    need to be increased, so that incoming connections are not dropped if the service cannot keep
    up with a large number of connections arriving in a short period of time. This needs to
    be configured wherever the shuffle service itself is running, which may be outside of the
    application (see <code>spark.shuffle.service.enabled</code> option below). If set below 1,
    will fallback to OS default defined by Netty's <code>io.netty.util.NetUtil#SOMAXCONN</code>. </td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.shuffle.io.connectionTimeout</code></td>
  <td>value of <code>spark.network.timeout</code></td>
  <td>
    Timeout for the established connections between shuffle servers and clients to be marked
    as idled and closed if there are still outstanding fetch requests but no traffic no the channel
    for at least <code>connectionTimeout</code>. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.io.connectionCreationTimeout</code></td>
  <td>value of <code>spark.shuffle.io.connectionTimeout</code></td>
  <td>
    Timeout for establishing a connection between the shuffle servers and clients. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.service.enabled</code></td>
  <td>false</td>
  <td>
    Enables the external shuffle service. This service preserves the shuffle files written by
    executors e.g. so that executors can be safely removed, or so that shuffle fetches can continue in
    the event of executor failure. The external shuffle service must be set up in order to enable it. See
    <a href="job-scheduling.html#configuration-and-setup">dynamic allocation
    configuration and setup documentation</a> for more information.