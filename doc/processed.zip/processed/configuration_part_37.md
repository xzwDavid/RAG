</td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.listenerbus.eventqueue.streams.capacity</code></td>
  <td><code>spark.scheduler.listenerbus.eventqueue.capacity</code></td>
  <td>
    Capacity for streams queue in Spark listener bus, which hold events for internal streaming listener. Consider increasing value if the listener events corresponding to streams queue are dropped. Increasing
    this value may result in the driver using more memory. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.resource.profileMergeConflicts</code></td>
  <td>false</td>
  <td>
    If set to "true", Spark will merge ResourceProfiles when different profiles are specified
    in RDDs that get combined into a single stage. When they are merged, Spark chooses the maximum of
    each resource and creates a new ResourceProfile. The default of false results in Spark throwing
    an exception if multiple different ResourceProfiles are found in RDDs going into the same stage. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.excludeOnFailure.unschedulableTaskSetTimeout</code></td>
  <td>120s</td>
  <td>
    The timeout in seconds to wait to acquire a new executor and schedule a task before aborting a
    TaskSet which is unschedulable because all executors are excluded due to task failures. </td>
  <td>2.4.1</td>
</tr>
<tr>
  <td><code>spark.standalone.submit.waitAppCompletion</code></td>
  <td>false</td>
  <td>
    If set to true, Spark will merge ResourceProfiles when different profiles are specified in RDDs that get combined into a single stage. When they are merged, Spark chooses the maximum of each resource and creates a new ResourceProfile. The default of false results in Spark throwing an exception if multiple different ResourceProfiles are found in RDDs going into the same stage. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.excludeOnFailure.enabled</code></td>
  <td>
    false
  </td>
  <td>
    If set to "true", prevent Spark from scheduling tasks on executors that have been excluded
    due to too many task failures. The algorithm used to exclude executors and nodes can be further
    controlled by the other "spark.excludeOnFailure" configuration options. This config will be overriden by "spark.excludeOnFailure.application.enabled" and 
    "spark.excludeOnFailure.taskAndStage.enabled" to specify exclusion enablement on individual
    levels. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.excludeOnFailure.application.enabled</code></td>
  <td>
    false
  </td>
  <td>
    If set to "true", enables excluding executors for the entire application due to too many task
    failures and prevent Spark from scheduling tasks on them. This config overrides "spark.excludeOnFailure.enabled". </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.excludeOnFailure.taskAndStage.enabled</code></td>
  <td>
    false
  </td>
  <td>
    If set to "true", enables excluding executors on a task set level due to too many task
    failures and prevent Spark from scheduling tasks on them. This config overrides "spark.excludeOnFailure.enabled".