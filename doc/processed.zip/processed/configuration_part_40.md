</td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.speculation.efficiency.longRunTaskFactor</code></td>
  <td>2</td>
  <td>
    A task will be speculated anyway as long as its duration has exceeded the value of multiplying
    the factor and the time threshold (either be <code>spark.speculation.multiplier</code>
    * successfulTaskDurations.median or <code>spark.speculation.minTaskRuntime</code>) regardless
    of it's data process rate is good or not. This avoids missing the inefficient tasks when task
    slow isn't related to data process rate. </td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.speculation.efficiency.enabled</code></td>
  <td>true</td>
  <td>
    When set to true, spark will evaluate the efficiency of task processing through the stage task
    metrics or its duration, and only need to speculate the inefficient tasks. A task is inefficient
    when 1)its data process rate is less than the average data process rate of all successful tasks
    in the stage multiplied by a multiplier or 2)its duration has exceeded the value of multiplying
     <code>spark.speculation.efficiency.longRunTaskFactor</code> and the time threshold (either be
     <code>spark.speculation.multiplier</code> * successfulTaskDurations.median or
    <code>spark.speculation.minTaskRuntime</code>). </td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.task.cpus</code></td>
  <td>1</td>
  <td>
    Number of cores to allocate for each task. </td>
  <td>0.5.0</td>
</tr>
<tr>
  <td><code>spark.task.resource.{resourceName}.amount</code></td>
  <td>1</td>
  <td>
    Amount of a particular resource type to allocate for each task, note that this can be a double. If this is specified you must also provide the executor config
    <code>spark.executor.resource.{resourceName}.amount</code> and any corresponding discovery configs
    so that your executors are created with that resource type. In addition to whole amounts,
    a fractional amount (for example, 0.25, which means 1/4th of a resource) may be specified. Fractional amounts must be less than or equal to 0.5, or in other words, the minimum amount of
    resource sharing is 2 tasks per resource. Additionally, fractional amounts are floored
    in order to assign resource slots (e.g. a 0.2222 configuration, or 1/0.2222 slots will become
    4 tasks/resource, not 5). </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.task.maxFailures</code></td>
  <td>4</td>
  <td>
    Number of continuous failures of any particular task before giving up on the job. The total number of failures spread across different tasks will not cause the job
    to fail; a particular task has to fail this number of attempts continuously. If any attempt succeeds, the failure count for the task will be reset. Should be greater than or equal to 1. Number of allowed retries = this value - 1. </td>
  <td>0.8.0</td>
</tr>
<tr>
  <td><code>spark.task.reaper.enabled</code></td>
  <td>false</td>
  <td>
    Enables monitoring of killed / interrupted tasks. When set to true, any task which is killed
    will be monitored by the executor until that task actually finishes executing. See the other
    <code>spark.task.reaper.*</code> configurations for details on how to control the exact behavior
    of this monitoring.