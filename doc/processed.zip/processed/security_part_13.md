The following options provides finer-grained control for this feature:

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.security.credentials.${service}.enabled</code></td>
  <td><code>true</code></td>
  <td>
    Controls whether to obtain credentials for services when security is enabled. By default, credentials for all supported services are retrieved when those services are
    configured, but it's possible to disable that behavior if it somehow conflicts with the
    application being run. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kerberos.access.hadoopFileSystems</code></td>
  <td>(none)</td>
  <td>
    A comma-separated list of secure Hadoop filesystems your Spark application is going to access. For
    example, <code>spark.kerberos.access.hadoopFileSystems=hdfs://nn1.com:8032,hdfs://nn2.com:8032,
    webhdfs://nn3.com:50070</code>. The Spark application must have access to the filesystems listed
    and Kerberos must be properly configured to be able to access them (either in the same realm
    or in a trusted realm). Spark acquires security tokens for each of the filesystems so that
    the Spark application can access those remote Hadoop filesystems. </td>
  <td>3.0.0</td>
</tr>
</table>

Users can exclude Kerberos delegation token renewal at resource scheduler. Currently it is only supported
on YARN. The configuration is covered in the [Running Spark on YARN](running-on-yarn.html#yarn-specific-kerberos-configuration) page. ## Long-Running Applications

Long-running applications may run into issues if their run time exceeds the maximum delegation
token lifetime configured in services it needs to access. This feature is not available everywhere. In particular, it's only implemented
on YARN and Kubernetes (both client and cluster modes). Spark supports automatically creating new tokens for these applications. There are two ways to
enable this functionality. ### Using a Keytab

By providing Spark with a principal and keytab (e.g. using `spark-submit` with `--principal`
and `--keytab` parameters), the application will maintain a valid Kerberos login that can be
used to retrieve delegation tokens indefinitely. Note that when using a keytab in cluster mode, it will be copied over to the machine running the
Spark driver. In the case of YARN, this means using HDFS as a staging area for the keytab, so it's
strongly recommended that both YARN and HDFS be secured with encryption, at least. ### Using a ticket cache

By setting `spark.kerberos.renewal.credentials` to `ccache` in Spark's configuration, the local
Kerberos ticket cache will be used for authentication. Spark will keep the ticket renewed during its
renewable life, but after it expires a new ticket needs to be acquired (e.g. by running `kinit`). It's up to the user to maintain an updated ticket cache that Spark can use. The location of the ticket cache can be customized by setting the `KRB5CCNAME` environment
variable. ## Secure Interaction with Kubernetes

When talking to Hadoop-based services behind Kerberos, it was noted that Spark needs to obtain delegation tokens
so that non-local processes can authenticate. These delegation tokens in Kubernetes are stored in Secrets that are
shared by the Driver and its Executors. As such, there are three ways of submitting a Kerberos job:

In all cases you must define the environment variable: `HADOOP_CONF_DIR` or
`spark.kubernetes.hadoop.configMapName.`

It also important to note that the KDC needs to be visible from inside the containers.