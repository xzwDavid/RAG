

### Description

A SQL join is used to combine rows from two relations based on join criteria. The following section describes the overall join syntax and the sub-sections cover different types of joins along with examples. ### Syntax

```sql
relation { [ join_type ] JOIN [ LATERAL ] relation [ join_criteria ] | NATURAL join_type JOIN [ LATERAL ] relation }
```

### Parameters

* **relation**

    Specifies the relation to be joined. * **join_type**

    Specifies the join type. **Syntax:**

    `[ INNER ] | CROSS | LEFT [ OUTER ] | [ LEFT ] SEMI | RIGHT [ OUTER ] | FULL [ OUTER ] | [ LEFT ] ANTI`

* **join_criteria**

    Specifies how the rows from one relation will be combined with the rows of another relation. **Syntax:** `ON boolean_expression | USING ( column_name [ , ... ] )`

    `boolean_expression`

    Specifies an expression with a return type of boolean. ### Join Types

#### **Inner Join**

The inner join is the default join in Spark SQL. It selects rows that have matching values in both relations. **Syntax:**

`relation [ INNER ] JOIN relation [ join_criteria ]`

#### **Left Join**

A left join returns all values from the left relation and the matched values from the right relation, or appends NULL if there is no match. It is also referred to as a left outer join. **Syntax:**

`relation LEFT [ OUTER ] JOIN relation [ join_criteria ]`

#### **Right Join**

A right join returns all values from the right relation and the matched values from the left relation, or appends NULL if there is no match. It is also referred to as a right outer join. **Syntax:**

`relation RIGHT [ OUTER ] JOIN relation [ join_criteria ]`

#### **Full Join**

A full join returns all values from both relations, appending NULL values on the side that does not have a match. It is also referred to as a full outer join. **Syntax:**

`relation FULL [ OUTER ] JOIN relation [ join_criteria ]`

#### **Cross Join**

A cross join returns the Cartesian product of two relations. **Syntax:**

`relation CROSS JOIN relation [ join_criteria ]`

#### **Semi Join**

A semi join returns values from the left side of the relation that has a match with the right. It is also referred to as a left semi join. **Syntax:**

`relation [ LEFT ] SEMI JOIN relation [ join_criteria ]`

#### **Anti Join**

An anti join returns values from the left relation that has no match with the right. It is also referred to as a left anti join. **Syntax:**

`relation [ LEFT ] ANTI JOIN relation [ join_criteria ]`

### Examples

```sql
-- Use employee and department tables to demonstrate different type of joins. SELECT * FROM employee;
+