<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.authenticate.secret.file</code></td>
  <td>None</td>
  <td>
    Path pointing to the secret key to use for securing connections. Ensure that the
    contents of the file have been securely generated. This file is loaded on both the driver
    and the executors unless other settings override this (see below). </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.authenticate.secret.driver.file</code></td>
  <td>The value of <code>spark.authenticate.secret.file</code></td>
  <td>
    When specified, overrides the location that the Spark driver reads to load the secret. Useful when in client mode, when the location of the secret file may differ in the pod versus
    the node the driver is running in. When this is specified,
    <code>spark.authenticate.secret.executor.file</code> must be specified so that the driver
    and the executors can both use files to load the secret key. Ensure that the contents of the file
    on the driver is identical to the contents of the file on the executors. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.authenticate.secret.executor.file</code></td>
  <td>The value of <code>spark.authenticate.secret.file</code></td>
  <td>
    When specified, overrides the location that the Spark executors read to load the secret. Useful in client mode, when the location of the secret file may differ in the pod versus
    the node the driver is running in. When this is specified,
    <code>spark.authenticate.secret.driver.file</code> must be specified so that the driver
    and the executors can both use files to load the secret key. Ensure that the contents of the file
    on the driver is identical to the contents of the file on the executors. </td>
  <td>3.0.0</td>
</tr>
</table>

Note that when using files, Spark will not mount these files into the containers for you. It is up
you to ensure that the secret files are deployed securely into your containers and that the driver's
secret file agrees with the executors' secret file. # Network Encryption

Spark supports two mutually exclusive forms of encryption for RPC connections:

The **preferred method** uses TLS (aka SSL) encryption via Netty's support for SSL. Enabling SSL
requires keys and certificates to be properly configured. SSL is standardized and considered more
secure. The legacy method is an AES-based encryption mechanism relying on a shared secret. This requires
RPC authentication to also be enabled. This method uses a bespoke protocol and it is recommended
to use SSL instead. One may prefer to use the SSL based encryption in scenarios where compliance mandates the usage
of specific protocols; or to leverage the security of a more standard encryption library. However,
the AES based encryption is simpler to configure and may be preferred if the only requirement
is that data be encrypted in transit. If both options are enabled in the configuration, the SSL based RPC encryption takes precedence
and the AES based encryption will not be used (and a warning message will be emitted). ## SSL Encryption (Preferred)

Spark supports SSL based encryption for RPC connections. Please refer to the SSL Configuration
section below to understand how to configure it. The SSL settings are mostly similar across the UI
and RPC, however there are a few additional settings which are specific to the RPC implementation. The RPC implementation uses Netty under the hood (while the UI uses Jetty), which supports a
different set of options. Unlike the other SSL settings for the UI, the RPC SSL is *not* automatically enabled if
`spark.ssl.enabled` is set. It must be explicitly enabled, to ensure a safe migration path for users
upgrading Spark versions. ## AES-based Encryption (Legacy)

Spark supports AES-based encryption for RPC connections.