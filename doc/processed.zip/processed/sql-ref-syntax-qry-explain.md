

### Description

The `EXPLAIN` statement is used to provide logical/physical plans for an input statement. By default, this clause provides information about a physical plan only. ### Syntax

```sql
EXPLAIN [ EXTENDED | CODEGEN | COST | FORMATTED ] statement
```

### Parameters

* **EXTENDED**

    Generates parsed logical plan, analyzed logical plan, optimized logical plan and physical plan. Parsed Logical plan is a unresolved plan that extracted from the query. Analyzed logical plans transforms which translates unresolvedAttribute and unresolvedRelation into fully typed objects. The optimized logical plan transforms through a set of optimization rules, resulting in the physical plan. * **CODEGEN**

    Generates code for the statement, if any and a physical plan. * **COST**

    If plan node statistics are available, generates a logical plan and the statistics. * **FORMATTED**

    Generates two sections: a physical plan outline and node details. * **statement**

    Specifies a SQL statement to be explained. ### Examples

```sql
-- Default Output
EXPLAIN select k, sum(v) from values (1, 2), (1, 3) t(k, v) group by k;
+