</td>
  <td>1.3.0</td>
</tr>
<tr>
  <td><code>spark.yarn.am.attemptFailuresValidityInterval</code></td>
  <td>(none)</td>
  <td>
  Defines the validity interval for AM failure tracking. If the AM has been running for at least the defined interval, the AM failure count will be reset. This feature is not enabled if not configured. </td>
  <td>1.6.0</td>
</tr>
<tr>
  <td><code>spark.yarn.am.clientModeTreatDisconnectAsFailed</code></td>
  <td>false</td>
  <td>
  Treat yarn-client unclean disconnects as failures. In yarn-client mode, normally the application will always finish
  with a final status of SUCCESS because in some cases, it is not possible to know if the Application was terminated
  intentionally by the user or if there was a real error. This config changes that behavior such that if the Application
  Master disconnects from the driver uncleanly (ie without the proper shutdown handshake) the application will
  terminate with a final status of FAILED. This will allow the caller to decide if it was truly a failure. Note that if
  this config is set and the user just terminate the client application badly it may show a status of FAILED when it wasn't really FAILED. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.yarn.am.clientModeExitOnError</code></td>
  <td>false</td>
  <td>
  In yarn-client mode, when this is true, if driver got application report with final status of KILLED or FAILED,
  driver will stop corresponding SparkContext and exit program with code 1. Note, if this is true and called from another application, it will terminate the parent application as well. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.yarn.am.tokenConfRegex</code></td>
  <td>(none)</td>
  <td>
    The value of this config is a regex expression used to grep a list of config entries from the job's configuration file (e.g., hdfs-site.xml)
    and send to RM, which uses them when renewing delegation tokens. A typical use case of this feature is to support delegation
    tokens in an environment where a YARN cluster needs to talk to multiple downstream HDFS clusters, where the YARN RM may not have configs
    (e.g., dfs.nameservices, dfs.ha.namenodes.*, dfs.namenode.rpc-address.*) to connect to these clusters. In this scenario, Spark users can specify the config value to be <code>^dfs.nameservices\$|^dfs.namenode.rpc-address.*\$|^dfs.ha.namenodes.*\$</code> to parse
    these HDFS configs from the job's local configuration files. This config is very similar to <code>mapreduce.job.send-token-conf</code>. Please check YARN-5910 for more details. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.yarn.submit.waitAppCompletion</code></td>
  <td><code>true</code></td>
  <td>
  In YARN cluster mode, controls whether the client waits to exit until the application completes. If set to <code>true</code>, the client process will stay alive reporting the application's status. Otherwise, the client process will exit after submission. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.yarn.am.nodeLabelExpression</code></td>
  <td>(none)</td>
  <td>
  A YARN node label expression that restricts the set of nodes AM will be scheduled on. Only versions of YARN greater than or equal to 2.6 support node label expressions, so when
  running against earlier versions, this property will be ignored.