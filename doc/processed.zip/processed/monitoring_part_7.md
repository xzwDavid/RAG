<br>
    <code>?status=[completed|running]</code> list only applications in the chosen state. <br>
    <code>?minDate=[date]</code> earliest start date/time to list. <br>
    <code>?maxDate=[date]</code> latest start date/time to list. <br>
    <code>?minEndDate=[date]</code> earliest end date/time to list. <br>
    <code>?maxEndDate=[date]</code> latest end date/time to list. <br>
    <code>?limit=[limit]</code> limits the number of applications listed. <br>Examples:
    <br><code>?minDate=2015-02-10</code>
    <br><code>?minDate=2015-02-03T16:42:40.000GMT</code>
    <br><code>?maxDate=2015-02-11T20:41:30.000GMT</code>
    <br><code>?minEndDate=2015-02-12</code>
    <br><code>?minEndDate=2015-02-12T09:15:10.000GMT</code>
    <br><code>?maxEndDate=2015-02-14T16:30:45.000GMT</code>
    <br><code>?limit=10</code></td>
  </tr>
  <tr>
    <td><code>/applications/[app-id]/jobs</code></td>
    <td>
      A list of all jobs for a given application. <br><code>?status=[running|succeeded|failed|unknown]</code> list only jobs in the specific state. </td>
  </tr>
  <tr>
    <td><code>/applications/[app-id]/jobs/[job-id]</code></td>
    <td>Details for the given job.</td>
  </tr>
  <tr>
    <td><code>/applications/[app-id]/stages</code></td>
    <td>
      A list of all stages for a given application. <br><code>?status=[active|complete|pending|failed]</code> list only stages in the given state. <br><code>?details=true</code> lists all stages with the task data. <br><code>?taskStatus=[RUNNING|SUCCESS|FAILED|KILLED|PENDING]</code> lists only those tasks with the specified task status. Query parameter taskStatus takes effect only when <code>details=true</code>. This also supports multiple <code>taskStatus</code> such as <code>?details=true&taskStatus=SUCCESS&taskStatus=FAILED</code> which will return all tasks matching any of specified task status. <br><code>?withSummaries=true</code> lists stages with task metrics distribution and executor metrics distribution. <br><code>?quantiles=0.0,0.25,0.5,0.75,1.0</code> summarize the metrics with the given quantiles. Query parameter quantiles takes effect only when <code>withSummaries=true</code>. Default value is <code>0.0,0.25,0.5,0.75,1.0</code>. </td>
  </tr>
  <tr>
    <td><code>/applications/[app-id]/stages/[stage-id]</code></td>
    <td>
      A list of all attempts for the given stage. <br><code>?details=true</code> lists all attempts with the task data for the given stage. <br><code>?taskStatus=[RUNNING|SUCCESS|FAILED|KILLED|PENDING]</code> lists only those tasks with the specified task status. Query parameter taskStatus takes effect only when <code>details=true</code>.