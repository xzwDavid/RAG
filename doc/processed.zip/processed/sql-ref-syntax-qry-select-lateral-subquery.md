

### Description

`LATERAL SUBQUERY` is a subquery that is preceded by the keyword `LATERAL`. It provides a way to reference columns in the preceding `FROM` clause. Without the `LATERAL` keyword, subqueries can only refer to columns in the outer query, but not in the `FROM` clause. `LATERAL SUBQUERY` makes the complicated
queries simpler and more efficient. ### Syntax

```sql
[ LATERAL ] primary_relation [ join_relation ]
```

### Parameters

* **primary_relation**

  Specifies the primary relation. It can be one of the following:
  * Table relation
  * Aliased query

    Syntax: `( query ) [ [ AS ] alias ]`
  * Aliased relation

    Syntax: `( relation ) [ [ AS ] alias ]`
  * [Table-value function](sql-ref-syntax-qry-select-tvf.html)
  * [Inline table](sql-ref-syntax-qry-select-inline-table.html)


* **join_relation**

    Specifies a [Join relation](sql-ref-syntax-qry-select-join.html). ### Examples

```sql
CREATE TABLE t1 (c1 INT, c2 INT);
INSERT INTO t1 VALUES (0, 1), (1, 2);

CREATE TABLE t2 (c1 INT, c2 INT);
INSERT INTO t2 VALUES (0, 2), (0, 3);

SELECT * FROM t1,
  LATERAL (SELECT * FROM t2 WHERE t1.c1 = t2.c1);
+