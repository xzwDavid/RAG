</td>
  <td>2.0.2</td>
</tr>
<tr>
  <td><code>spark.worker.idPattern</code></td>
  <td>worker-%s-%s-%d</td>
  <td>
    The pattern for worker ID generation based on Java `String.format` method. The default value is `worker-%s-%s-%d` which represents the existing worker id string, e.g.,
    `worker-20231109183042-[fe80::1%lo0]-39729`. Please be careful to generate unique IDs
  </td>
  <td>4.0.0</td>
</tr>
</table>

# Resource Allocation and Configuration Overview

Please make sure to have read the Custom Resource Scheduling and Configuration Overview section on the [configuration page](configuration.html). This section only talks about the Spark Standalone specific aspects of resource scheduling. Spark Standalone has 2 parts, the first is configuring the resources for the Worker, the second is the resource allocation for a specific application. The user must configure the Workers to have a set of resources available so that it can assign them out to Executors. The <code>spark.worker.resource.{resourceName}.amount</code> is used to control the amount of each resource the worker has allocated. The user must also specify either <code>spark.worker.resourcesFile</code> or <code>spark.worker.resource.{resourceName}.discoveryScript</code> to specify how the Worker discovers the resources its assigned. See the descriptions above for each of those to see which method works best for your setup. The second part is running an application on Spark Standalone. The only special case from the standard Spark resource configs is when you are running the Driver in client mode. For a Driver in client mode, the user can specify the resources it uses via <code>spark.driver.resourcesFile</code> or <code>spark.driver.resource.{resourceName}.discoveryScript</code>. If the Driver is running on the same host as other Drivers, please make sure the resources file or discovery script only returns resources that do not conflict with other Drivers running on the same node. Note, the user does not need to specify a discovery script when submitting an application as the Worker will start each Executor with the resources it allocates to it. # Connecting an Application to the Cluster

To run an application on the Spark cluster, simply pass the `spark://IP:PORT` URL of the master as to the [`SparkContext`
constructor](rdd-programming-guide.html#initializing-spark). To run an interactive Spark shell against the cluster, run the following command:

    ./bin/spark-shell --master spark://IP:PORT

You can also pass an option `--total-executor-cores <numCores>` to control the number of cores that spark-shell uses on the cluster. # Client Properties

Spark applications supports the following configuration properties specific to standalone mode:

<table class="spark-config">
  <thead><tr><th>Property Name</th><th>Default Value</th><th>Meaning</th><th>Since Version</th></tr></thead>
  <tr>
  <td><code>spark.standalone.submit.waitAppCompletion</code></td>
  <td><code>false</code></td>
  <td>
  In standalone cluster mode, controls whether the client waits to exit until the application completes. If set to <code>true</code>, the client process will stay alive polling the driver's status. Otherwise, the client process will exit after submission. </td>
  <td>3.1.0</td>
  </tr>
</table>


# Launching Spark Applications

## Spark Protocol

The [`spark-submit` script](submitting-applications.html) provides the most straightforward way to
submit a compiled Spark application to the cluster. For standalone clusters, Spark currently
supports two deploy modes. In `client` mode, the driver is launched in the same process as the
client that submits the application. In `cluster` mode, however, the driver is launched from one
of the Worker processes inside the cluster, and the client process exits as soon as it fulfills
its responsibility of submitting the application without waiting for the application to finish. If your application is launched through Spark submit, then the application jar is automatically
distributed to all worker nodes.