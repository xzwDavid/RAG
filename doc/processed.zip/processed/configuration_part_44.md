</td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.shuffleTracking.enabled</code></td>
  <td><code>true</code></td>
  <td>
    Enables shuffle file tracking for executors, which allows dynamic allocation
    without the need for an external shuffle service. This option will try to keep alive executors
    that are storing shuffle data for active jobs. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.shuffleTracking.timeout</code></td>
  <td><code>infinity</code></td>
  <td>
    When shuffle tracking is enabled, controls the timeout for executors that are holding shuffle
    data. The default value means that Spark will rely on the shuffles being garbage collected to be
    able to release executors. If for some reason garbage collection is not cleaning up shuffles
    quickly enough, this option can be used to control when to time out executors even when they are
    storing shuffle data. </td>
  <td>3.0.0</td>
</tr>
</table>

### Thread Configurations

Depending on jobs and cluster configurations, we can set number of threads in several places in Spark to utilize
available resources efficiently to get better performance. Prior to Spark 3.0, these thread configurations apply
to all roles of Spark, such as driver, executor, worker and master. From Spark 3.0, we can configure threads in
finer granularity starting from driver and executor. Take RPC module as example in below table. For other modules,
like shuffle, just replace "rpc" with "shuffle" in the property names except
<code>spark.{driver|executor}.rpc.netty.dispatcher.numThreads</code>, which is only for RPC module. <table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.{driver|executor}.rpc.io.serverThreads</code></td>
  <td>
    Fall back on <code>spark.rpc.io.serverThreads</code>
  </td>
  <td>Number of threads used in the server thread pool</td>
  <td>1.6.0</td>
</tr>
<tr>
  <td><code>spark.{driver|executor}.rpc.io.clientThreads</code></td>
  <td>
    Fall back on <code>spark.rpc.io.clientThreads</code>
  </td>
  <td>Number of threads used in the client thread pool</td>
  <td>1.6.0</td>
</tr>
<tr>
  <td><code>spark.{driver|executor}.rpc.netty.dispatcher.numThreads</code></td>
  <td>
    Fall back on <code>spark.rpc.netty.dispatcher.numThreads</code>
  </td>
  <td>Number of threads used in RPC message dispatcher thread pool</td>
  <td>3.0.0</td>
</tr>
</table>

The default value for number of thread-related config keys is the minimum of the number of cores requested for
the driver or executor, or, in the absence of that value, the number of cores available for the JVM (with a hardcoded upper limit of 8). ### Spark Connect

#### Server Configuration

Server configurations are set in Spark Connect server, for example, when you start the Spark Connect server with `./sbin/start-connect-server.sh`. They are typically set via the config file and command-line options with `--conf/-c`.