</td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.recordLevelFilter.enabled</code></td>
  <td>false</td>
  <td>
    If true, enables Parquet's native record-level filtering using the pushed down filters. This configuration only has an effect when <code>spark.sql.parquet.filterPushdown</code>
    is enabled and the vectorized reader is not used. You can ensure the vectorized reader
    is not used by setting <code>spark.sql.parquet.enableVectorizedReader</code> to false. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.columnarReaderBatchSize</code></td>
  <td>4096</td>
  <td>
    The number of rows to include in a parquet vectorized reader batch. The number should
    be carefully chosen to minimize overhead and avoid OOMs in reading data. </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.fieldId.write.enabled</code></td>
  <td>true</td>
  <td>
    Field ID is a native field of the Parquet schema spec. When enabled,
    Parquet writers will populate the field Id metadata (if present) in the Spark schema to the Parquet schema. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.fieldId.read.enabled</code></td>
  <td>false</td>
  <td>
    Field ID is a native field of the Parquet schema spec. When enabled, Parquet readers
    will use field IDs (if present) in the requested Spark schema to look up Parquet
    fields instead of using column names. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.fieldId.read.ignoreMissing</code></td>
  <td>false</td>
  <td>
    When the Parquet file doesn't have any field IDs but the
    Spark read schema is using field IDs to read, we will silently return nulls
    when this flag is enabled, or error otherwise. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.inferTimestampNTZ.enabled</code></td>
  <td>true</td>
  <td>
    When enabled, Parquet timestamp columns with annotation <code>isAdjustedToUTC = false</code>
    are inferred as TIMESTAMP_NTZ type during schema inference. Otherwise, all the Parquet
    timestamp columns are inferred as TIMESTAMP_LTZ types. Note that Spark writes the
    output schema into Parquet's footer metadata on file writing and leverages it on file
    reading. Thus this configuration only affects the schema inference on Parquet files
    which are not written by Spark.