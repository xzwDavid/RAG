These operators generally work in the same way as in regular Spark
SQL, as described in the table below. ### Independence and Interoperability

SQL pipe syntax works in Spark without any backwards-compatibility concerns with existing SQL
queries; it is possible to write any query using regular Spark SQL, pipe syntax, or a combination of
the two. As a consequence, the following invariants always hold:

* Each pipe operator receives an input table and operates the same way on its rows regardless of how
  it was computed. * For any valid chain of N SQL pipe operators, any subset of the first M <= N operators also
represents a valid query.<br>
  This property can be useful for introspection and debugging, such as by selected a subset of
  lines and using the "run highlighted text" feature of SQL editors like Jupyter notebooks. * It is possible to append pipe operators to any valid query written in regular Spark SQL.<br>
  The canonical way of starting pipe syntax queries is with the `FROM <tableName>` clause.<br>
  Note that this is a valid standalone query and may be replaced with any other Spark SQL query
  without loss of generality. * Table subqueries can be written using either regular Spark SQL syntax or pipe syntax.<br>
  They may appear inside enclosing queries written in either syntax. * Other Spark SQL statements such as views and DDL and DML commands may include queries written
  using either syntax. ### Supported Operators

| Operator                                          | Output rows                                                                                                         |
|