<table>
  <thead>
    <tr>
      <th><b>Spark SQL Data Type</b></th>
      <th><b>DB2 Data Type</b></th>
      <th><b>Remarks</b></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>BooleanType</td>
      <td>BOOLEAN</td>
      <td></td>
    </tr>
    <tr>
      <td>ByteType</td>
      <td>SMALLINT</td>
      <td></td>
    </tr>
    <tr>
      <td>ShortType</td>
      <td>SMALLINT</td>
      <td></td>
    </tr>
    <tr>
      <td>IntegerType</td>
      <td>INTEGER</td>
      <td></td>
    </tr>
    <tr>
      <td>LongType</td>
      <td>BIGINT</td>
      <td></td>
    </tr>
    <tr>
      <td>FloatType</td>
      <td>REAL</td>
      <td></td>
    </tr>
    <tr>
      <td>DoubleType</td>
      <td>DOUBLE PRECISION</td>
      <td></td>
    </tr>
    <tr>
      <td>DecimalType(p, s)</td>
      <td>DECIMAL(p,s)</td>
      <td>The maximum value for 'p' is 31 in DB2, while it is 38 in Spark.