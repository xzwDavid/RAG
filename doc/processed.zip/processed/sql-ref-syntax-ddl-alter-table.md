

### Description

`ALTER TABLE` statement changes the schema or properties of a table. ### RENAME 

`ALTER TABLE RENAME TO` statement changes the table name of an existing table in the database. The table rename command cannot be used to move a table between databases, only to rename a table within the same database. If the table is cached, the commands clear cached data of the table. The cache will be lazily filled when the next time the table is accessed. Additionally:
  * the table rename command uncaches all table's dependents such as views that refer to the table. The dependents should be cached again explicitly. * the partition rename command clears caches of all table dependents while keeping them as cached. So, their caches will be lazily filled when the next time they are accessed. #### Syntax

```sql
ALTER TABLE table_identifier RENAME TO table_identifier

ALTER TABLE table_identifier partition_spec RENAME TO partition_spec
```

#### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **partition_spec**

    Partition to be renamed. Note that one can use a typed literal (e.g., date'2019-01-02') in the partition spec. **Syntax:** `PARTITION ( partition_col_name  = partition_col_val [ , ... ] )`

### ADD COLUMNS

`ALTER TABLE ADD COLUMNS` statement adds mentioned columns to an existing table. #### Syntax

```sql
ALTER TABLE table_identifier ADD COLUMNS ( col_spec [ , ... ] )
```

#### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **COLUMNS ( col_spec )**

    Specifies the columns to be added. ### DROP COLUMNS

`ALTER TABLE DROP COLUMNS` statement drops mentioned columns from an existing table. Note that this statement is only supported with v2 tables. #### Syntax

```sql
ALTER TABLE table_identifier DROP { COLUMN | COLUMNS } [ ( ] col_name [ , ... ] [ ) ]
```

#### Parameters

* **table_identifier**

  Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **col_name**

  Specifies the name of the column. ### RENAME COLUMN

`ALTER TABLE RENAME COLUMN` statement changes the column name of an existing table. Note that this statement is only supported with v2 tables. #### Syntax

```sql
ALTER TABLE table_identifier RENAME COLUMN col_name TO col_name
```

#### Parameters

* **table_identifier**

  Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **col_name**

  Specifies the name of the column. ### ALTER OR CHANGE COLUMN

`ALTER TABLE ALTER COLUMN` or `ALTER TABLE CHANGE COLUMN` statement changes column's definition. #### Syntax

```sql
ALTER TABLE table_identifier { ALTER | CHANGE } [ COLUMN ] col_name alterColumnAction
```

#### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **col_name**

    Specifies the name of the column. * **alterColumnAction**

    Change column's definition. ### REPLACE COLUMNS

`ALTER TABLE REPLACE COLUMNS` statement removes all existing columns and adds the new set of columns. Note that this statement is only supported with v2 tables.