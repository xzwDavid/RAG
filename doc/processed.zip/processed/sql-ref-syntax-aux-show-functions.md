

### Description

Returns the list of functions after applying an optional regex pattern. Given number of functions supported by Spark is quite large, this statement
in conjunction with [describe function](sql-ref-syntax-aux-describe-function.html)
may be used to quickly find the function and understand its usage. The `LIKE` 
clause is optional and supported only for compatibility with other systems. ### Syntax

```sql
SHOW [ function_kind ] FUNCTIONS [ { FROM | IN } database_name ] [ LIKE regex_pattern ]
```

### Parameters

* **function_kind**

    Specifies the name space of the function to be searched upon. The valid name spaces are :

    * **USER** - Looks up the function(s) among the user defined functions. * **SYSTEM** - Looks up the function(s) among the system defined functions. * **ALL** -  Looks up the function(s) among both user and system defined functions. * **{ FROM `|` IN } database_name**

  Specifies the database name from which functions are listed. * **regex_pattern**

    Specifies a regular expression pattern that is used to filter the results of the
    statement. * Except for `*` and `|` character, the pattern works like a regular expression. * `*` alone matches 0 or more characters and `|` is used to separate multiple different regular expressions,
       any of which can match. * The leading and trailing blanks are trimmed in the input pattern before processing. The pattern match is case-insensitive. ### Examples

```sql
-- List a system function `trim` by searching both user defined and system
-- defined functions. SHOW FUNCTIONS trim;
+