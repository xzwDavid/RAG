<table>
  <thead>
    <tr>
      <th><b>MySQL Data Type</b></th>
      <th><b>Spark SQL Data Type</b></th>
      <th><b>Remarks</b></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>BIT(1)</td>
      <td>BooleanType</td>
      <td></td>
    </tr>
    <tr>
      <td>BIT( &gt;1 )</td>
      <td>BinaryType</td>
      <td>(Default)</td>
    </tr>
    <tr>
      <td>BIT( &gt;1 )</td>
      <td>LongType</td>
      <td>spark.sql.legacy.mysql.bitArrayMapping.enabled=true</td>
    </tr>
    <tr>
      <td>TINYINT(1)</td>
      <td>BooleanType</td>
      <td></td>
    </tr>
    <tr>
      <td>TINYINT(1)</td>
      <td>ByteType</td>
      <td>tinyInt1isBit=false</td>
    </tr>
    <tr>
      <td>BOOLEAN</td>
      <td>BooleanType</td>
      <td></td>
    </tr>
    <tr>
      <td>BOOLEAN</td>
      <td>ByteType</td>
      <td>tinyInt1isBit=false</td>
    </tr>
    <tr>
      <td>TINYINT( &gt;1 )</td>
      <td>ByteType</td>
      <td></td>
    </tr>
    <tr>
      <td>TINYINT( any ) UNSIGNED</td>
      <td>ShortType</td>
      <td></td>
    </tr>
    <tr>
      <td>SMALLINT</td>
      <td>ShortType</td>
      <td></td>
    </tr>
    <tr>
      <td>SMALLINT UNSIGNED</td>
      <td>IntegerType</td>
      <td></td>
    </tr>
    <tr>
      <td>MEDIUMINT [UNSIGNED]</td>
      <td>IntegerType</td>
      <td></td>
    </tr>
    <tr>
      <td>INT</td>
      <td>IntegerType</td>
      <td></td>
    </tr>
    <tr>
      <td>INT UNSIGNED</td>
      <td>LongType</td>
      <td></td>
    </tr>
    <tr>
      <td>BIGINT</td>
      <td>LongType</td>
      <td></td>
    </tr>
    <tr>
      <td>BIGINT UNSIGNED</td>
      <td>DecimalType(20,0)</td>
      <td></td>
    </tr>
    <tr>
      <td>FLOAT</td>
      <td>FloatType</td>
      <td></td>
    </tr>
    <tr>
      <td>FLOAT UNSIGNED</td>
      <td>DoubleType</td>
      <td></td>
    </tr>
    <tr>
      <td>DOUBLE [UNSIGNED]</td>
      <td>DoubleType</td>
      <td></td>
    </tr>
    <tr>
      <td>DECIMAL(p,s) [UNSIGNED]</td>
      <td>DecimalType(min(38, p),(min(18,s)))</td>
      <td>The column type is bounded to DecimalType(38, 18), if 'p>38', the fraction part will be truncated if exceeded.