</td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.node.selector.[labelKey]</code></td>
  <td>(none)</td>
  <td>
    Adds to the node selector of the driver pod and executor pods, with key <code>labelKey</code> and the value as the
    configuration's value. For example, setting <code>spark.kubernetes.node.selector.identifier</code> to <code>myIdentifier</code>
    will result in the driver pod and executors having a node selector with key <code>identifier</code> and value
     <code>myIdentifier</code>. Multiple node selector keys can be added by setting multiple configurations with this prefix. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.node.selector.[labelKey]</code></td>
  <td>(none)</td>
  <td>
    Adds to the driver node selector of the driver pod, with key <code>labelKey</code> and the value as the
    configuration's value. For example, setting <code>spark.kubernetes.driver.node.selector.identifier</code> to <code>myIdentifier</code>
    will result in the driver pod having a node selector with key <code>identifier</code> and value
     <code>myIdentifier</code>. Multiple driver node selector keys can be added by setting multiple configurations with this prefix. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.executor.node.selector.[labelKey]</code></td>
  <td>(none)</td>
  <td>
    Adds to the executor node selector of the executor pods, with key <code>labelKey</code> and the value as the
    configuration's value. For example, setting <code>spark.kubernetes.executor.node.selector.identifier</code> to <code>myIdentifier</code>
    will result in the executors having a node selector with key <code>identifier</code> and value
     <code>myIdentifier</code>. Multiple executor node selector keys can be added by setting multiple configurations with this prefix. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driverEnv.[EnvironmentVariableName]</code></td>
  <td>(none)</td>
  <td>
    Add the environment variable specified by <code>EnvironmentVariableName</code> to
    the Driver process. The user can specify multiple of these to set multiple environment variables. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.driver.secrets.[SecretName]</code></td>
  <td>(none)</td>
  <td>
   Add the <a href="https://kubernetes.io/docs/concepts/configuration/secret/">Kubernetes Secret</a> named <code>SecretName</code> to the driver pod on the path specified in the value. For example,
   <code>spark.kubernetes.driver.secrets.spark-secret=/etc/secrets</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.kubernetes.executor.secrets.[SecretName]</code></td>
  <td>(none)</td>
  <td>
   Add the <a href="https://kubernetes.io/docs/concepts/configuration/secret/">Kubernetes Secret</a> named <code>SecretName</code> to the executor pod on the path specified in the value.