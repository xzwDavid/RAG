</td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.service.port</code></td>
  <td>7337</td>
  <td>
    Port on which the external shuffle service will run. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.service.name</code></td>
  <td>spark_shuffle</td>
  <td>
    The configured name of the Spark shuffle service the client should communicate with. This must match the name used to configure the Shuffle within the YARN NodeManager configuration
    (<code>yarn.nodemanager.aux-services</code>). Only takes effect
    when <code>spark.shuffle.service.enabled</code> is set to true. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.service.index.cache.size</code></td>
  <td>100m</td>
  <td>
    Cache entries limited to the specified memory footprint, in bytes unless otherwise specified. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.service.removeShuffle</code></td>
  <td>true</td>
  <td>
    Whether to use the ExternalShuffleService for deleting shuffle blocks for
    deallocated executors when the shuffle is no longer needed. Without this enabled,
    shuffle data on executors that are deallocated will remain on disk until the
    application ends. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.maxChunksBeingTransferred</code></td>
  <td>Long.MAX_VALUE</td>
  <td>
    The max number of chunks allowed to be transferred at the same time on shuffle service. Note that new incoming connections will be closed when the max number is hit. The client will
    retry according to the shuffle retry configs (see <code>spark.shuffle.io.maxRetries</code> and
    <code>spark.shuffle.io.retryWait</code>), if those limits are reached the task will fail with
    fetch failure. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.sort.bypassMergeThreshold</code></td>
  <td>200</td>
  <td>
    (Advanced) In the sort-based shuffle manager, avoid merge-sorting data if there is no
    map-side aggregation and there are at most this many reduce partitions. </td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.shuffle.sort.io.plugin.class</code></td>
  <td>org.apache.spark.shuffle.sort.io.LocalDiskShuffleDataIO</td>
  <td>
    Name of the class to use for shuffle IO. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.spill.compress</code></td>
  <td>true</td>
  <td>
    Whether to compress data spilled during shuffles. Compression will use
    <code>spark.io.compression.codec</code>. </td>
  <td>0.9.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.accurateBlockThreshold</code></td>
  <td>100 * 1024 * 1024</td>
  <td>
    Threshold in bytes above which the size of shuffle blocks in HighlyCompressedMapStatus is
    accurately recorded.