It might fail when storing DecimalType(p>=32, s) to DB2</td>
    </tr>
    <tr>
      <td>DateType</td>
      <td>DATE</td>
      <td></td>
    </tr>
    <tr>
      <td>TimestampType</td>
      <td>TIMESTAMP</td>
      <td></td>
    </tr>
    <tr>
      <td>TimestampNTZType</td>
      <td>TIMESTAMP</td>
      <td></td>
    </tr>
    <tr>
      <td>StringType</td>
      <td>CLOB</td>
      <td></td>
    </tr>
    <tr>
      <td>BinaryType</td>
      <td>BLOB</td>
      <td></td>
    </tr>
    <tr>
      <td>CharType(n)</td>
      <td>CHAR(n)</td>
      <td>The maximum value for 'n' is 255 in DB2, while it is unlimited in Spark.</td>
    </tr>
    <tr>
      <td>VarcharType(n)</td>
      <td>VARCHAR(n)</td>
      <td>The maximum value for 'n' is 255 in DB2, while it is unlimited in Spark.</td>
    </tr>
  </tbody>
</table>

The Spark Catalyst data types below are not supported with suitable DB2 types. - DayTimeIntervalType
- YearMonthIntervalType
- CalendarIntervalType
- ArrayType
- MapType
- StructType
- UserDefinedType
- NullType
- ObjectType
- VariantType

### Mapping Spark SQL Data Types from Teradata

The below table describes the data type conversions from Teradata data types to Spark SQL Data Types,
when reading data from a Teradata table using the built-in jdbc data source with the [Teradata JDBC Driver](https://mvnrepository.com/artifact/com.teradata.jdbc/terajdbc)
as the activated JDBC Driver.