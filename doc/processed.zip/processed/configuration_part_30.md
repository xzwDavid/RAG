Heartbeats let
    the driver know that the executor is still alive and update it with metrics for in-progress
    tasks. spark.executor.heartbeatInterval should be significantly less than
    spark.network.timeout
  </td>
  <td>1.1.0</td>
</tr>
<tr>
  <td><code>spark.files.fetchTimeout</code></td>
  <td>60s</td>
  <td>
    Communication timeout to use when fetching files added through SparkContext.addFile() from
    the driver. </td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.files.useFetchCache</code></td>
  <td>true</td>
  <td>
    If set to true (default), file fetching will use a local cache that is shared by executors
    that belong to the same application, which can improve task launching performance when
    running many executors on the same host. If set to false, these caching optimizations will
    be disabled and all executors will fetch their own copies of files. This optimization may be
    disabled in order to use Spark local directories that reside on NFS filesystems (see
    <a href="https://issues.apache.org/jira/browse/SPARK-6313">SPARK-6313</a> for more details). </td>
  <td>1.2.2</td>
</tr>
<tr>
  <td><code>spark.files.overwrite</code></td>
  <td>false</td>
  <td>
    Whether to overwrite any files which exist at the startup. Users can not overwrite the files added by
    <code>SparkContext.addFile</code> or <code>SparkContext.addJar</code> before even if this option is set
    <code>true</code>. </td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.files.ignoreCorruptFiles</code></td>
  <td>false</td>
  <td>
    Whether to ignore corrupt files. If true, the Spark jobs will continue to run when encountering corrupted or
    non-existing files and contents that have been read will still be returned. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.files.ignoreMissingFiles</code></td>
  <td>false</td>
  <td>
    Whether to ignore missing files. If true, the Spark jobs will continue to run when encountering missing files and
    the contents that have been read will still be returned. </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.files.maxPartitionBytes</code></td>
  <td>134217728 (128 MiB)</td>
  <td>
    The maximum number of bytes to pack into a single partition when reading files. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.files.openCostInBytes</code></td>
  <td>4194304 (4 MiB)</td>
  <td>
    The estimated cost to open a file, measured by the number of bytes could be scanned at the same
    time. This is used when putting multiple files into a partition. It is better to overestimate,
    then the partitions with small files will be faster than partitions with bigger files. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.hadoop.cloneConf</code></td>
  <td>false</td>
  <td>
    If set to true, clones a new Hadoop <code>Configuration</code> object for each task.