

### Description

Set operators are used to combine two input relations into a single one. Spark SQL supports three types of set operators:

 - `EXCEPT` or `MINUS`
 - `INTERSECT`
 - `UNION`

Note that input relations must have the same number of columns and compatible data types for the respective columns. ### EXCEPT

`EXCEPT` and `EXCEPT ALL` return the rows that are found in one relation but not the other. `EXCEPT` (alternatively, `EXCEPT DISTINCT`) takes only distinct rows while `EXCEPT ALL` does not remove duplicates from the result rows. Note that `MINUS` is an alias for `EXCEPT`. #### Syntax

```sql
[ ( ] relation [ ) ] EXCEPT | MINUS [ ALL | DISTINCT ] [ ( ] relation [ ) ]
```

#### Examples

```sql
-- Use number1 and number2 tables to demonstrate set operators in this page. SELECT * FROM number1;
+