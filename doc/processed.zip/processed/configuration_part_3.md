</td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.driver.memory</code></td>
  <td>1g</td>
  <td>
    Amount of memory to use for the driver process, i.e. where SparkContext is initialized, in the
    same format as JVM memory strings with a size unit suffix ("k", "m", "g" or "t")
    (e.g. <code>512m</code>, <code>2g</code>). <br />
    <em>Note:</em> In client mode, this config must not be set through the <code>SparkConf</code>
    directly in your application, because the driver JVM has already started at that point. Instead, please set this through the <code>--driver-memory</code> command line option
    or in your default properties file. </td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.driver.memoryOverhead</code></td>
  <td>driverMemory * <code>spark.driver.memoryOverheadFactor</code>, with minimum of <code>spark.driver.minMemoryOverhead</code></td>
  <td>
    Amount of non-heap memory to be allocated per driver process in cluster mode, in MiB unless
    otherwise specified. This is memory that accounts for things like VM overheads, interned strings,
    other native overheads, etc. This tends to grow with the container size (typically 6-10%). This option is currently supported on YARN and Kubernetes. <em>Note:</em> Non-heap memory includes off-heap memory
    (when <code>spark.memory.offHeap.enabled=true</code>) and memory used by other driver processes
    (e.g. python process that goes with a PySpark driver) and memory used by other non-driver
    processes running in the same container. The maximum memory size of container to running
    driver is determined by the sum of <code>spark.driver.memoryOverhead</code>
    and <code>spark.driver.memory</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.driver.minMemoryOverhead</code></td>
  <td>384m</td>
  <td>
    The minimum amount of non-heap memory to be allocated per driver process in cluster mode, in MiB unless otherwise specified, if <code>spark.driver.memoryOverhead</code> is not defined. This option is currently supported on YARN and Kubernetes. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.driver.memoryOverheadFactor</code></td>
  <td>0.10</td>
  <td>
    Fraction of driver memory to be allocated as additional non-heap memory per driver process in cluster mode. This is memory that accounts for things like VM overheads, interned strings,
    other native overheads, etc. This tends to grow with the container size. This value defaults to 0.10 except for Kubernetes non-JVM jobs, which defaults to
    0.40. This is done as non-JVM tasks need more non-JVM heap space and such tasks
    commonly fail with "Memory Overhead Exceeded" errors. This preempts this error
    with a higher default. This value is ignored if <code>spark.driver.memoryOverhead</code> is set directly. </td>
  <td>3.3.0</td>
</tr>
<tr>
 <td><code>spark.driver.resource.{resourceName}.amount</code></td>
  <td>0</td>
  <td>
    Amount of a particular resource type to use on the driver. If this is used, you must also specify the
    <code>spark.driver.resource.{resourceName}.discoveryScript</code>
    for the driver to find the resource on startup.