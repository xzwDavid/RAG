**Note:** If the specified property key does not exist, whether specify `IF EXISTS` or not, the command will ignore it and finally succeed. ##### Syntax

```sql
-- Unset Properties
ALTER TABLE table_identifier UNSET TBLPROPERTIES ( key1, key2, ... )
```

#### SET SERDE

`ALTER TABLE SET` command is used for setting the SERDE or SERDE properties in Hive tables. If a particular property was already set, this overrides the old value with the new one. ##### Syntax

```sql
-- Set SERDE Properties
ALTER TABLE table_identifier [ partition_spec ]
    SET SERDEPROPERTIES ( key1 = val1, key2 = val2, ... )

ALTER TABLE table_identifier [ partition_spec ] SET SERDE serde_class_name
    [ WITH SERDEPROPERTIES ( key1 = val1, key2 = val2, ... ) ]
```

#### SET LOCATION And SET FILE FORMAT

`ALTER TABLE SET` command can also be used for changing the file location and file format for 
existing tables. If the table is cached, the `ALTER TABLE .. SET LOCATION` command clears cached data of the table and all its dependents that refer to it. The cache will be lazily filled when the next time the table or the dependents are accessed. ##### Syntax

```sql
-- Changing File Format
ALTER TABLE table_identifier [ partition_spec ] SET FILEFORMAT file_format

-- Changing File Location
ALTER TABLE table_identifier [ partition_spec ] SET LOCATION 'new_location'
```

#### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **partition_spec**

    Specifies the partition on which the property has to be set. Note that one can use a typed literal (e.g., date'2019-01-02') in the partition spec. **Syntax:** `PARTITION ( partition_col_name  = partition_col_val [ , ... ] )`

* **SERDEPROPERTIES ( key1 = val1, key2 = val2, ... )**

    Specifies the SERDE properties to be set. ### RECOVER PARTITIONS

`ALTER TABLE RECOVER PARTITIONS` statement recovers all the partitions in the directory of a table and updates the Hive metastore. Another way to recover partitions is to use `MSCK REPAIR TABLE`. #### Syntax

```sql
ALTER TABLE table_identifier RECOVER PARTITIONS
```

#### Parameters

* **table_identifier**

  Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

### Examples

```sql
-- RENAME table 
DESC student;
+