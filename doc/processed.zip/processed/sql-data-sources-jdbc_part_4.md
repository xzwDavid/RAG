This option applies only to reading.<br>
      Example:<br>
      <code>
         spark.read.format("jdbc")<br>
           .option("url", jdbcUrl)<br>
           .option("dbtable", "(select c1, c2 from t1) as subq")<br>
           .option("partitionColumn", "c1")<br>
           .option("lowerBound", "1")<br>
           .option("upperBound", "100")<br>
           .option("numPartitions", "3")<br>
           .load()
      </code>
    </td>
    <td>read</td>
  </tr>

  <tr>
    <td><code>numPartitions</code></td>
    <td>(none)</td>
    <td>
      The maximum number of partitions that can be used for parallelism in table reading and
      writing. This also determines the maximum number of concurrent JDBC connections. If the number of partitions to write exceeds this limit, we decrease it to this limit by
      calling <code>coalesce(numPartitions)</code> before writing. </td>
    <td>read/write</td>
  </tr>

  <tr>
    <td><code>queryTimeout</code></td>
    <td><code>0</code></td>
    <td>
      The number of seconds the driver will wait for a Statement object to execute to the given
      number of seconds. Zero means there is no limit. In the write path, this option depends on
      how JDBC drivers implement the API <code>setQueryTimeout</code>, e.g., the h2 JDBC driver
      checks the timeout of each query instead of an entire JDBC batch. </td>
    <td>read/write</td>
  </tr>

  <tr>
    <td><code>fetchsize</code></td>
    <td><code>0</code></td>
    <td>
      The JDBC fetch size, which determines how many rows to fetch per round trip. This can help performance on JDBC drivers which default to low fetch size (e.g. Oracle with 10 rows). </td>
    <td>read</td>
  </tr>

  <tr>
    <td><code>batchsize</code></td>
    <td><code>1000</code></td>
    <td>
      The JDBC batch size, which determines how many rows to insert per round trip. This can help performance on JDBC drivers. This option applies only to writing. </td>
    <td>write</td>
  </tr>

  <tr>
    <td><code>isolationLevel</code></td>
    <td><code>READ_UNCOMMITTED</code></td>
    <td>
      The transaction isolation level, which applies to current connection. It can be one of <code>NONE</code>, <code>READ_COMMITTED</code>, <code>READ_UNCOMMITTED</code>, <code>REPEATABLE_READ</code>, or <code>SERIALIZABLE</code>, corresponding to standard transaction isolation levels defined by JDBC's Connection object, with default of <code>READ_UNCOMMITTED</code>. Please refer the documentation in <code>java.sql.Connection</code>.