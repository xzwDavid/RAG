

An SQL operator is a symbol specifying an action that is performed on one or more expressions. Operators are represented by special characters or by keywords. ### Operator Precedence

When a complex expression has multiple operators, operator precedence determines the sequence of operations in the expression,
e.g. in expression `1 + 2 * 3`, `*` has higher precedence than `+`, so the expression is evaluated as `1 + (2 * 3) = 7`. The order of execution can significantly affect the resulting value. Operators have the precedence levels shown in the following table. An operator on higher precedence is evaluated before an operator on a lower level. In the following table, the operators in descending order of precedence, a.k.a. 1 is the highest level. Operators listed on the same table cell have the same precedence and are evaluated from left to right or right to left based on the associativity.