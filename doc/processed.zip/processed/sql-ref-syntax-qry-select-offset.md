

### Description

The `OFFSET` clause is used to specify the number of rows to skip before beginning to return rows
returned by the [SELECT](sql-ref-syntax-qry-select.html) statement. In general, this clause
is used in conjunction with [ORDER BY](sql-ref-syntax-qry-select-orderby.html) to
ensure that the results are deterministic. ### Syntax

```sql
OFFSET integer_expression
```

### Parameters

* **integer_expression**

    Specifies a foldable expression that returns an integer. ### Examples

```sql
CREATE TABLE person (name STRING, age INT);
INSERT INTO person VALUES
    ('Zen Hui', 25),
    ('Anil B', 18),
    ('Shone S', 16),
    ('Mike A', 25),
    ('John A', 18),
    ('Jack N', 16);

-- Skip the first two rows. SELECT name, age FROM person ORDER BY name OFFSET 2;
+