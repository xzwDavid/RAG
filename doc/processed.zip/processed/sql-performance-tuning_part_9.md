</td>
      <td>3.4.0</td>
    </tr>
    <tr>
      <td><code>spark.sql.sources.v2.bucketing.allowJoinKeysSubsetOfPartitionKeys.enabled</code></td>
      <td>false</td>
      <td>
        When enabled, try to avoid shuffle if join or MERGE condition does not include all partition columns. This config requires both <code>spark.sql.sources.v2.bucketing.enabled</code> and <code>spark.sql.sources.v2.bucketing.pushPartValues.enabled</code> to be true, and <code>spark.sql.requireAllClusterKeysForCoPartition</code> to be false. </td>
      <td>4.0.0</td>
    </tr>
    <tr>
      <td><code>spark.sql.sources.v2.bucketing.allowCompatibleTransforms.enabled</code></td>
      <td>false</td>
      <td>
        When enabled, try to avoid shuffle if partition transforms are compatible but not identical. This config requires both <code>spark.sql.sources.v2.bucketing.enabled</code> and <code>spark.sql.sources.v2.bucketing.pushPartValues.enabled</code> to be true. </td>
      <td>4.0.0</td>
    </tr>
    <tr>
      <td><code>spark.sql.sources.v2.bucketing.shuffle.enabled</code></td>
      <td>false</td>
      <td>
        When enabled, try to avoid shuffle on one side of the join, by recognizing the partitioning reported by a V2 data source on the other side. </td>
      <td>4.0.0</td>
    </tr>
  </table>

If Storage Partition Join is performed, the query plan will not contain Exchange nodes prior to the join. The following example uses Iceberg ([https://iceberg.apache.org/docs/latest/spark-getting-started/](https://iceberg.apache.org/docs/latest/spark-getting-started/)), a Spark V2 DataSource that supports Storage Partition Join.