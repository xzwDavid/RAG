An example of usage can be found in section <a href="#handling-circular-references-of-avro-fields">Handling circular references of Avro fields</a></td>
    <td>read</td>
    <td>4.0.0</td>
  </tr>
</table>

## Configuration
Configuration of Avro can be done via `spark.conf.set` or by running `SET key=value` commands using SQL. <table class="spark-config">
  <thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
  <tr>
    <td>spark.sql.legacy.replaceDatabricksSparkAvro.enabled</td>
    <td>true</td>
    <td>
      If it is set to true, the data source provider <code>com.databricks.spark.avro</code> is mapped
      to the built-in but external Avro data source module for backward compatibility. <br><b>Note:</b> the SQL config has been deprecated in Spark 3.2 and might be removed in the future. </td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td>spark.sql.avro.compression.codec</td>
    <td>snappy</td>
    <td>
      Compression codec used in writing of AVRO files. Supported codecs: uncompressed, deflate,
      snappy, bzip2, xz and zstandard. Default codec is snappy. </td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td>spark.sql.avro.deflate.level</td>
    <td>-1</td>
    <td>
      Compression level for the deflate codec used in writing of AVRO files. Valid value must be in
      the range of from 1 to 9 inclusive or -1. The default value is -1 which corresponds to 6 level
      in the current implementation. </td>
    <td>2.4.0</td>
  </tr>
  <tr>
    <td>spark.sql.avro.xz.level</td>
    <td>6</td>
    <td>
      Compression level for the xz codec used in writing of AVRO files. Valid value must be in
      the range of from 1 to 9 inclusive. The default value is 6 in the current implementation. </td>
    <td>4.0.0</td>
  </tr>
  <tr>
    <td>spark.sql.avro.zstandard.level</td>
    <td>3</td>
    <td>
      Compression level for the zstandard codec used in writing of AVRO files. The default value is 3 in the current implementation. </td>
    <td>4.0.0</td>
  </tr>
  <tr>
    <td>spark.sql.avro.zstandard.bufferPool.enabled</td>
    <td>false</td>
    <td>
      If true, enable buffer pool of ZSTD JNI library when writing of AVRO files.