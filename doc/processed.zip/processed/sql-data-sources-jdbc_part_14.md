<table>
  <thead>
    <tr>
      <th><b>Spark SQL Data Type</b></th>
      <th><b>PostgreSQL Data Type</b></th>
      <th><b>Remarks</b></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>BooleanType</td>
      <td>boolean</td>
      <td></td>
    </tr>
    <tr>
      <td>ByteType</td>
      <td>smallint</td>
      <td></td>
    </tr>
    <tr>
      <td>ShortType</td>
      <td>smallint</td>
      <td></td>
    </tr>
    <tr>
      <td>IntegerType</td>
      <td>integer</td>
      <td></td>
    </tr>
    <tr>
      <td>LongType</td>
      <td>bigint</td>
      <td></td>
    </tr>
    <tr>
      <td>FloatType</td>
      <td>float4</td>
      <td></td>
    </tr>
    <tr>
      <td>DoubleType</td>
      <td>float8</td>
      <td></td>
    </tr>
    <tr>
      <td>DecimalType(p, s)</td>
      <td>numeric(p,s)</td>
      <td></td>
    </tr>
    <tr>
      <td>DateType</td>
      <td>date</td>
      <td></td>
    </tr>
    <tr>
      <td>TimestampType</td>
      <td>timestamp with time zone</td>
      <td>Before Spark 4.0, it was mapped as timestamp.