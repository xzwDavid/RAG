<p/>
    For now, only YARN and K8s cluster manager supports this configuration
  </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.ui.prometheus.enabled</code></td>
  <td>true</td>
  <td>
    Expose executor metrics at /metrics/executors/prometheus at driver web page. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.worker.ui.retainedExecutors</code></td>
  <td>1000</td>
  <td>
    How many finished executors the Spark UI and status APIs remember before garbage collecting. </td>
  <td>1.5.0</td>
</tr>
<tr>
  <td><code>spark.worker.ui.retainedDrivers</code></td>
  <td>1000</td>
  <td>
    How many finished drivers the Spark UI and status APIs remember before garbage collecting. </td>
  <td>1.5.0</td>
</tr>
<tr>
  <td><code>spark.sql.ui.retainedExecutions</code></td>
  <td>1000</td>
  <td>
    How many finished executions the Spark UI and status APIs remember before garbage collecting. </td>
  <td>1.5.0</td>
</tr>
<tr>
  <td><code>spark.streaming.ui.retainedBatches</code></td>
  <td>1000</td>
  <td>
    How many finished batches the Spark UI and status APIs remember before garbage collecting. </td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.ui.retainedDeadExecutors</code></td>
  <td>100</td>
  <td>
    How many dead executors the Spark UI and status APIs remember before garbage collecting. </td>
  <td>2.0.0</td>
</tr>
<tr>
  <td><code>spark.ui.filters</code></td>
  <td>None</td>
  <td>
    Comma separated list of filter class names to apply to the Spark Web UI. The filter should be a
    standard <a href="http://docs.oracle.com/javaee/6/api/javax/servlet/Filter.html">
    javax servlet Filter</a>. <br />Filter parameters can also be specified in the configuration, by setting config entries
    of the form <code>spark.&lt;class name of filter&gt;.param.&lt;param name&gt;=&lt;value&gt;</code>

    <br />For example:
    <br /><code>spark.ui.filters=com.test.filter1</code>
    <br /><code>spark.com.test.filter1.param.name1=foo</code>
    <br /><code>spark.com.test.filter1.param.name2=bar</code>
    <br />
    <br />Note that some filter requires additional dependencies. For example,
    the built-in <code>org.apache.spark.ui.JWSFilter</code> requires
    <code>jjwt-impl</code> and <code>jjwt-jackson</code> jar files. </td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.ui.requestHeaderSize</code></td>
  <td>8k</td>
  <td>
    The maximum allowed size for a HTTP request header, in bytes unless otherwise specified. This setting applies for the Spark History Server too.