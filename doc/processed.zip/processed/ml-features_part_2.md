**Note:** `spark.ml` doesn't provide tools for text segmentation. We refer users to the [Stanford NLP Group](http://nlp.stanford.edu/) and 
[scalanlp/chalk](https://github.com/scalanlp/chalk). **Examples**

In the following code segment, we start with a set of sentences. We split each sentence into words 
using `Tokenizer`. For each sentence (bag of words), we use `HashingTF` to hash the sentence into 
a feature vector. We use `IDF` to rescale the feature vectors; this generally improves performance 
when using text as features. Our feature vectors could then be passed to a learning algorithm. <div class="codetabs">

<div data-lang="python" markdown="1">

Refer to the [HashingTF Python docs](api/python/reference/api/pyspark.ml.feature.HashingTF.html) and
the [IDF Python docs](api/python/reference/api/pyspark.ml.feature.IDF.html) for more details on the API. {% include_example python/ml/tf_idf_example.py %}
</div>

<div data-lang="scala" markdown="1">

Refer to the [HashingTF Scala docs](api/scala/org/apache/spark/ml/feature/HashingTF.html) and
the [IDF Scala docs](api/scala/org/apache/spark/ml/feature/IDF.html) for more details on the API. {% include_example scala/org/apache/spark/examples/ml/TfIdfExample.scala %}
</div>

<div data-lang="java" markdown="1">

Refer to the [HashingTF Java docs](api/java/org/apache/spark/ml/feature/HashingTF.html) and the
[IDF Java docs](api/java/org/apache/spark/ml/feature/IDF.html) for more details on the API. {% include_example java/org/apache/spark/examples/ml/JavaTfIdfExample.java %}
</div>

</div>

## Word2Vec

`Word2Vec` is an `Estimator` which takes sequences of words representing documents and trains a
`Word2VecModel`. The model maps each word to a unique fixed-size vector. The `Word2VecModel`
transforms each document into a vector using the average of all words in the document; this vector
can then be used as features for prediction, document similarity calculations, etc. Please refer to the [MLlib user guide on Word2Vec](mllib-feature-extraction.html#word2vec) for more
details. **Examples**

In the following code segment, we start with a set of documents, each of which is represented as a sequence of words. For each document, we transform it into a feature vector. This feature vector could then be passed to a learning algorithm. <div class="codetabs">

<div data-lang="python" markdown="1">

Refer to the [Word2Vec Python docs](api/python/reference/api/pyspark.ml.feature.Word2Vec.html)
for more details on the API. {% include_example python/ml/word2vec_example.py %}
</div>

<div data-lang="scala" markdown="1">

Refer to the [Word2Vec Scala docs](api/scala/org/apache/spark/ml/feature/Word2Vec.html)
for more details on the API. {% include_example scala/org/apache/spark/examples/ml/Word2VecExample.scala %}
</div>

<div data-lang="java" markdown="1">

Refer to the [Word2Vec Java docs](api/java/org/apache/spark/ml/feature/Word2Vec.html)
for more details on the API. {% include_example java/org/apache/spark/examples/ml/JavaWord2VecExample.java %}
</div>

</div>

## CountVectorizer

`CountVectorizer` and `CountVectorizerModel` aim to help convert a collection of text documents
 to vectors of token counts.