For example, you may
have configuration like:

```properties
  yarn.nodemanager.aux-services = spark_shuffle_x,spark_shuffle_y
  yarn.nodemanager.aux-services.spark_shuffle_x.classpath = /path/to/spark-x-path/fat.jar:/path/to/spark-x-config
  yarn.nodemanager.aux-services.spark_shuffle_y.classpath = /path/to/spark-y-path/fat.jar:/path/to/spark-y-config
```
Or
```properties
  yarn.nodemanager.aux-services = spark_shuffle_x,spark_shuffle_y
  yarn.nodemanager.aux-services.spark_shuffle_x.classpath = /path/to/spark-x-path/*:/path/to/spark-x-config
  yarn.nodemanager.aux-services.spark_shuffle_y.classpath = /path/to/spark-y-path/*:/path/to/spark-y-config
```

The two `spark-*-config` directories each contain one file, `spark-shuffle-site.xml`. These are XML
files in the [Hadoop Configuration format](https://hadoop.apache.org/docs/current/api/org/apache/hadoop/conf/Configuration.html)
which each contain a few configurations to adjust the port number and metrics name prefix used:
```xml
<configuration>
  <property>
    <name>spark.shuffle.service.port</name>
    <value>7001</value>
  </property>
  <property>
    <name>spark.yarn.shuffle.service.metrics.namespace</name>
    <value>sparkShuffleServiceX</value>
  </property>
</configuration>
```
The values should both be different for the two different services. Then, in the configuration of the Spark applications, one should be configured with:
```properties
  spark.shuffle.service.name = spark_shuffle_x
  spark.shuffle.service.port = 7001
```
and one should be configured with:
```properties
  spark.shuffle.service.name = spark_shuffle_y
  spark.shuffle.service.port = <other value>
```

# Configuring different JDKs for Spark Applications

In some cases it may be desirable to use a different JDK from YARN node manager to run Spark applications,
this can be achieved by setting the `JAVA_HOME` environment variable for YARN containers and the `spark-submit`
process. Note that, Spark assumes that all JVM processes runs in one application use the same version of JDK, otherwise,
you may encounter JDK serialization issues. To configure a Spark application to use a JDK which has been pre-installed on all nodes at `/opt/openjdk-17`:

    $ export JAVA_HOME=/opt/openjdk-17
    $ ./bin/spark-submit --class path.to.your.Class \
        --master yarn \
        --conf spark.yarn.appMasterEnv.JAVA_HOME=/opt/openjdk-17 \
        --conf spark.executorEnv.JAVA_HOME=/opt/openjdk-17 \
        <app jar> [app options]

Optionally, the user may want to avoid installing a different JDK on the YARN cluster nodes, in such a case,
it's also possible to distribute the JDK using YARN's Distributed Cache.