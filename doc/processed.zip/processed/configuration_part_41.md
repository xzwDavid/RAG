When set to false (the default), task killing will use an older code
    path which lacks such monitoring. </td>
  <td>2.0.3</td>
</tr>
<tr>
  <td><code>spark.task.reaper.pollingInterval</code></td>
  <td>10s</td>
  <td>
    When <code>spark.task.reaper.enabled = true</code>, this setting controls the frequency at which
    executors will poll the status of killed tasks. If a killed task is still running when polled
    then a warning will be logged and, by default, a thread-dump of the task will be logged
    (this thread dump can be disabled via the <code>spark.task.reaper.threadDump</code> setting,
    which is documented below). </td>
  <td>2.0.3</td>
</tr>
<tr>
  <td><code>spark.task.reaper.threadDump</code></td>
  <td>true</td>
  <td>
    When <code>spark.task.reaper.enabled = true</code>, this setting controls whether task thread
    dumps are logged during periodic polling of killed tasks. Set this to false to disable
    collection of thread dumps. </td>
  <td>2.0.3</td>
</tr>
<tr>
  <td><code>spark.task.reaper.killTimeout</code></td>
  <td>-1</td>
  <td>
    When <code>spark.task.reaper.enabled = true</code>, this setting specifies a timeout after
    which the executor JVM will kill itself if a killed task has not stopped running. The default
    value, -1, disables this mechanism and prevents the executor from self-destructing. The purpose
    of this setting is to act as a safety-net to prevent runaway noncancellable tasks from rendering
    an executor unusable. </td>
  <td>2.0.3</td>
</tr>
<tr>
  <td><code>spark.stage.maxConsecutiveAttempts</code></td>
  <td>4</td>
  <td>
    Number of consecutive stage attempts allowed before a stage is aborted. </td>
  <td>2.2.0</td>
</tr>
<tr>
  <td><code>spark.stage.ignoreDecommissionFetchFailure</code></td>
  <td>true</td>
  <td>
    Whether ignore stage fetch failure caused by executor decommission when
    count <code>spark.stage.maxConsecutiveAttempts</code>
  </td>
  <td>3.4.0</td>
</tr>
</table>

### Barrier Execution Mode

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.barrier.sync.timeout</code></td>
  <td>365d</td>
  <td>
    The timeout in seconds for each <code>barrier()</code> call from a barrier task. If the
    coordinator didn't receive all the sync messages from barrier tasks within the
    configured time, throw a SparkException to fail all the tasks. The default value is set
    to 31536000(3600 * 24 * 365) so the <code>barrier()</code> call shall wait for one year. </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.barrier.maxConcurrentTasksCheck.interval</code></td>
  <td>15s</td>
  <td>
    Time in seconds to wait between a max concurrent tasks check failure and the next
    check. A max concurrent tasks check ensures the cluster can launch more concurrent
    tasks than required by a barrier stage on job submitted.