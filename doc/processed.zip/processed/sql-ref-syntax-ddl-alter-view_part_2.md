* **COMPENSATION** - The view can tolerate type changes in the underlying schema requiring casts. Runtime casting errors may occur. * **TYPE EVOLUTION** - The view will adapt to any type changes in the underlying schema. * **EVOLUTION** - For views defined without a column lists any schema changes are adapted by the view, including, for queries with `SELECT *` dropped or added columns. If the view is defined with a column list, the clause is interpreted as `TYPE EVOLUTION`. ### Examples

```sql
-- Rename only changes the view name. -- The source and target databases of the view have to be the same. -- Use qualified or unqualified name for the source and target view. ALTER VIEW tempdb1.v1 RENAME TO tempdb1.v2;

-- Verify that the new view is created. DESCRIBE TABLE EXTENDED tempdb1.v2;
+