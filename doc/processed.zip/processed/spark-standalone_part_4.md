</td>
  <td>1.1.0</td>
</tr>
<tr>
  <td><code>spark.master.ui.title</code></td>
  <td>(None)</td>
  <td>
    Specifies the title of the Master UI page. If unset, <code>Spark Master at 'master url'</code>
    is used by default. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.master.ui.decommission.allow.mode</code></td>
  <td><code>LOCAL</code></td>
  <td>
    Specifies the behavior of the Master Web UI's /workers/kill endpoint. Possible choices
    are: <code>LOCAL</code> means allow this endpoint from IP's that are local to the machine running
    the Master, <code>DENY</code> means to completely disable this endpoint, <code>ALLOW</code> means to allow
    calling this endpoint from any IP. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.master.ui.historyServerUrl</code></td>
  <td>(None)</td>
  <td>
    The URL where Spark history server is running. Please note that this assumes
    that all Spark jobs share the same event log location where the history server accesses. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.master.rest.enabled</code></td>
  <td><code>false</code></td>
  <td>
    Whether to use the Master REST API endpoint or not. </td>
  <td>1.3.0</td>
</tr>
<tr>
  <td><code>spark.master.rest.host</code></td>
  <td>(None)</td>
  <td>
    Specifies the host of the Master REST API endpoint. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.master.rest.port</code></td>
  <td><code>6066</code></td>
  <td>
    Specifies the port number of the Master REST API endpoint. </td>
  <td>1.3.0</td>
</tr>
<tr>
  <td><code>spark.master.rest.filters</code></td>
  <td>(None)</td>
  <td>
    Comma separated list of filter class names to apply to the Master REST API. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.master.useAppNameAsAppId.enabled</code></td>
  <td><code>false</code></td>
  <td>
    (Experimental) If true, Spark master uses the user-provided appName for appId. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.deploy.retainedApplications</code></td>
  <td>200</td>
  <td>
    The maximum number of completed applications to display. Older applications will be dropped from the UI to maintain this limit.<br/>
  </td>
  <td>0.8.0</td>
</tr>
<tr>
  <td><code>spark.deploy.retainedDrivers</code></td>
  <td>200</td>
  <td>
   The maximum number of completed drivers to display.