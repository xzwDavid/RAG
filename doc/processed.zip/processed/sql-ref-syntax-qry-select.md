

### Description

Spark supports a `SELECT` statement and conforms to the ANSI SQL standard. Queries are
used to retrieve result sets from one or more tables. The following section
describes the overall query syntax and the sub-sections cover different constructs
of a query along with examples. ### Syntax

```sql
[ WITH with_query [ , ... ] ]
select_statement [ { UNION | INTERSECT | EXCEPT } [ ALL | DISTINCT ] select_statement, ... ]
    [ ORDER BY { expression [ ASC | DESC ] [ NULLS { FIRST | LAST } ] [ , ... ] } ]
    [ SORT BY { expression [ ASC | DESC ] [ NULLS { FIRST | LAST } ] [ , ... ] } ]
    [ CLUSTER BY { expression [ , ... ] } ]
    [ DISTRIBUTE BY { expression [, ... ] } ]
    [ WINDOW { named_window [ , WINDOW named_window, ... ] } ]
    [ LIMIT { ALL | expression } ]
```

While `select_statement` is defined as
```sql
SELECT [ hints , ... ] [ ALL | DISTINCT ] { [ [ named_expression | regex_column_names | star ] [ , ... ] | TRANSFORM (...) ] }
    FROM { from_item [ , ... ] }
    [ PIVOT clause ]
    [ UNPIVOT clause ]
    [ LATERAL VIEW clause ] [ ... ] 
    [ WHERE boolean_expression ]
    [ GROUP BY expression [ , ... ] ]
    [ HAVING boolean_expression ]
```

### Parameters

* **with_query**

    Specifies the [common table expressions (CTEs)](sql-ref-syntax-qry-select-cte.html) before the main query block. These table expressions are allowed to be referenced later in the FROM clause. This is useful to abstract
    out repeated subquery blocks in the FROM clause and improves readability of the query. * **hints**

    Hints can be specified to help spark optimizer make better planning decisions. Currently spark supports hints
    that influence selection of join strategies and repartitioning of the data. * **ALL**

    Select all matching rows from the relation and is enabled by default. * **DISTINCT**

    Select all matching rows from the relation after removing duplicates in results. * **named_expression**

    An expression with an assigned name. In general, it denotes a column expression. **Syntax:** `expression [[AS] alias]`

* **star**

    The `*` (star) clause is used to select all or most columns from one or all relations in a FROM clause. * **from_item**

     Specifies a source of input for the query. It can be one of the following:
     * Table relation
     * [Join relation](sql-ref-syntax-qry-select-join.html)
     * [Pivot relation](sql-ref-syntax-qry-select-pivot.html)
     * [Unpivot relation](sql-ref-syntax-qry-select-unpivot.html)
     * [Table-value function](sql-ref-syntax-qry-select-tvf.html)
     * [Inline table](sql-ref-syntax-qry-select-inline-table.html)
     * [ [LATERAL](sql-ref-syntax-qry-select-lateral-subquery.html) ] ( Subquery )
     * [File](sql-ref-syntax-qry-select-file.html)
     
* **PIVOT**

     The `PIVOT` clause is used for data perspective; We can get the aggregated values based on specific column value. * **UNPIVOT**

     The `UNPIVOT` clause transforms columns into rows. It is the reverse of `PIVOT`, except for aggregation of values.