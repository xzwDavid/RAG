</td>
    <td>read</td>
  </tr>
</table>

Note that kerberos authentication with keytab is not always supported by the JDBC driver.<br>
Before using <code>keytab</code> and <code>principal</code> configuration options, please make sure the following requirements are met:
* The included JDBC driver version supports kerberos authentication with keytab. * There is a built-in connection provider which supports the used database. There is a built-in connection providers for the following databases:
* DB2
* MariaDB
* MS Sql
* Oracle
* PostgreSQL

If the requirements are not met, please consider using the <code>JdbcConnectionProvider</code> developer API to handle custom authentication. <div class="codetabs">

<div data-lang="python"  markdown="1">
{% include_example jdbc_dataset python/sql/datasource.py %}
</div>

<div data-lang="scala"  markdown="1">
{% include_example jdbc_dataset scala/org/apache/spark/examples/sql/SQLDataSourceExample.scala %}
</div>

<div data-lang="java"  markdown="1">
{% include_example jdbc_dataset java/org/apache/spark/examples/sql/JavaSQLDataSourceExample.java %}
</div>

<div data-lang="r"  markdown="1">
{% include_example jdbc_dataset r/RSparkSQLExample.R %}
</div>

<div data-lang="SQL"  markdown="1">

{% highlight sql %}

CREATE TEMPORARY VIEW jdbcTable
USING org.apache.spark.sql.jdbc
OPTIONS (
  url "jdbc:postgresql:dbserver",
  dbtable "schema.tablename",
  user 'username',
  password 'password'
)

INSERT INTO TABLE jdbcTable
SELECT * FROM resultTable
{% endhighlight %}

</div>
</div>

## Data Type Mapping

### Mapping Spark SQL Data Types from MySQL

The below table describes the data type conversions from MySQL data types to Spark SQL Data Types,
when reading data from a MySQL table using the built-in jdbc data source with the MySQL Connector/J
as the activated JDBC Driver. Note that, different JDBC drivers, such as Maria Connector/J, which
are also available to connect MySQL, may have different mapping rules.