

Spark SQL provides `spark.read().xml("file_1_path","file_2_path")` to read a file or directory of files in XML format into a Spark DataFrame, and `dataframe.write().xml("path")` to write to a xml file. When reading a XML file, the `rowTag` option must be specified to indicate the XML element that maps to a `DataFrame row`. The option() function can be used to customize the behavior of reading or writing, such as controlling behavior of the XML attributes, XSD validation, compression, and so on. <div class="codetabs">

<div data-lang="python"  markdown="1">
{% include_example xml_dataset python/sql/datasource.py %}
</div>

<div data-lang="scala"  markdown="1">
{% include_example xml_dataset scala/org/apache/spark/examples/sql/SQLDataSourceExample.scala %}
</div>

<div data-lang="java"  markdown="1">
{% include_example xml_dataset java/org/apache/spark/examples/sql/JavaSQLDataSourceExample.java %}
</div>

</div>

## Data Source Option

Data source options of XML can be set via:

* the `.option`/`.options` methods of
    * `DataFrameReader`
    * `DataFrameWriter`
    * `DataStreamReader`
    * `DataStreamWriter`
* the built-in functions below
    * `from_xml`
    * `to_xml`
    * `schema_of_xml`
* `OPTIONS` clause at [CREATE TABLE USING DATA_SOURCE](sql-ref-syntax-ddl-create-table-datasource.html)

<table>
  <thead><tr><th><b>Property Name</b></th><th><b>Default</b></th><th><b>Meaning</b></th><th><b>Scope</b></th></tr></thead>
  <tr>
    <td><code>rowTag</code></td>
    <td></td>
    <td>The row tag of your xml files to treat as a row. For example, in this xml: 
        <code><xmp><books><book></book>...</books></xmp></code>
        the appropriate value would be book. This is a required option for both read and write. </td>
    <td>read</td>
  </tr>

  <tr>
    <td><code>samplingRatio</code></td>
    <td><code>1.0</code></td>
    <td>Defines fraction of rows used for schema inferring. XML built-in functions ignore this option.</td>
    <td>read</td>
  </tr>

  <tr>
    <td><code>excludeAttribute</code></td>
    <td><code>false</code></td>
    <td>Whether to exclude attributes in elements.</td>
    <td>read</td>
  </tr>

  <tr>
    <td><code>mode</code></td>
    <td><code>PERMISSIVE</code></td>
    <td>Allows a mode for dealing with corrupt records during parsing.<br>
    <ul>
      <li><code>PERMISSIVE</code>: when it meets a corrupted record, puts the malformed string into a field configured by columnNameOfCorruptRecord, and sets malformed fields to null. To keep corrupt records, an user can set a string type field named columnNameOfCorruptRecord in an user-defined schema. If a schema does not have the field, it drops corrupt records during parsing. When inferring a schema, it implicitly adds a columnNameOfCorruptRecord field in an output schema.</li>
      <li><code>DROPMALFORMED</code>: ignores the whole corrupted records.