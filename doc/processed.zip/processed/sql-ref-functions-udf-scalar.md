

### Description

User-Defined Functions (UDFs) are user-programmable routines that act on one row. This documentation lists the classes that are required for creating and registering UDFs. It also contains examples that demonstrate how to define and register UDFs and invoke them in Spark SQL. ### UserDefinedFunction

To define the properties of a user-defined function, the user can use some of the methods defined in this class. * **asNonNullable(): UserDefinedFunction**

    Updates UserDefinedFunction to non-nullable. * **asNondeterministic(): UserDefinedFunction**

    Updates UserDefinedFunction to nondeterministic. * **withName(name: String): UserDefinedFunction**

    Updates UserDefinedFunction with a given name. ### Examples

<div class="codetabs">
<div data-lang="scala"  markdown="1">
{% include_example udf_scalar scala/org/apache/spark/examples/sql/UserDefinedScalar.scala%}
</div>
<div data-lang="java"  markdown="1">
  {% include_example udf_scalar java/org/apache/spark/examples/sql/JavaUserDefinedScalar.java%}
</div>
</div>

### Related Statements
* [User Defined Aggregate Functions (UDAFs)](sql-ref-functions-udf-aggregate.html)
* [Integration with Hive UDFs/UDAFs/UDTFs](sql-ref-functions-udf-hive.html)
