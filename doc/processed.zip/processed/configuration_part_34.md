This config will be used in place of
    <code>spark.storage.blockManagerHeartbeatTimeoutMs</code>,
    <code>spark.shuffle.io.connectionTimeout</code>, <code>spark.rpc.askTimeout</code> or
    <code>spark.rpc.lookupTimeout</code> if they are not configured. </td>
  <td>1.3.0</td>
</tr>
<tr>
  <td><code>spark.network.timeoutInterval</code></td>
  <td>60s</td>
  <td>
    Interval for the driver to check and expire dead executors. </td>
  <td>1.3.2</td>
</tr>
<tr>
  <td><code>spark.network.io.preferDirectBufs</code></td>
  <td>true</td>
  <td>
    If enabled then off-heap buffer allocations are preferred by the shared allocators. Off-heap buffers are used to reduce garbage collection during shuffle and cache
    block transfer. For environments where off-heap memory is tightly limited, users may wish to
    turn this off to force all allocations to be on-heap. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.port.maxRetries</code></td>
  <td>16</td>
  <td>
    Maximum number of retries when binding to a port before giving up. When a port is given a specific value (non 0), each subsequent retry will
    increment the port used in the previous attempt by 1 before retrying. This
    essentially allows it to try a range of ports from the start port specified
    to port + maxRetries. </td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.rpc.askTimeout</code></td>
  <td><code>spark.network.timeout</code></td>
  <td>
    Duration for an RPC ask operation to wait before timing out. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.rpc.lookupTimeout</code></td>
  <td>120s</td>
  <td>
    Duration for an RPC remote endpoint lookup operation to wait before timing out. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.network.maxRemoteBlockSizeFetchToMem</code></td>
  <td>200m</td>
  <td>
    Remote block will be fetched to disk when size of the block is above this threshold
    in bytes. This is to avoid a giant request takes too much memory. Note this
    configuration will affect both shuffle fetch and block manager remote block fetch. For users who enabled external shuffle service, this feature can only work when
    external shuffle service is at least 2.3.0. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.rpc.io.connectionTimeout</code></td>
  <td>value of <code>spark.network.timeout</code></td>
  <td>
    Timeout for the established connections between RPC peers to be marked as idled and closed
    if there are outstanding RPC requests but no traffic on the channel for at least
    <code>connectionTimeout</code>. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.rpc.io.connectionCreationTimeout</code></td>
  <td>value of <code>spark.rpc.io.connectionTimeout</code></td>
  <td>
    Timeout for establishing a connection between RPC peers.