</td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.cachedExecutorIdleTimeout</code></td>
  <td>infinity</td>
  <td>
    If dynamic allocation is enabled and an executor which has cached data blocks has been idle for more than this duration,
    the executor will be removed. For more details, see this
    <a href="job-scheduling.html#resource-allocation-policy">description</a>. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.initialExecutors</code></td>
  <td><code>spark.dynamicAllocation.minExecutors</code></td>
  <td>
    Initial number of executors to run if dynamic allocation is enabled. <br /><br />
    If <code>--num-executors</code> (or <code>spark.executor.instances</code>) is set and larger than this value, it will
    be used as the initial number of executors. </td>
  <td>1.3.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.maxExecutors</code></td>
  <td>infinity</td>
  <td>
    Upper bound for the number of executors if dynamic allocation is enabled. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.minExecutors</code></td>
  <td>0</td>
  <td>
    Lower bound for the number of executors if dynamic allocation is enabled. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.executorAllocationRatio</code></td>
  <td>1</td>
  <td>
    By default, the dynamic allocation will request enough executors to maximize the
    parallelism according to the number of tasks to process. While this minimizes the
    latency of the job, with small tasks this setting can waste a lot of resources due to
    executor allocation overhead, as some executor might not even do any work. This setting allows to set a ratio that will be used to reduce the number of
    executors w.r.t. full parallelism. Defaults to 1.0 to give maximum parallelism. 0.5 will divide the target number of executors by 2
    The target number of executors computed by the dynamicAllocation can still be overridden
    by the <code>spark.dynamicAllocation.minExecutors</code> and
    <code>spark.dynamicAllocation.maxExecutors</code> settings
  </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.schedulerBacklogTimeout</code></td>
  <td>1s</td>
  <td>
    If dynamic allocation is enabled and there have been pending tasks backlogged for more than
    this duration, new executors will be requested. For more detail, see this
    <a href="job-scheduling.html#resource-allocation-policy">description</a>. </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.sustainedSchedulerBacklogTimeout</code></td>
  <td><code>schedulerBacklogTimeout</code></td>
  <td>
    Same as <code>spark.dynamicAllocation.schedulerBacklogTimeout</code>, but used only for
    subsequent executor requests. For more detail, see this
    <a href="job-scheduling.html#resource-allocation-policy">description</a>.