`spark.ml`'s PowerIterationClustering implementation takes the following parameters:

* `k`: the number of clusters to create
* `initMode`: param for the initialization algorithm
* `maxIter`: param for maximum number of iterations
* `srcCol`: param for the name of the input column for source vertex IDs
* `dstCol`: name of the input column for destination vertex IDs
* `weightCol`: Param for weight column name

**Examples**

<div class="codetabs">

<div data-lang="python" markdown="1">
Refer to the [Python API docs](api/python/reference/api/pyspark.ml.clustering.PowerIterationClustering.html) for more details. {% include_example python/ml/power_iteration_clustering_example.py %}
</div>

<div data-lang="scala" markdown="1">
Refer to the [Scala API docs](api/scala/org/apache/spark/ml/clustering/PowerIterationClustering.html) for more details. {% include_example scala/org/apache/spark/examples/ml/PowerIterationClusteringExample.scala %}
</div>

<div data-lang="java" markdown="1">
Refer to the [Java API docs](api/java/org/apache/spark/ml/clustering/PowerIterationClustering.html) for more details. {% include_example java/org/apache/spark/examples/ml/JavaPowerIterationClusteringExample.java %}
</div>

<div data-lang="r" markdown="1">

Refer to the [R API docs](api/R/reference/spark.powerIterationClustering.html) for more details. {% include_example r/ml/powerIterationClustering.R %}
</div>

</div>
