<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.connect.grpc.binding.port</code></td>
  <td>
    15002
  </td>
  <td>Port for Spark Connect server to bind.</td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.connect.grpc.interceptor.classes</code></td>
  <td>
    (none)
  </td>
  <td>Comma separated list of class names that must implement the <code>io.grpc.ServerInterceptor</code> interface</td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.connect.grpc.arrow.maxBatchSize</code></td>
  <td>
    4m
  </td>
  <td>When using Apache Arrow, limit the maximum size of one arrow batch that can be sent from server side to client side. Currently, we conservatively use 70% of it because the size is not accurate but estimated.</td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.connect.grpc.maxInboundMessageSize</code></td>
  <td>
    134217728
  </td>
  <td>Sets the maximum inbound message size for the gRPC requests. Requests with a larger payload will fail.</td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.connect.extensions.relation.classes</code></td>
  <td>
    (none)
  </td>
  <td>Comma separated list of classes that implement the trait <code>org.apache.spark.sql.connect.plugin.RelationPlugin</code> to support custom
Relation types in proto.</td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.connect.extensions.expression.classes</code></td>
  <td>
    (none)
  </td>
  <td>Comma separated list of classes that implement the trait
<code>org.apache.spark.sql.connect.plugin.ExpressionPlugin</code> to support custom
Expression types in proto.</td>
  <td>3.4.0</td>
</tr>
<tr>
  <td><code>spark.connect.extensions.command.classes</code></td>
  <td>
    (none)
  </td>
  <td>Comma separated list of classes that implement the trait
<code>org.apache.spark.sql.connect.plugin.CommandPlugin</code> to support custom
Command types in proto.</td>
  <td>3.4.0</td>
</tr>
</table>

### Security

Please refer to the [Security](security.html) page for available options on how to secure different
Spark subsystems. ### Spark SQL

#### Runtime SQL Configuration

Runtime SQL configurations are per-session, mutable Spark SQL configurations. They can be set with initial values by the config file
and command-line options with `--conf/-c` prefixed, or by setting `SparkConf` that are used to create `SparkSession`. Also, they can be set and queried by SET commands and reset to their initial values by RESET command,
or by `SparkSession.conf`'s setter and getter methods in runtime. {% include_api_gen generated-runtime-sql-config-table.html %}

#### Static SQL Configuration

Static SQL configurations are cross-session, immutable Spark SQL configurations. They can be set with final values by the config file
and command-line options with `--conf/-c` prefixed, or by setting `SparkConf` that are used to create `SparkSession`. External users can query the static sql config values via `SparkSession.conf` or via set command, e.g.