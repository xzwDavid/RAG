</td>
  <td>3.5.0</td>
</tr>
</table>

#### Available patterns for SHS custom executor log URL

<table>
    <thead><tr><th>Pattern</th><th>Meaning</th></tr></thead>
    <tr>
      <td>&#123;&#123;HTTP_SCHEME&#125;&#125;</td>
      <td><code>http://</code> or <code>https://</code> according to YARN HTTP policy. (Configured via <code>yarn.http.policy</code>)</td>
    </tr>
    <tr>
      <td>&#123;&#123;NM_HOST&#125;&#125;</td>
      <td>The "host" of node where container was run.</td>
    </tr>
    <tr>
      <td>&#123;&#123;NM_PORT&#125;&#125;</td>
      <td>The "port" of node manager where container was run.</td>
    </tr>
    <tr>
      <td>&#123;&#123;NM_HTTP_PORT&#125;&#125;</td>
      <td>The "port" of node manager's http server where container was run.</td>
    </tr>
    <tr>
      <td>&#123;&#123;NM_HTTP_ADDRESS&#125;&#125;</td>
      <td>Http URI of the node on which the container is allocated.</td>
    </tr>
    <tr>
      <td>&#123;&#123;CLUSTER_ID&#125;&#125;</td>
      <td>The cluster ID of Resource Manager. (Configured via <code>yarn.resourcemanager.cluster-id</code>)</td>
    </tr>
    <tr>
      <td>&#123;&#123;CONTAINER_ID&#125;&#125;</td>
      <td>The ID of container.</td>
    </tr>
    <tr>
      <td>&#123;&#123;USER&#125;&#125;</td>
      <td><code>SPARK_USER</code> on system environment.</td>
    </tr>
    <tr>
      <td>&#123;&#123;FILE_NAME&#125;&#125;</td>
      <td><code>stdout</code>, <code>stderr</code>.</td>
    </tr>
</table>

For example, suppose you would like to point log url link to Job History Server directly instead of let NodeManager http server redirects it, you can configure `spark.history.custom.executor.log.url` as below:

<code>&#123;&#123;HTTP_SCHEME&#125;&#125;&lt;JHS_HOST&gt;:&lt;JHS_PORT&gt;/jobhistory/logs/&#123;&#123;NM_HOST&#125;&#125;:&#123;&#123;NM_PORT&#125;&#125;/&#123;&#123;CONTAINER_ID&#125;&#125;/&#123;&#123;CONTAINER_ID&#125;&#125;/&#123;&#123;USER&#125;&#125;/&#123;&#123;FILE_NAME&#125;&#125;?start=-4096</code>

NOTE: you need to replace `<JHS_HOST>` and `<JHS_PORT>` with actual value.