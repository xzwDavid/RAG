HybridStore will first write data
      to an in-memory store and having a background thread that dumps data to a disk store after the writing
      to in-memory store is completed. </td>
    <td>3.1.0</td>
  </tr>
  <tr>
    <td>spark.history.store.hybridStore.maxMemoryUsage</td>
    <td>2g</td>
    <td>
      Maximum memory space that can be used to create HybridStore. The HybridStore co-uses the heap memory,
      so the heap memory should be increased through the memory option for SHS if the HybridStore is enabled. </td>
    <td>3.1.0</td>
  </tr>
  <tr>
    <td>spark.history.store.hybridStore.diskBackend</td>
    <td>ROCKSDB</td>
    <td>
      Specifies a disk-based store used in hybrid store; ROCKSDB or LEVELDB (deprecated). </td>
    <td>3.3.0</td>
  </tr>
  <tr>
    <td>spark.history.fs.update.batchSize</td>
    <td>Int.MaxValue</td>
    <td>
      Specifies the batch size for updating new eventlog files. This controls each scan process to be completed within a reasonable time, and such
      prevent the initial scan from running too long and blocking new eventlog files to
      be scanned in time in large environments. </td>
    <td>3.4.0</td>
  </tr>
</table>

Note that in all of these UIs, the tables are sortable by clicking their headers,
making it easy to identify slow tasks, data skew, etc. Note

1. The history server displays both completed and incomplete Spark jobs. If an application makes
multiple attempts after failures, the failed attempts will be displayed, as well as any ongoing
incomplete attempt or the final successful attempt. 1. Incomplete applications are only updated intermittently. The time between updates is defined
by the interval between checks for changed files (`spark.history.fs.update.interval`). On larger clusters, the update interval may be set to large values. The way to view a running application is actually to view its own web UI. 1. Applications which exited without registering themselves as completed will be listed
as incomplete —even though they are no longer running. This can happen if an application
crashes. 1. One way to signal the completion of a Spark job is to stop the Spark Context
explicitly (`sc.stop()`), or in Python using the `with SparkContext() as sc:` construct
to handle the Spark Context setup and tear down. ## REST API

In addition to viewing the metrics in the UI, they are also available as JSON. This gives developers
an easy way to create new visualizations and monitoring tools for Spark. The JSON is available for
both running applications, and in the history server. The endpoints are mounted at `/api/v1`. For example,
for the history server, they would typically be accessible at `http://<server-url>:18080/api/v1`, and
for a running application, at `http://localhost:4040/api/v1`. In the API, an application is referenced by its application ID, `[app-id]`. When running on YARN, each application may have multiple attempts, but there are attempt IDs
only for applications in cluster mode, not applications in client mode. Applications in YARN cluster mode
can be identified by their `[attempt-id]`. In the API listed below, when running in YARN cluster mode,
`[app-id]` will actually be `[base-app-id]/[attempt-id]`, where `[base-app-id]` is the YARN application ID. <table>
  <thead><tr><th>Endpoint</th><th>Meaning</th></tr></thead>
  <tr>
    <td><code>/applications</code></td>
    <td>A list of all applications.