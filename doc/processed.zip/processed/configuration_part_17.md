This helps to prevent OOM by avoiding underestimating shuffle
    block size when fetch shuffle blocks. </td>
  <td>2.2.1</td>
</tr>
<tr>
  <td><code>spark.shuffle.accurateBlockSkewedFactor</code></td>
  <td>-1.0</td>
  <td>
    A shuffle block is considered as skewed and will be accurately recorded in
    <code>HighlyCompressedMapStatus</code> if its size is larger than this factor multiplying
    the median shuffle block size or <code>spark.shuffle.accurateBlockThreshold</code>. It is
    recommended to set this parameter to be the same as
    <code>spark.sql.adaptive.skewJoin.skewedPartitionFactor</code>. Set to -1.0 to disable this
    feature by default. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.registration.timeout</code></td>
  <td>5000</td>
  <td>
    Timeout in milliseconds for registration to the external shuffle service. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.registration.maxAttempts</code></td>
  <td>3</td>
  <td>
    When we fail to register to the external shuffle service, we will retry for maxAttempts times. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.reduceLocality.enabled</code></td>
  <td>true</td>
  <td>
    Whether to compute locality preferences for reduce tasks. </td>
  <td>1.5.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.mapOutput.minSizeForBroadcast</code></td>
  <td>512k</td>
  <td>
    The size at which we use Broadcast to send the map output statuses to the executors. </td>
  <td>2.0.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.detectCorrupt</code></td>
  <td>true</td>
  <td>
    Whether to detect any corruption in fetched blocks. </td>
  <td>2.2.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.detectCorrupt.useExtraMemory</code></td>
  <td>false</td>
  <td>
    If enabled, part of a compressed/encrypted stream will be de-compressed/de-crypted by using extra memory
    to detect early corruption. Any IOException thrown will cause the task to be retried once
    and if it fails again with same exception, then FetchFailedException will be thrown to retry previous stage. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.useOldFetchProtocol</code></td>
  <td>false</td>
  <td>
    Whether to use the old protocol while doing the shuffle block fetching. It is only enabled while we need the
    compatibility in the scenario of new Spark version job fetching shuffle blocks from old version external shuffle service. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.readHostLocalDisk</code></td>
  <td>true</td>
  <td>
    If enabled (and <code>spark.shuffle.useOldFetchProtocol</code> is disabled, shuffle blocks requested from those block managers
    which are running on the same host are read from the disk directly instead of being fetched as remote blocks over the network.