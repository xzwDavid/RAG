</td>
  <td>3.1.0</td>
</tr>
<tr>
  <td>spark.sql.parquet.int96RebaseModeInWrite</td>
  <td><code>EXCEPTION</code></td>
  <td>The rebasing mode for the values of the <code>INT96</code> timestamp type from the Proleptic Gregorian to Julian calendar:<br>
    <ul>
      <li><code>EXCEPTION</code>: Spark will fail the writing if it sees ancient timestamps that are ambiguous between the two calendars.</li>
      <li><code>CORRECTED</code>: Spark will not do rebase and write the dates/timestamps as it is.</li>
      <li><code>LEGACY</code>: Spark will rebase INT96 timestamps from Proleptic Gregorian calendar to the legacy hybrid (Julian + Gregorian) calendar when writing Parquet files.</li>
    </ul>
  </td>
  <td>3.1.0</td>
</tr>
</table>
