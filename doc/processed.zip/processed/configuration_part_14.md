When the number of hosts in the cluster increase, it might lead to very large number
    of inbound connections to one or more nodes, causing the workers to fail under load. By allowing it to limit the number of fetch requests, this scenario can be mitigated. </td>
  <td>2.0.0</td>
</tr>
<tr>
  <td><code>spark.reducer.maxBlocksInFlightPerAddress</code></td>
  <td>Int.MaxValue</td>
  <td>
    This configuration limits the number of remote blocks being fetched per reduce task from a
    given host port. When a large number of blocks are being requested from a given address in a
    single fetch or simultaneously, this could crash the serving executor or Node Manager. This
    is especially useful to reduce the load on the Node Manager when external shuffle is enabled. You can mitigate this issue by setting it to a lower value. </td>
  <td>2.2.1</td>
</tr>
<tr>
  <td><code>spark.shuffle.compress</code></td>
  <td>true</td>
  <td>
    Whether to compress map output files. Generally a good idea. Compression will use
    <code>spark.io.compression.codec</code>. </td>
  <td>0.6.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.file.buffer</code></td>
  <td>32k</td>
  <td>
    Size of the in-memory buffer for each shuffle file output stream, in KiB unless otherwise
    specified. These buffers reduce the number of disk seeks and system calls made in creating
    intermediate shuffle files. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.file.merge.buffer</code></td>
  <td>32k</td>
  <td>
    Size of the in-memory buffer for each shuffle file input stream, in KiB unless otherwise
    specified. These buffers use off-heap buffers and are related to the number of files in
    the shuffle file. Too large buffers should be avoided. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.unsafe.file.output.buffer</code></td>
  <td>32k</td>
  <td>
    Deprecated since Spark 4.0, please use <code>spark.shuffle.localDisk.file.output.buffer</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.localDisk.file.output.buffer</code></td>
  <td>32k</td>
  <td>
    The file system for this buffer size after each partition is written in all local disk shuffle writers. In KiB unless otherwise specified. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.spill.diskWriteBufferSize</code></td>
  <td>1024 * 1024</td>
  <td>
    The buffer size, in bytes, to use when writing the sorted records to an on-disk file. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.io.maxRetries</code></td>
  <td>3</td>
  <td>
    (Netty only) Fetches that fail due to IO-related exceptions are automatically retried if this is
    set to a non-zero value. This retry logic helps stabilize large shuffles in the face of long GC
    pauses or transient network connectivity issues.