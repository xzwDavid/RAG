</td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.filterPushdown</code></td>
  <td>true</td>
  <td>Enables Parquet filter push-down optimization when set to true.</td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.aggregatePushdown</code></td>
  <td>false</td>
  <td>
    If true, aggregates will be pushed down to Parquet for optimization. Support MIN, MAX
    and COUNT as aggregate expression. For MIN/MAX, support boolean, integer, float and date
    type. For COUNT, support all data types. If statistics is missing from any Parquet file
    footer, exception would be thrown. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.hive.convertMetastoreParquet</code></td>
  <td>true</td>
  <td>
    When set to false, Spark SQL will use the Hive SerDe for parquet tables instead of the built in
    support. </td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.mergeSchema</code></td>
  <td>false</td>
  <td>
    <p>
      When true, the Parquet data source merges schemas collected from all data files, otherwise the
      schema is picked from the summary file or a random data file if no summary file is available. </p>
  </td>
  <td>1.5.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.respectSummaryFiles</code></td>
  <td>false</td>
  <td>
    When true, we make assumption that all part-files of Parquet are consistent with
    summary files and we will ignore them when merging schema. Otherwise, if this is
    false, which is the default, we will merge all part-files. This should be considered
    as expert-only option, and shouldn't be enabled before knowing what it means exactly. </td>
  <td>1.5.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.writeLegacyFormat</code></td>
  <td>false</td>
  <td>
    If true, data will be written in a way of Spark 1.4 and earlier. For example, decimal values
    will be written in Apache Parquet's fixed-length byte array format, which other systems such as
    Apache Hive and Apache Impala use. If false, the newer format in Parquet will be used. For
    example, decimals will be written in int-based format. If Parquet output is intended for use
    with systems that do not support this newer format, set to true. </td>
  <td>1.6.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.enableVectorizedReader</code></td>
  <td>true</td>
  <td>
    Enables vectorized parquet decoding. </td>
  <td>2.0.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.enableNestedColumnVectorizedReader</code></td>
  <td>true</td>
  <td>
    Enables vectorized Parquet decoding for nested columns (e.g., struct, list, map). Requires <code>spark.sql.parquet.enableVectorizedReader</code> to be enabled.