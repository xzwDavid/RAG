- DayTimeIntervalType
- YearMonthIntervalType
- CalendarIntervalType
- ArrayType
- MapType
- StructType
- UserDefinedType
- NullType
- ObjectType
- VariantType

### Mapping Spark SQL Data Types from Microsoft SQL Server

The below table describes the data type conversions from Microsoft SQL Server data types to Spark SQL Data Types,
when reading data from a Microsoft SQL Server table using the built-in jdbc data source with the mssql-jdbc
as the activated JDBC Driver.