

### Description
​
`DESCRIBE DATABASE` statement returns the metadata of an existing database. The metadata information includes database
name, database comment, and database location on the filesystem. If the optional `EXTENDED` option is specified, it
returns the basic metadata information along with the database properties. The `DATABASE` and `SCHEMA` are
interchangeable. ### Syntax

```sql
{ DESC | DESCRIBE } DATABASE [ EXTENDED ] db_name
```

### Parameters

* **db_name**

    Specifies a name of an existing database or an existing schema in the system. If the name does not exist, an
    exception is thrown. ### Examples

```sql
-- Create employees DATABASE
CREATE DATABASE employees COMMENT 'For software companies';

-- Describe employees DATABASE. -- Returns Database Name, Description and Root location of the filesystem
-- for the employees DATABASE. DESCRIBE DATABASE employees;
+