The following extra configuration options are available when the shuffle service is running on YARN:

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.yarn.shuffle.stopOnFailure</code></td>
  <td><code>false</code></td>
  <td>
    Whether to stop the NodeManager when there's a failure in the Spark Shuffle Service's
    initialization. This prevents application failures caused by running containers on
    NodeManagers where the Spark Shuffle Service is not running. </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.yarn.shuffle.service.metrics.namespace</code></td>
  <td><code>sparkShuffleService</code></td>
  <td>
    The namespace to use when emitting shuffle service metrics into Hadoop metrics2 system of the
    NodeManager. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.yarn.shuffle.service.logs.namespace</code></td>
  <td><code>(not set)</code></td>
  <td>
    A namespace which will be appended to the class name when forming the logger name to use for
    emitting logs from the YARN shuffle service, like
    <code>org.apache.spark.network.yarn.YarnShuffleService.logsNamespaceValue</code>. Since some logging frameworks
    may expect the logger name to look like a class name, it's generally recommended to provide a value which
    would be a valid Java package or class name and not include spaces. </td>
  <td>3.3.0</td>
</tr>
<tr>
  <td><code>spark.shuffle.service.db.backend</code></td>
  <td>ROCKSDB</td>
  <td>
    When work-preserving restart is enabled in YARN, this is used to specify the disk-base store used
    in shuffle service state store, supports `ROCKSDB` and `LEVELDB` (deprecated) with `ROCKSDB` as default value. The original data store in `RocksDB/LevelDB` will not be automatically converted to another kind
    of storage now. The original data store will be retained and the new type data store will be
    created when switching storage types. </td>
  <td>3.4.0</td>
</tr>
</table>

Please note that the instructions above assume that the default shuffle service name,
`spark_shuffle`, has been used. It is possible to use any name here, but the values used in the
YARN NodeManager configurations must match the value of `spark.shuffle.service.name` in the
Spark application. The shuffle service will, by default, take all of its configurations from the Hadoop Configuration
used by the NodeManager (e.g. `yarn-site.xml`). However, it is also possible to configure the
shuffle service independently using a file named `spark-shuffle-site.xml` which should be placed
onto the classpath of the shuffle service (which is, by default, shared with the classpath of the
NodeManager). The shuffle service will treat this as a standard Hadoop Configuration resource and
overlay it on top of the NodeManager's configuration. # Launching your application with Apache Oozie

Apache Oozie can launch Spark applications as part of a workflow. In a secure cluster, the launched application will need the relevant tokens to access the cluster's
services. If Spark is launched with a keytab, this is automatic. However, if Spark is to be launched without a keytab, the responsibility for setting up security
must be handed over to Oozie. The details of configuring Oozie for secure clusters and obtaining
credentials for a job can be found on the [Oozie web site](http://oozie.apache.org/)
in the "Authentication" section of the specific release's documentation.