Set to empty string to suppress</td>
      <td>write</td>
  </tr>

  <tr>
    <td><code>arrayElementName</code></td>
    <td><code>item</code></td>
    <td>Name of XML element that encloses each element of an array-valued column when writing.</td>
    <td>write</td>
  </tr>

  <tr>
    <td><code>nullValue</code></td>
    <td>null</td>
    <td>Sets the string representation of a null value. Default is string null. When this is null, it does not write attributes and elements for fields.</td>
    <td>read/write</td>
  </tr>

  <tr>
    <td><code>wildcardColName</code></td>
    <td><code>xs_any</code></td>
    <td>Name of a column existing in the provided schema which is interpreted as a 'wildcard'. It must have type string or array of strings. It will match any XML child element that is not otherwise matched by the schema. The XML of the child becomes the string value of the column. If an array, then all unmatched elements will be returned as an array of strings. As its name implies, it is meant to emulate XSD's xs:any type.</td>
    <td>read</td>
  </tr>

  <tr>
    <td><code>compression</code></td>
    <td><code>none</code></td>
    <td>Compression codec to use when saving to file. This can be one of the known case-insensitive shortened names (none, bzip2, gzip, lz4, snappy and deflate). XML built-in functions ignore this option.</td>
    <td>write</td>
  </tr>

  <tr>
      <td><code>validateName</code></td>
      <td><code>true</code></td>
      <td>If true, throws error on XML element name validation failure. For example, SQL field names can have spaces, but XML element names cannot.</td>
      <td>write</td>
  </tr>

</table>
Other generic options can be found in <a href="https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html"> Generic File Source Options</a>. 