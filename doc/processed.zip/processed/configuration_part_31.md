This
    option should be enabled to work around <code>Configuration</code> thread-safety issues (see
    <a href="https://issues.apache.org/jira/browse/SPARK-2546">SPARK-2546</a> for more details). This is disabled by default in order to avoid unexpected performance regressions for jobs that
    are not affected by these issues. </td>
  <td>1.0.3</td>
</tr>
<tr>
  <td><code>spark.hadoop.validateOutputSpecs</code></td>
  <td>true</td>
  <td>
    If set to true, validates the output specification (e.g. checking if the output directory already exists)
    used in saveAsHadoopFile and other variants. This can be disabled to silence exceptions due to pre-existing
    output directories. We recommend that users do not disable this except if trying to achieve compatibility
    with previous versions of Spark. Simply use Hadoop's FileSystem API to delete output directories by hand. This setting is ignored for jobs generated through Spark Streaming's StreamingContext, since data may
    need to be rewritten to pre-existing output directories during checkpoint recovery. </td>
  <td>1.0.1</td>
</tr>
<tr>
  <td><code>spark.storage.memoryMapThreshold</code></td>
  <td>2m</td>
  <td>
    Size of a block above which Spark memory maps when reading a block from disk. Default unit is bytes,
    unless specified otherwise. This prevents Spark from memory mapping very small blocks. In general,
    memory mapping has high overhead for blocks close to or below the page size of the operating system. </td>
  <td>0.9.2</td>
</tr>
<tr>
  <td><code>spark.storage.decommission.enabled</code></td>
  <td>false</td>
  <td>
    Whether to decommission the block manager when decommissioning executor. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.storage.decommission.shuffleBlocks.enabled</code></td>
  <td>true</td>
  <td>
    Whether to transfer shuffle blocks during block manager decommissioning. Requires a migratable shuffle resolver
    (like sort based shuffle). </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.storage.decommission.shuffleBlocks.maxThreads</code></td>
  <td>8</td>
  <td>
    Maximum number of threads to use in migrating shuffle files. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.storage.decommission.rddBlocks.enabled</code></td>
  <td>true</td>
  <td>
    Whether to transfer RDD blocks during block manager decommissioning. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.storage.decommission.fallbackStorage.path</code></td>
  <td>(none)</td>
  <td>
    The location for fallback storage during block manager decommissioning. For example, <code>s3a://spark-storage/</code>. In case of empty, fallback storage is disabled. The storage should be managed by TTL because Spark will not clean it up. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.storage.decommission.fallbackStorage.cleanUp</code></td>
  <td>false</td>
  <td>
    If true, Spark cleans up its fallback storage data during shutting down.