It can be in one of following formats:
    * a [SELECT](sql-ref-syntax-qry-select.html) statement
    * a [Inline Table](sql-ref-syntax-qry-select-inline-table.html) statement
    * a `FROM` statement

### Examples

#### Spark format
```sql
INSERT OVERWRITE DIRECTORY '/tmp/destination'
    USING parquet
    OPTIONS (col1 1, col2 2, col3 'test')
    SELECT * FROM test_table;

INSERT OVERWRITE DIRECTORY
    USING parquet
    OPTIONS ('path' '/tmp/destination', col1 1, col2 2, col3 'test')
    SELECT * FROM test_table;
```

#### Hive format

```sql
INSERT OVERWRITE LOCAL DIRECTORY '/tmp/destination'
    STORED AS orc
    SELECT * FROM test_table;

INSERT OVERWRITE LOCAL DIRECTORY '/tmp/destination'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
    SELECT * FROM test_table;
```

### Related Statements

* [INSERT TABLE statement](sql-ref-syntax-dml-insert-table.html)
