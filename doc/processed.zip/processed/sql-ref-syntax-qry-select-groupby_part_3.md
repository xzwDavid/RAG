Group by `id`. SELECT id, sum(quantity) FROM dealer GROUP BY id ORDER BY id;
+