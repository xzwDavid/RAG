

### Description

The `DESCRIBE QUERY` statement is used to return the metadata of output
of a query. A shorthand `DESC` may be used instead of `DESCRIBE` to
describe the query output. ### Syntax

```sql
{ DESC | DESCRIBE } [ QUERY ] input_statement
```

### Parameters

* **QUERY**
    This clause is optional and may be omitted. * **input_statement**

    Specifies a result set producing statement and may be one of the following: 

    * a `SELECT` statement
    * a `CTE(Common table expression)` statement
    * an `INLINE TABLE` statement
    * a `TABLE` statement
    * a `FROM` statement`

    Please refer to [select-statement](sql-ref-syntax-qry-select.html)
    for a detailed syntax of the query parameter. ### Examples

```sql
-- Create table `person`
CREATE TABLE person (name STRING , age INT COMMENT 'Age column', address STRING);

-- Returns column metadata information for a simple select query
DESCRIBE QUERY SELECT age, sum(age) FROM person GROUP BY age;
+