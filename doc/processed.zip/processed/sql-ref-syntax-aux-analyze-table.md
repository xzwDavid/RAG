

### Description

The `ANALYZE TABLE` statement collects statistics about one specific table or all the tables in one specified database,
that are to be [used by the query optimizer][stats] to find a better query execution plan. These statistics are stored in the catalog. [stats]: sql-performance-tuning.html#leveraging-statistics

### Syntax

```sql
ANALYZE TABLE table_identifier [ partition_spec ]
    COMPUTE STATISTICS [ NOSCAN | FOR COLUMNS col [ , ... ] | FOR ALL COLUMNS ]
```

```sql
ANALYZE TABLES [ { FROM | IN } database_name ] COMPUTE STATISTICS [ NOSCAN ]
```

### Parameters

* **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **partition_spec**

    An optional parameter that specifies a comma separated list of key and value pairs
    for partitions. When specified, partition statistics is returned. **Syntax:** `PARTITION ( partition_col_name [ = partition_col_val ] [ , ... ] )`

* **{ FROM `|` IN } database_name**

  Specifies the name of the database to be analyzed. Without a database name, `ANALYZE` collects all tables in the current database that the current user has permission to analyze. * **NOSCAN**

  Collects only the table's size in bytes (which does not require scanning the entire table). * **FOR COLUMNS col [ , ... ] `|` FOR ALL COLUMNS**

  Collects column statistics for each column specified, or alternatively for every column, as well as table statistics. If no analyze option is specified, both number of rows and size in bytes are collected. ### Examples

```sql
CREATE DATABASE school_db;
USE school_db;

CREATE TABLE teachers (name STRING, teacher_id INT);
INSERT INTO teachers VALUES ('Tom', 1), ('Jerry', 2);

CREATE TABLE students (name STRING, student_id INT) PARTITIONED BY (student_id);
INSERT INTO students VALUES ('Mark', 111111), ('John', 222222);

ANALYZE TABLE students COMPUTE STATISTICS NOSCAN;

DESC EXTENDED students;
+