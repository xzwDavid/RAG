<table>
  <thead>
    <tr>
      <th>Component</th>
      <th>Port</th>
      <th>JSON End Point</th>
      <th>Prometheus End Point</th>
    </tr>
  </thead>
  <tr>
    <td>Master</td>
    <td>8080</td>
    <td><code>/metrics/master/json/</code></td>
    <td><code>/metrics/master/prometheus/</code></td>
  </tr>
  <tr>
    <td>Master</td>
    <td>8080</td>
    <td><code>/metrics/applications/json/</code></td>
    <td><code>/metrics/applications/prometheus/</code></td>
  </tr>
  <tr>
    <td>Worker</td>
    <td>8081</td>
    <td><code>/metrics/json/</code></td>
    <td><code>/metrics/prometheus/</code></td>
  </tr>
  <tr>
    <td>Driver</td>
    <td>4040</td>
    <td><code>/metrics/json/</code></td>
    <td><code>/metrics/prometheus/</code></td>
  </tr>
  <tr>
    <td>Driver</td>
    <td>4040</td>
    <td><code>/api/v1/applications/{id}/executors/</code></td>
    <td><code>/metrics/executors/prometheus/</code></td>
  </tr>
</table>

Spark also supports a Ganglia sink which is not included in the default build due to
licensing restrictions:

* `GangliaSink`: Sends metrics to a Ganglia node or multicast group. To install the `GangliaSink` you'll need to perform a custom build of Spark. _**Note that
by embedding this library you will include [LGPL](http://www.gnu.org/copyleft/lesser.html)-licensed
code in your Spark package**_. For sbt users, set the
`SPARK_GANGLIA_LGPL` environment variable before building. For Maven users, enable
the `-Pspark-ganglia-lgpl` profile. In addition to modifying the cluster's Spark build
user applications will need to link to the `spark-ganglia-lgpl` artifact. The syntax of the metrics configuration file and the parameters available for each sink are defined
in an example configuration file,
`$SPARK_HOME/conf/metrics.properties.template`. When using Spark configuration parameters instead of the metrics configuration file, the relevant
parameter names are composed by the prefix `spark.metrics.conf.` followed by the configuration
details, i.e. the parameters take the following form:
`spark.metrics.conf.[instance|*].sink.[sink_name].[parameter_name]`.