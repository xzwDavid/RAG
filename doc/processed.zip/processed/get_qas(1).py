import os
import json
import random
from dotenv import load_dotenv
import random
import requests
import time
from typing import Optional
from datetime import datetime

# class API_CLIENT():
#   def __init__(self):
#     #Sets the current working directory to be the same as the file.
#     os.chdir(os.path.dirname(os.path.abspath(__file__)))

#     #Load environment file for secrets.
#     #Create Azure client
#     self.client = AzureOpenAI(
#         api_key='bc66fc90cd3448e68de391ea7e0074f0',
#         api_version='2024-06-01',
#         azure_endpoint = 'https://api.umgpt.umich.edu/azure-openai-api',
#         organization = "016732"
#     )
#     self.model = 'gpt-4o'

#   def send_query(self, inputPrompt, userAnswer, correctAnswer):
#    # Format the prompt with the given instruction, response, and reference answer
#     prompt = EVALUATION_PROMPT.format(
#         instruction=inputPrompt,
#         response=userAnswer,
#         reference_answer=correctAnswer
#     )

#     #Create Query
#     messages=[
#             {"role": "system","content": "You are a fair evaluator language model"},
#             {"role": "user","content": prompt},
#         ]




def load_json_tree(json_file):
    """
    Load the JSON tree structure from a file.
    """
    with open(json_file, 'r', encoding='utf-8') as f:
        return json.load(f)


def get_leaf_paths_from_tree(tree, current_path=None):
    """
    Recursively find all paths from the JSON tree that end at a leaf node.
    """
    if current_path is None:
        current_path = []
    
    current_path = current_path + [tree["name"]]

    if not tree.get("children"):  # If no children, it's a leaf node
        return [current_path]
    
    leaf_paths = []
    for child in tree["children"]:
        leaf_paths.extend(get_leaf_paths_from_tree(child, current_path))
    
    return leaf_paths


def select_random_paths_from_tree(tree, num_paths=1):
    """
    Select a specified number of random paths from the JSON tree.
    """
    leaf_paths = get_leaf_paths_from_tree(tree)
    samples = random.sample(leaf_paths, min(num_paths, len(leaf_paths)))

    return [sample[random.randint(0, len(sample) - 1):] for sample in samples]


def find_markdown_files_along_path(path):
    """
    Find Markdown files that correspond to nodes in the path.
    """
    files_along_path = []
    
    # Traverse through the path and look for corresponding .md files
    for p in path:
        md_file = f"{p}.md"
        if os.path.exists(md_file):
            files_along_path.append(md_file)
    
    return files_along_path


def combine_files(random_path, output_file="combined.md"):
    """
    Combines the content of Markdown files along the paths into a single file.
    """
    with open(output_file, 'w', encoding='utf-8') as outfile:
        
        # Get Markdown files along the path
        files_along_path = find_markdown_files_along_path(random_path)
        
        for file in files_along_path:
            if os.path.exists(file):
                
                with open(file, 'r', encoding='utf-8') as infile:
                    outfile.write(infile.read())
                
                outfile.write("\n\n")  # Separate files with a newline
            else:
                print(f"Warning: {file} not found!")
    
    print(f"All files have been combined into {output_file}")


def create_prompt_from_contents(contents):
    with open(contents, 'r', encoding='utf-8') as file:
        combined_content = file.read()

    prompt = (
        "Based on the following documents, please generate a question that requires combining all the documents to answer, "
        "and provide a detailed answer. "
        "Make sure the answer requires referencing content from all the documents.\n\n"
        "Document contents:\n"
        f"{combined_content}"
    )
    return prompt


def segment_question_answer(text):
    """
    Segments a string containing a question and answer into two parts: question and answer.

    Args:
        text (str): The input string containing **Question:** and **Answer:** sections.

    Returns:
        tuple: A tuple containing two strings: (question, answer).
    """
    # Split the text into two parts: before and after **Answer:**
    try:
        question_part, answer_part = text.split("Answer", 1)
        
        # Remove **Question:** and clean up extra whitespace
        question = question_part.replace("Question", "").strip()
        answer = answer_part.strip()
        
        return question, answer
    except ValueError:
        raise ValueError("The input text does not have the expected format with '**Question:**' and '**Answer:**'.")

def generate_question_and_answer(prompt, api_url, api_key, max_retries=3, delay_seconds=3) -> Optional[str]:
    """
    Generate question and answer with retry mechanism and delay between requests

    Args:
        prompt: The input prompt
        api_url: Azure OpenAI API URL
        api_key: API key
        max_retries: Maximum number of retry attempts
        delay_seconds: Delay between requests in seconds

    Returns:
        Generated answer or None if failed
    """
    headers = {
        'Content-Type': 'application/json',
        'api-key': api_key
    }
    payload = {
        "messages": [
            {"role": "system", "content": "You are a knowledgeable assistant."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 1000,
        "top_p": 0.95,
        "frequency_penalty": 0,
        "presence_penalty": 0
    }

    for attempt in range(max_retries):
        try:
            # Add delay before each request (except first attempt)
            if attempt > 0:
                time.sleep(delay_seconds)

            print(f"Making API request (attempt {attempt + 1}/{max_retries})...")
            response = requests.post(api_url, headers=headers, json=payload, timeout=30)

            if response.status_code == 200:
                result = response.json()
                return result['choices'][0]['message']['content']
            elif response.status_code == 429:  # Rate limit exceeded
                retry_after = int(response.headers.get('Retry-After', delay_seconds))
                # retry_after = 15
                print(f"Rate limit exceeded. Waiting {retry_after} seconds...")
                time.sleep(retry_after)
                continue
            else:
                print(f"Request failed with status code: {response.status_code}")
                print(f"Response content: {response.text}")

        except requests.RequestException as e:
            print(f"Request error occurred: {str(e)}")
            if attempt < max_retries - 1:
                print(f"Retrying in {delay_seconds} seconds...")
                time.sleep(delay_seconds)
            continue

    print("All retry attempts failed")
    return None

def save_results(question_answer, md_files_list, output_path):
    question, answer=segment_question_answer(question_answer)
    data = {
        'question': question,
        'answer': answer,
        'documents': md_files_list,
        'timestamp': datetime.now().isoformat()
    }
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    print(f"Results saved to {output_path}")

# Example usage: # Change this to your root folder path
output_dir = 'QA'
os.makedirs('QA/text', exist_ok=True)
os.makedirs('QA/qa', exist_ok=True)

md_tree = load_json_tree('md_tree.json')

os.environ['AZURE_OPENAI_API_KEY'] = 'aa25f3a2013941dd86abcf64a9972857'
os.environ['AZURE_OPENAI_API_URL'] = 'https://nsf-gen.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-08-01-preview'
load_dotenv()

        # Load configuration
api_url = os.getenv('AZURE_OPENAI_API_URL')
api_key = os.getenv('AZURE_OPENAI_API_KEY')

if not api_url or not api_key:
    raise ValueError("Please set AZURE_OPENAI_API_URL and AZURE_OPENAI_API_KEY environment variables")


n_QAs = 200
random_paths = select_random_paths_from_tree(md_tree, n_QAs)
print(random_paths)
for idx in range(195, n_QAs):
    md_files = ""

    # Print the selected paths and their corresponding files
    print(f"Path {idx}:")
    md_files += f"Path {idx}:\n"
    for file in random_paths[idx]:
        print(f"- {file}")
        md_files += f"{file}\n"

    contents = f"QA/text/combined_output_{idx}.md"
    # Example usage:
    combine_files(random_paths[idx], output_file=contents)

    prompt = create_prompt_from_contents(contents)
    question_answer = generate_question_and_answer(prompt, api_url, api_key)

    if question_answer:
        output_file = os.path.join(output_dir, f'qa/result_{idx}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')
        save_results(question_answer, md_files, output_file)

        delay = 60  # 5 seconds between processing pairs
        print(f"Waiting {delay} seconds before processing next pair...")
        time.sleep(delay)