

In Spark SQL, there are two options to comply with the SQL standard: `spark.sql.ansi.enabled` and `spark.sql.storeAssignmentPolicy` (See a table below for details). By default, `spark.sql.ansi.enabled` is `true` and Spark SQL uses an ANSI compliant dialect instead of being Hive compliant. For example, Spark will throw an exception at runtime instead of returning null results if the inputs to a SQL operator/function are invalid. Some ANSI dialect features may be not from the ANSI SQL standard directly, but their behaviors align with ANSI SQL's style. Moreover, Spark SQL has an independent option to control implicit casting behaviours when inserting rows in a table. The casting behaviours are defined as store assignment rules in the standard. By default, `spark.sql.storeAssignmentPolicy` is `ANSI` and Spark SQL complies with the ANSI store assignment rules. <table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.sql.ansi.enabled</code></td>
  <td>true</td>
  <td>
    When true, Spark tries to conform to the ANSI SQL specification: <br/>
    1. Spark SQL will throw runtime exceptions on invalid operations, including integer overflow
    errors, string parsing errors, etc. <br/>
    2. Spark will use different type coercion rules for resolving conflicts among data types. The rules are consistently based on data type precedence. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.sql.storeAssignmentPolicy</code></td>
  <td>ANSI</td>
  <td>
    When inserting a value into a column with different data type, Spark will perform type
    conversion. Currently, we support 3 policies for the type coercion rules: ANSI, legacy and
    strict.<br/>
    1. With ANSI policy, Spark performs the type coercion as per ANSI SQL. In practice, the behavior
    is mostly the same as PostgreSQL. It disallows certain unreasonable type conversions such as
    converting string to int or double to boolean. On inserting a numeric type column, an overflow
    error will be thrown if the value is out of the target data type's range.<br/>
    2. With legacy policy, Spark allows the type coercion as long as it is a valid Cast, which is
    very loose. e.g. converting string to int or double to boolean is allowed. It is also the only
    behavior in Spark 2.x and it is compatible with Hive.<br/>
    3. With strict policy, Spark doesn't allow any possible precision loss or data truncation in
    type coercion, e.g. converting double to int or decimal to double is not allowed. </td>
  <td>3.0.0</td>
</tr>
</table>

The following subsections present behaviour changes in arithmetic operations, type conversions, and SQL parsing when the ANSI mode enabled. For type conversions in Spark SQL, there are three kinds of them and this article will introduce them one by one: cast, store assignment and type coercion. ### Arithmetic Operations

In Spark SQL, by default, Spark throws an arithmetic exception at runtime for both interval and numeric type overflows. If `spark.sql.ansi.enabled` is `false`, then the decimal type will produce `null` values and other numeric types will behave in the same way as the corresponding operation in a Java/Scala program (e.g., if the sum of 2 integers is higher than the maximum value representable, the result is a negative number) which is the behavior of Spark 3 or older. ```sql
-- `spark.sql.ansi.enabled=true`
SELECT 2147483647 + 1;
org.apache.spark.SparkArithmeticException: [ARITHMETIC_OVERFLOW] integer overflow. Use 'try_add' to tolerate overflow and return NULL instead. If necessary set spark.sql.ansi.enabled to "false" to bypass this error.