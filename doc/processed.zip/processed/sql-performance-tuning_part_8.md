</td>
      <td>3.1.0</td>
    </tr>
    <tr>
      <td><code>spark.sql.adaptive.customCostEvaluatorClass</code></td>
      <td>(none)</td>
      <td>
        The custom cost evaluator class to be used for adaptive execution. If not being set, Spark will use its own <code>SimpleCostEvaluator</code> by default. </td>
      <td>3.2.0</td>
    </tr>
  </table>

## Storage Partition Join

Storage Partition Join (SPJ) is an optimization technique in Spark SQL that makes use the existing storage layout to avoid the shuffle phase. This is a generalization of the concept of Bucket Joins, which is only applicable for [bucketed](sql-data-sources-load-save-functions.html#bucketing-sorting-and-partitioning) tables, to tables partitioned by functions registered in FunctionCatalog. Storage Partition Joins are currently supported for compatible V2 DataSources. The following SQL properties enable Storage Partition Join in different join queries with various optimizations. <table class="spark-config">
    <thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
    <tr>
      <td><code>spark.sql.sources.v2.bucketing.enabled</code></td>
      <td>false</td>
      <td>
        When true, try to eliminate shuffle by using the partitioning reported by a compatible V2 data source. </td>
      <td>3.3.0</td>
    </tr>
    <tr>
      <td><code>spark.sql.sources.v2.bucketing.pushPartValues.enabled</code></td>
      <td>true</td>
      <td>
        When enabled, try to eliminate shuffle if one side of the join has missing partition values from the other side. This config requires <code>spark.sql.sources.v2.bucketing.enabled</code> to be true. </td>
      <td>3.4.0</td>
    </tr>
    <tr>
      <td><code>spark.sql.requireAllClusterKeysForCoPartition</code></td>
      <td>true</td>
      <td>
        When true, require the join or MERGE keys to be same and in the same order as the partition keys to eliminate shuffle. Hence, set to <b>false</b> in this situation to eliminate shuffle. </td>
      <td>3.4.0</td>
    </tr>
    <tr>
      <td><code>spark.sql.sources.v2.bucketing.partiallyClusteredDistribution.enabled</code></td>
      <td>false</td>
      <td>
        When true, and when the join is not a full outer join, enable skew optimizations to handle partitions with large amounts of data when avoiding shuffle. One side will be chosen as the big table based on table statistics, and the splits on this side will be partially-clustered. The splits of the other side will be grouped and replicated to match. This config requires both <code>spark.sql.sources.v2.bucketing.enabled</code> and <code>spark.sql.sources.v2.bucketing.pushPartValues.enabled</code> to be true.