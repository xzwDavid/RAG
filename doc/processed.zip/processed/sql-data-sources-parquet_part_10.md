</td>
  <td>3.4.0</td>
</tr>
<tr>
<td>spark.sql.parquet.datetimeRebaseModeInRead</td>
  <td><code>EXCEPTION</code></td>
  <td>The rebasing mode for the values of the <code>DATE</code>, <code>TIMESTAMP_MILLIS</code>, <code>TIMESTAMP_MICROS</code> logical types from the Julian to Proleptic Gregorian calendar:<br>
    <ul>
      <li><code>EXCEPTION</code>: Spark will fail the reading if it sees ancient dates/timestamps that are ambiguous between the two calendars.</li>
      <li><code>CORRECTED</code>: Spark will not do rebase and read the dates/timestamps as it is.</li>
      <li><code>LEGACY</code>: Spark will rebase dates/timestamps from the legacy hybrid (Julian + Gregorian) calendar to Proleptic Gregorian calendar when reading Parquet files.</li>
    </ul>
    This config is only effective if the writer info (like Spark, Hive) of the Parquet files is unknown. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td>spark.sql.parquet.datetimeRebaseModeInWrite</td>
  <td><code>EXCEPTION</code></td>
  <td>The rebasing mode for the values of the <code>DATE</code>, <code>TIMESTAMP_MILLIS</code>, <code>TIMESTAMP_MICROS</code> logical types from the Proleptic Gregorian to Julian calendar:<br>
    <ul>
      <li><code>EXCEPTION</code>: Spark will fail the writing if it sees ancient dates/timestamps that are ambiguous between the two calendars.</li>
      <li><code>CORRECTED</code>: Spark will not do rebase and write the dates/timestamps as it is.</li>
      <li><code>LEGACY</code>: Spark will rebase dates/timestamps from Proleptic Gregorian calendar to the legacy hybrid (Julian + Gregorian) calendar when writing Parquet files.</li>
    </ul>
  </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td>spark.sql.parquet.int96RebaseModeInRead</td>
  <td><code>EXCEPTION</code></td>
  <td>The rebasing mode for the values of the <code>INT96</code> timestamp type from the Julian to Proleptic Gregorian calendar:<br>
    <ul>
      <li><code>EXCEPTION</code>: Spark will fail the reading if it sees ancient INT96 timestamps that are ambiguous between the two calendars.</li>
      <li><code>CORRECTED</code>: Spark will not do rebase and read the dates/timestamps as it is.</li>
      <li><code>LEGACY</code>: Spark will rebase INT96 timestamps from the legacy hybrid (Julian + Gregorian) calendar to Proleptic Gregorian calendar when reading Parquet files.</li>
    </ul>
    This config is only effective if the writer info (like Spark, Hive) of the Parquet files is unknown.