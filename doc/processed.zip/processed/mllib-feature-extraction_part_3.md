Standardization can improve the convergence rate during the optimization process, and also prevents
against features with very large variances exerting an overly large influence during model training. ### Model Fitting

[`StandardScaler`](api/scala/org/apache/spark/mllib/feature/StandardScaler.html) has the
following parameters in the constructor:

* `withMean` False by default. Centers the data with mean before scaling. It will build a dense
output, so take care when applying to sparse input. * `withStd` True by default. Scales the data to unit standard deviation. We provide a [`fit`](api/scala/org/apache/spark/mllib/feature/StandardScaler.html) method in
`StandardScaler` which can take an input of `RDD[Vector]`, learn the summary statistics, and then
return a model which can transform the input dataset into unit standard deviation and/or zero mean features
depending how we configure the `StandardScaler`. This model implements [`VectorTransformer`](api/scala/org/apache/spark/mllib/feature/VectorTransformer.html)
which can apply the standardization on a `Vector` to produce a transformed `Vector` or on
an `RDD[Vector]` to produce a transformed `RDD[Vector]`. Note that if the variance of a feature is zero, it will return default `0.0` value in the `Vector`
for that feature. ### Example

The example below demonstrates how to load a dataset in libsvm format, and standardize the features
so that the new features have unit standard deviation and/or zero mean. <div class="codetabs">

<div data-lang="python" markdown="1">
Refer to the [`StandardScaler` Python docs](api/python/reference/api/pyspark.mllib.feature.StandardScaler.html) for more details on the API. {% include_example python/mllib/standard_scaler_example.py %}
</div>

<div data-lang="scala" markdown="1">
Refer to the [`StandardScaler` Scala docs](api/scala/org/apache/spark/mllib/feature/StandardScaler.html) for details on the API. {% include_example scala/org/apache/spark/examples/mllib/StandardScalerExample.scala %}
</div>

</div>

## Normalizer

Normalizer scales individual samples to have unit $L^p$ norm. This is a common operation for text
classification or clustering. For example, the dot product of two $L^2$ normalized TF-IDF vectors
is the cosine similarity of the vectors. [`Normalizer`](api/scala/org/apache/spark/mllib/feature/Normalizer.html) has the following
parameter in the constructor:

* `p` Normalization in $L^p$ space, $p = 2$ by default. `Normalizer` implements [`VectorTransformer`](api/scala/org/apache/spark/mllib/feature/VectorTransformer.html)
which can apply the normalization on a `Vector` to produce a transformed `Vector` or on
an `RDD[Vector]` to produce a transformed `RDD[Vector]`. Note that if the norm of the input is zero, it will return the input vector. ### Example

The example below demonstrates how to load a dataset in libsvm format, and normalizes the features
with $L^2$ norm, and $L^\infty$ norm. <div class="codetabs">

<div data-lang="python" markdown="1">
Refer to the [`Normalizer` Python docs](api/python/reference/api/pyspark.mllib.feature.Normalizer.html) for more details on the API. {% include_example python/mllib/normalizer_example.py %}
</div>

<div data-lang="scala" markdown="1">
Refer to the [`Normalizer` Scala docs](api/scala/org/apache/spark/mllib/feature/Normalizer.html) for details on the API.