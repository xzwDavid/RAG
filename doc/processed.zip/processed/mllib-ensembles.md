

* Table of contents
{:toc}

An [ensemble method](http://en.wikipedia.org/wiki/Ensemble_learning)
is a learning algorithm which creates a model composed of a set of other base models. `spark.mllib` supports two major ensemble algorithms: [`GradientBoostedTrees`](api/scala/org/apache/spark/mllib/tree/GradientBoostedTrees.html) and [`RandomForest`](api/scala/org/apache/spark/mllib/tree/RandomForest$.html). Both use [decision trees](mllib-decision-tree.html) as their base models. ## Gradient-Boosted Trees vs. Random Forests

Both [Gradient-Boosted Trees (GBTs)](mllib-ensembles.html#gradient-boosted-trees-gbts) and [Random Forests](mllib-ensembles.html#random-forests) are algorithms for learning ensembles of trees, but the training processes are different. There are several practical trade-offs:

 * GBTs train one tree at a time, so they can take longer to train than random forests. Random Forests can train multiple trees in parallel. * On the other hand, it is often reasonable to use smaller (shallower) trees with GBTs than with Random Forests, and training smaller trees takes less time. * Random Forests can be less prone to overfitting. Training more trees in a Random Forest reduces the likelihood of overfitting, but training more trees with GBTs increases the likelihood of overfitting. (In statistical language, Random Forests reduce variance by using more trees, whereas GBTs reduce bias by using more trees.)
 * Random Forests can be easier to tune since performance improves monotonically with the number of trees (whereas performance can start to decrease for GBTs if the number of trees grows too large). In short, both algorithms can be effective, and the choice should be based on the particular dataset. ## Random Forests

[Random forests](http://en.wikipedia.org/wiki/Random_forest)
are ensembles of [decision trees](mllib-decision-tree.html). Random forests are one of the most successful machine learning models for classification and
regression. They combine many decision trees in order to reduce the risk of overfitting. Like decision trees, random forests handle categorical features,
extend to the multiclass classification setting, do not require
feature scaling, and are able to capture non-linearities and feature interactions. `spark.mllib` supports random forests for binary and multiclass classification and for regression,
using both continuous and categorical features. `spark.mllib` implements random forests using the existing [decision tree](mllib-decision-tree.html)
implementation. Please see the decision tree guide for more information on trees. ### Basic algorithm

Random forests train a set of decision trees separately, so the training can be done in parallel. The algorithm injects randomness into the training process so that each decision tree is a bit
different. Combining the predictions from each tree reduces the variance of the predictions,
improving the performance on test data. #### Training

The randomness injected into the training process includes:

* Subsampling the original dataset on each iteration to get a different training set (a.k.a. bootstrapping). * Considering different random subsets of features to split on at each tree node. Apart from these randomizations, decision tree training is done in the same way as for individual decision trees. #### Prediction

To make a prediction on a new instance, a random forest must aggregate the predictions from its set of decision trees. This aggregation is done differently for classification and regression. *Classification*: Majority vote. Each tree's prediction is counted as a vote for one class. The label is predicted to be the class which receives the most votes. *Regression*: Averaging. Each tree predicts a real value. The label is predicted to be the average of the tree predictions. ### Usage tips

We include a few guidelines for using random forests by discussing the various parameters. We omit some decision tree parameters since those are covered in the [decision tree guide](mllib-decision-tree.html). The first two parameters we mention are the most important, and tuning them can often improve performance:

* **`numTrees`**: Number of trees in the forest. * Increasing the number of trees will decrease the variance in predictions, improving the model's test-time accuracy. * Training time increases roughly linearly in the number of trees. * **`maxDepth`**: Maximum depth of each tree in the forest.