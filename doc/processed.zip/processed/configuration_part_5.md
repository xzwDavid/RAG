<br/>
    <em>Note:</em> Additional memory includes PySpark executor memory
    (when <code>spark.executor.pyspark.memory</code> is not configured) and memory used by other
    non-executor processes running in the same container. The maximum memory size of container to
    running executor is determined by the sum of <code>spark.executor.memoryOverhead</code>,
    <code>spark.executor.memory</code>, <code>spark.memory.offHeap.size</code> and
    <code>spark.executor.pyspark.memory</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.driver.minMemoryOverhead</code></td>
  <td>384m</td>
  <td>
    The minimum amount of non-heap memory to be allocated per executor process, in MiB unless otherwise specified, if <code>spark.executor.memoryOverhead</code> is not defined. This option is currently supported on YARN and Kubernetes. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.memoryOverheadFactor</code></td>
  <td>0.10</td>
  <td>
    Fraction of executor memory to be allocated as additional non-heap memory per executor process. This is memory that accounts for things like VM overheads, interned strings,
    other native overheads, etc. This tends to grow with the container size. This value defaults to 0.10 except for Kubernetes non-JVM jobs, which defaults to
    0.40. This is done as non-JVM tasks need more non-JVM heap space and such tasks
    commonly fail with "Memory Overhead Exceeded" errors. This preempts this error
    with a higher default. This value is ignored if <code>spark.executor.memoryOverhead</code> is set directly. </td>
  <td>3.3.0</td>
</tr>
<tr>
 <td><code>spark.executor.resource.{resourceName}.amount</code></td>
  <td>0</td>
  <td>
    Amount of a particular resource type to use per executor process. If this is used, you must also specify the
    <code>spark.executor.resource.{resourceName}.discoveryScript</code>
    for the executor to find the resource on startup. </td>
  <td>3.0.0</td>
</tr>
<tr>
 <td><code>spark.executor.resource.{resourceName}.discoveryScript</code></td>
  <td>None</td>
  <td>
    A script for the executor to run to discover a particular resource type. This should
    write to STDOUT a JSON string in the format of the ResourceInformation class. This has a
    name and an array of addresses. </td>
  <td>3.0.0</td>
</tr>
<tr>
 <td><code>spark.executor.resource.{resourceName}.vendor</code></td>
  <td>None</td>
  <td>
    Vendor of the resources to use for the executors. This option is currently
    only supported on Kubernetes and is actually both the vendor and domain following
    the Kubernetes device plugin naming convention. (e.g. For GPUs on Kubernetes
    this config would be set to nvidia.com or amd.com)
  </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.extraListeners</code></td>
  <td>(none)</td>
  <td>
    A comma-separated list of classes that implement <code>SparkListener</code>; when initializing
    SparkContext, instances of these classes will be created and registered with Spark's listener
    bus.