Maximum heap size settings can be set with spark.executor.memory. The following symbols, if present will be interpolated: {{APP_ID}} will be replaced by
    application ID and {{EXECUTOR_ID}} will be replaced by executor ID. For example, to enable
    verbose gc logging to a file named for the executor ID of the app in /tmp, pass a 'value' of:
    <code>-verbose:gc -Xloggc:/tmp/{{APP_ID}}-{{EXECUTOR_ID}}.gc</code>
  </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.extraJavaOptions</code></td>
  <td>(none)</td>
  <td>
    A string of extra JVM options to pass to executors. This is intended to be set by users. For instance, GC settings or other logging. Note that it is illegal to set Spark properties or maximum heap size (-Xmx) settings with this
    option. Spark properties should be set using a SparkConf object or the spark-defaults.conf file
    used with the spark-submit script. Maximum heap size settings can be set with spark.executor.memory. The following symbols, if present will be interpolated: {{APP_ID}} will be replaced by
    application ID and {{EXECUTOR_ID}} will be replaced by executor ID. For example, to enable
    verbose gc logging to a file named for the executor ID of the app in /tmp, pass a 'value' of:
    <code>-verbose:gc -Xloggc:/tmp/{{APP_ID}}-{{EXECUTOR_ID}}.gc</code>

    <code>spark.executor.defaultJavaOptions</code> will be prepended to this configuration. </td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.extraLibraryPath</code></td>
  <td>(none)</td>
  <td>
    Set a special library path to use when launching executor JVM's. </td>
  <td>1.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.logs.rolling.maxRetainedFiles</code></td>
  <td>-1</td>
  <td>
    Sets the number of latest rolling log files that are going to be retained by the system. Older log files will be deleted. Disabled by default. </td>
  <td>1.1.0</td>
</tr>
<tr>
  <td><code>spark.executor.logs.rolling.enableCompression</code></td>
  <td>false</td>
  <td>
    Enable executor log compression. If it is enabled, the rolled executor logs will be compressed. Disabled by default. </td>
  <td>2.0.2</td>
</tr>
<tr>
  <td><code>spark.executor.logs.rolling.maxSize</code></td>
  <td>1024 * 1024</td>
  <td>
    Set the max size of the file in bytes by which the executor logs will be rolled over. Rolling is disabled by default. See <code>spark.executor.logs.rolling.maxRetainedFiles</code>
    for automatic cleaning of old logs. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.executor.logs.rolling.strategy</code></td>
  <td>"" (disabled)</td>
  <td>
    Set the strategy of rolling of executor logs. By default it is disabled. It can
    be set to "time" (time-based rolling) or "size" (size-based rolling) or "" (disabled). For "time",
    use <code>spark.executor.logs.rolling.time.interval</code> to set the rolling interval.