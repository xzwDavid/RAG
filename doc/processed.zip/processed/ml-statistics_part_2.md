{% include_example java/org/apache/spark/examples/ml/JavaChiSquareTestExample.java %}
</div>

</div>

## Summarizer

We provide vector column summary statistics for `Dataframe` through `Summarizer`. Available metrics are the column-wise max, min, mean, sum, variance, std, and number of nonzeros,
as well as the total count. <div class="codetabs">

<div data-lang="python" markdown="1">
Refer to the [`Summarizer` Python docs](api/python/reference/api/pyspark.ml.stat.Summarizer.html) for details on the API. {% include_example python/ml/summarizer_example.py %}
</div>

<div data-lang="scala" markdown="1">
The following example demonstrates using [`Summarizer`](api/scala/org/apache/spark/ml/stat/Summarizer$.html)
to compute the mean and variance for a vector column of the input dataframe, with and without a weight column. {% include_example scala/org/apache/spark/examples/ml/SummarizerExample.scala %}
</div>

<div data-lang="java" markdown="1">
The following example demonstrates using [`Summarizer`](api/java/org/apache/spark/ml/stat/Summarizer.html)
to compute the mean and variance for a vector column of the input dataframe, with and without a weight column. {% include_example java/org/apache/spark/examples/ml/JavaSummarizerExample.java %}
</div>

</div>
