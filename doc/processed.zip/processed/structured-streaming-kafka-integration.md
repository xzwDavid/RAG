

This page has moved [here](./streaming/structured-streaming-kafka-integration.html). 