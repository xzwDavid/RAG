</td>
  <td>1.3.0</td>
</tr>
<tr>
  <td><code>spark.jars.ivySettings</code></td>
  <td></td>
  <td>
    Path to an Ivy settings file to customize resolution of jars specified using <code>spark.jars.packages</code>
    instead of the built-in defaults, such as maven central. Additional repositories given by the command-line
    option <code>--repositories</code> or <code>spark.jars.repositories</code> will also be included. Useful for allowing Spark to resolve artifacts from behind a firewall e.g. via an in-house
    artifact server like Artifactory. Details on the settings file format can be
    found at <a href="http://ant.apache.org/ivy/history/latest-milestone/settings.html">Settings Files</a>. Only paths with <code>file://</code> scheme are supported. Paths without a scheme are assumed to have
    a <code>file://</code> scheme. <p/>
    When running in YARN cluster mode, this file will also be localized to the remote driver for dependency
    resolution within <code>SparkContext#addJar</code>
  </td>
  <td>2.2.0</td>
</tr>
 <tr>
  <td><code>spark.jars.repositories</code></td>
  <td></td>
  <td>
    Comma-separated list of additional remote repositories to search for the maven coordinates
    given with <code>--packages</code> or <code>spark.jars.packages</code>. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.archives</code></td>
  <td></td>
  <td>
    Comma-separated list of archives to be extracted into the working directory of each executor. .jar, .tar.gz, .tgz and .zip are supported. You can specify the directory name to unpack via
    adding <code>#</code> after the file name to unpack, for example, <code>file.zip#directory</code>. This configuration is experimental. </td>
  <td>3.1.0</td>
</tr>
<tr>
  <td><code>spark.pyspark.driver.python</code></td>
  <td></td>
  <td>
    Python binary executable to use for PySpark in driver. (default is <code>spark.pyspark.python</code>)
  </td>
  <td>2.1.0</td>
</tr>
<tr>
  <td><code>spark.pyspark.python</code></td>
  <td></td>
  <td>
    Python binary executable to use for PySpark in both driver and executors. </td>
  <td>2.1.0</td>
</tr>
</table>

### Shuffle Behavior

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.reducer.maxSizeInFlight</code></td>
  <td>48m</td>
  <td>
    Maximum size of map outputs to fetch simultaneously from each reduce task, in MiB unless
    otherwise specified. Since each output requires us to create a buffer to receive it, this
    represents a fixed memory overhead per reduce task, so keep it small unless you have a
    large amount of memory. </td>
  <td>1.4.0</td>
</tr>
<tr>
  <td><code>spark.reducer.maxReqsInFlight</code></td>
  <td>Int.MaxValue</td>
  <td>
    This configuration limits the number of remote requests to fetch blocks at any given point.