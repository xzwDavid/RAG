

This page documents sections of the migration guide for each component in order
for users to migrate effectively. * [Spark Core](core-migration-guide.html)
* [SQL, Datasets, and DataFrame](sql-migration-guide.html)
* [Structured Streaming](./streaming/ss-migration-guide.html)
* [MLlib (Machine Learning)](ml-migration-guide.html)
* [PySpark (Python on Spark)](pyspark-migration-guide.html)
* [SparkR (R on Spark)](sparkr-migration-guide.html)
