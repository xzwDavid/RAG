

### Description

An inline table is a temporary table created using a VALUES clause. ### Syntax

```sql
VALUES ( expression [ , ... ] ) [ table_alias ]
```

### Parameters

* **expression**

    Specifies a combination of one or more values, operators and SQL functions that results in a value. * **table_alias**

    Specifies a temporary name with an optional column name list. **Syntax:** `[ AS ] table_name [ ( column_name [ , ... ] ) ]`

### Examples

```sql
-- single row, without a table alias
SELECT * FROM VALUES ("one", 1);
+