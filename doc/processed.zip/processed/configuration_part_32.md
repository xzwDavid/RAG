</td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.storage.decommission.shuffleBlocks.maxDiskSize</code></td>
  <td>(none)</td>
  <td>
    Maximum disk space to use to store shuffle blocks before rejecting remote shuffle blocks. Rejecting remote shuffle blocks means that an executor will not receive any shuffle migrations,
    and if there are no other executors available for migration then shuffle blocks will be lost unless
    <code>spark.storage.decommission.fallbackStorage.path</code> is configured. </td>
  <td>3.2.0</td>
</tr>
<tr>
  <td><code>spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version</code></td>
  <td>1</td>
  <td>
    The file output committer algorithm version, valid algorithm version number: 1 or 2. Note that 2 may cause a correctness issue like MAPREDUCE-7282. </td>
  <td>2.2.0</td>
</tr>
</table>

### Executor Metrics

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.eventLog.logStageExecutorMetrics</code></td>
  <td>false</td>
  <td>
    Whether to write per-stage peaks of executor metrics (for each executor) to the event log. <br />
    <em>Note:</em> The metrics are polled (collected) and sent in the executor heartbeat,
    and this is always done; this configuration is only to determine if aggregated metric peaks
    are written to the event log. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.processTreeMetrics.enabled</code></td>
  <td>false</td>
  <td>
    Whether to collect process tree metrics (from the /proc filesystem) when collecting
    executor metrics. <br />
    <em>Note:</em> The process tree metrics are collected only if the /proc filesystem
    exists. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.executor.metrics.pollingInterval</code></td>
  <td>0</td>
  <td>
    How often to collect executor metrics (in milliseconds). <br />
    If 0, the polling is done on executor heartbeats (thus at the heartbeat interval,
    specified by <code>spark.executor.heartbeatInterval</code>). If positive, the polling is done at this interval. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.eventLog.gcMetrics.youngGenerationGarbageCollectors</code></td>
  <td>Copy,PS Scavenge,ParNew,G1 Young Generation</td>
  <td>
    Names of supported young generation garbage collector. A name usually is the return of GarbageCollectorMXBean.getName. The built-in young generation garbage collectors are Copy,PS Scavenge,ParNew,G1 Young Generation. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.eventLog.gcMetrics.oldGenerationGarbageCollectors</code></td>
  <td>MarkSweepCompact,PS MarkSweep,ConcurrentMarkSweep,G1 Old Generation</td>
  <td>
    Names of supported old generation garbage collector. A name usually is the return of GarbageCollectorMXBean.getName. The built-in old generation garbage collectors are MarkSweepCompact,PS MarkSweep,ConcurrentMarkSweep,G1 Old Generation.