BlockMatrix ata = matA.transpose().multiply(matA);
{% endhighlight %}
</div>

</div>
