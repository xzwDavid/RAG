<p style="text-align: center;">
          <img src="img/streaming-kinesis-arch.png"
               title="Spark Streaming Kinesis Architecture"
               alt="Spark Streaming Kinesis Architecture"
           width="60%"
        />
    </p>

    *Points to remember at runtime:*

    - Kinesis data processing is ordered per partition and occurs at-least once per message. - Multiple applications can read from the same Kinesis stream. Kinesis will maintain the application-specific shard and checkpoint info in DynamoDB. - A single Kinesis stream shard is processed by one input DStream at a time. - A single Kinesis input DStream can read from multiple shards of a Kinesis stream by creating multiple KinesisRecordProcessor threads. - Multiple input DStreams running in separate processes/instances can read from a Kinesis stream. - You never need more Kinesis input DStreams than the number of Kinesis stream shards as each input DStream will create at least one KinesisRecordProcessor thread that handles a single shard. - Horizontal scaling is achieved by adding/removing  Kinesis input DStreams (within a single process or across multiple processes/instances) - up to the total number of Kinesis stream shards per the previous point. - The Kinesis input DStream will balance the load between all DStreams - even across processes/instances. - The Kinesis input DStream will balance the load during re-shard events (merging and splitting) due to changes in load. - As a best practice, it's recommended that you avoid re-shard jitter by over-provisioning when possible. - Each Kinesis input DStream maintains its own checkpoint info. See the Kinesis Checkpointing section for more details. - There is no correlation between the number of Kinesis stream shards and the number of RDD partitions/shards created across the Spark cluster during input DStream processing. These are 2 independent partitioning schemes. #### Running the Example
To run the example,

- Download a Spark binary from the [download site](https://spark.apache.org/downloads.html). - Set up Kinesis stream (see earlier section) within AWS. Note the name of the Kinesis stream and the endpoint URL corresponding to the region where the stream was created. - Set up the environment variables `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` with your AWS credentials.