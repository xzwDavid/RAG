

### Description

`DESCRIBE FUNCTION` statement returns the basic metadata information of an
existing function. The metadata information includes the function name, implementing
class and the usage details. If the optional `EXTENDED` option is specified, the basic
metadata information is returned along with the extended usage information. ### Syntax

```sql
{ DESC | DESCRIBE } FUNCTION [ EXTENDED ] function_name
```

### Parameters

* **function_name**

    Specifies a name of an existing function in the system. The function name may be
    optionally qualified with a database name. If `function_name` is qualified with
    a database then the function is resolved from the user specified database, otherwise
    it is resolved from the current database. **Syntax:** `[ database_name. ] function_name`

### Examples

```sql
-- Describe a builtin scalar function. -- Returns function name, implementing class and usage
DESC FUNCTION abs;
+