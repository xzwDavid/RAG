

Spark SQL is Apache Spark's module for working with structured data. The SQL Syntax section describes the SQL syntax in detail along with usage examples when applicable. This document provides a list of Data Definition and Data Manipulation Statements, as well as Data Retrieval and Auxiliary Statements. ### DDL Statements

Data Definition Statements are used to create or modify the structure of database objects in a database. Spark SQL supports the following Data Definition Statements:

 * [ALTER DATABASE](sql-ref-syntax-ddl-alter-database.html)
 * [ALTER TABLE](sql-ref-syntax-ddl-alter-table.html)
 * [ALTER VIEW](sql-ref-syntax-ddl-alter-view.html)
 * [CREATE DATABASE](sql-ref-syntax-ddl-create-database.html)
 * [CREATE FUNCTION](sql-ref-syntax-ddl-create-function.html)
 * [CREATE TABLE](sql-ref-syntax-ddl-create-table.html)
 * [CREATE VIEW](sql-ref-syntax-ddl-create-view.html)
 * [DECLARE VARIABLE](sql-ref-syntax-ddl-declare-variable.html)
 * [DROP DATABASE](sql-ref-syntax-ddl-drop-database.html)
 * [DROP FUNCTION](sql-ref-syntax-ddl-drop-function.html)
 * [DROP TABLE](sql-ref-syntax-ddl-drop-table.html)
 * [DROP TEMPORARY VARIABLE](sql-ref-syntax-ddl-drop-variable.html)
 * [DROP VIEW](sql-ref-syntax-ddl-drop-view.html)
 * [REPAIR TABLE](sql-ref-syntax-ddl-repair-table.html)
 * [TRUNCATE TABLE](sql-ref-syntax-ddl-truncate-table.html)
 * [USE DATABASE](sql-ref-syntax-ddl-usedb.html)

### DML Statements

Data Manipulation Statements are used to add, change, or delete data. Spark SQL supports the following Data Manipulation Statements:

 * [INSERT TABLE](sql-ref-syntax-dml-insert-table.html)
 * [INSERT OVERWRITE DIRECTORY](sql-ref-syntax-dml-insert-overwrite-directory.html)
 * [LOAD](sql-ref-syntax-dml-load.html)

### Data Retrieval Statements

Spark supports <code>SELECT</code> statement that is used to retrieve rows
from one or more tables according to the specified clauses. The full syntax
and brief description of supported clauses are explained in
[SELECT](sql-ref-syntax-qry-select.html) section. The SQL statements related
to SELECT are also included in this section. Spark also provides the
ability to generate logical and physical plan for a given query using
[EXPLAIN](sql-ref-syntax-qry-explain.html) statement.