

### Description

`DESCRIBE TABLE` statement returns the basic metadata information of a
table. The metadata information includes column name, column type
and column comment. Optionally a partition spec or column name may be specified
to return the metadata pertaining to a partition or column respectively. ### Syntax

```sql
{ DESC | DESCRIBE } [ TABLE ] [ format ] table_identifier [ partition_spec ] [ col_name ]
```

### Parameters

* **format**

    Specifies the optional format of describe output. If `EXTENDED` is specified
    then additional metadata information (such as parent database, owner, and access time)
    is returned. * **table_identifier**

    Specifies a table name, which may be optionally qualified with a database name. **Syntax:** `[ database_name. ] table_name`

* **partition_spec**

    An optional parameter that specifies a comma separated list of key and value pairs
    for partitions. When specified, additional partition metadata is returned. **Syntax:** `PARTITION ( partition_col_name  = partition_col_val [ , ... ] )`

* **col_name**

    An optional parameter that specifies the column name that needs to be described. The supplied column name may be optionally qualified. Parameters `partition_spec`
    and `col_name` are  mutually exclusive and can not be specified together. Currently
    nested columns are not allowed to be specified. **Syntax:** `[ database_name. ] [ table_name. ] column_name`

### Examples

```sql
-- Creates a table `customer`. Assumes current database is `salesdb`. CREATE TABLE customer(
        cust_id INT,
        state VARCHAR(20),
        name STRING COMMENT 'Short name'
    )
    USING parquet
    PARTITIONED BY (state);
    
INSERT INTO customer PARTITION (state = 'AR') VALUES (100, 'Mike');
    
-- Returns basic metadata information for unqualified table `customer`
DESCRIBE TABLE customer;
+