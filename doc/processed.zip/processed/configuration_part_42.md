The check can fail in case
    a cluster has just started and not enough executors have registered, so we wait for a
    little while and try to perform the check again. If the check fails more than a
    configured max failure times for a job then fail current job submission. Note this
    config only applies to jobs that contain one or more barrier stages, we won't perform
    the check on non-barrier jobs. </td>
  <td>2.4.0</td>
</tr>
<tr>
  <td><code>spark.scheduler.barrier.maxConcurrentTasksCheck.maxFailures</code></td>
  <td>40</td>
  <td>
    Number of max concurrent tasks check failures allowed before fail a job submission. A max concurrent tasks check ensures the cluster can launch more concurrent tasks than
    required by a barrier stage on job submitted. The check can fail in case a cluster
    has just started and not enough executors have registered, so we wait for a little
    while and try to perform the check again. If the check fails more than a configured
    max failure times for a job then fail current job submission. Note this config only
    applies to jobs that contain one or more barrier stages, we won't perform the check on
    non-barrier jobs. </td>
  <td>2.4.0</td>
</tr>
</table>

### Dynamic Allocation

<table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.dynamicAllocation.enabled</code></td>
  <td>false</td>
  <td>
    Whether to use dynamic resource allocation, which scales the number of executors registered
    with this application up and down based on the workload. For more detail, see the description
    <a href="job-scheduling.html#dynamic-resource-allocation">here</a>. <br><br>
    This requires one of the following conditions: 
    1) enabling external shuffle service through <code>spark.shuffle.service.enabled</code>, or
    2) enabling shuffle tracking through <code>spark.dynamicAllocation.shuffleTracking.enabled</code>, or
    3) enabling shuffle blocks decommission through <code>spark.decommission.enabled</code> and <code>spark.storage.decommission.shuffleBlocks.enabled</code>, or
    4) (Experimental) configuring <code>spark.shuffle.sort.io.plugin.class</code> to use a custom <code>ShuffleDataIO</code> who's <code>ShuffleDriverComponents</code> supports reliable storage. The following configurations are also relevant:
    <code>spark.dynamicAllocation.minExecutors</code>,
    <code>spark.dynamicAllocation.maxExecutors</code>, and
    <code>spark.dynamicAllocation.initialExecutors</code>
    <code>spark.dynamicAllocation.executorAllocationRatio</code>
  </td>
  <td>1.2.0</td>
</tr>
<tr>
  <td><code>spark.dynamicAllocation.executorIdleTimeout</code></td>
  <td>60s</td>
  <td>
    If dynamic allocation is enabled and an executor has been idle for more than this duration,
    the executor will be removed. For more detail, see this
    <a href="job-scheduling.html#resource-allocation-policy">description</a>.