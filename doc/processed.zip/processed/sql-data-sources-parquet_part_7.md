This will override <code>spark.sql.parquet.compression.codec</code>.</td>
    <td>write</td>
  </tr>
</table>
Other generic options can be found in <a href="https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html"> Generic Files Source Options</a>

### Configuration

Configuration of Parquet can be done via `spark.conf.set` or by running
`SET key=value` commands using SQL. <table class="spark-config">
<thead><tr><th>Property Name</th><th>Default</th><th>Meaning</th><th>Since Version</th></tr></thead>
<tr>
  <td><code>spark.sql.parquet.binaryAsString</code></td>
  <td>false</td>
  <td>
    Some other Parquet-producing systems, in particular Impala, Hive, and older versions of Spark SQL, do
    not differentiate between binary data and strings when writing out the Parquet schema. This
    flag tells Spark SQL to interpret binary data as a string to provide compatibility with these systems. </td>
  <td>1.1.1</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.int96AsTimestamp</code></td>
  <td>true</td>
  <td>
    Some Parquet-producing systems, in particular Impala and Hive, store Timestamp into INT96. This
    flag tells Spark SQL to interpret INT96 data as a timestamp to provide compatibility with these systems. </td>
  <td>1.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.int96TimestampConversion</code></td>
  <td>false</td>
  <td>
    This controls whether timestamp adjustments should be applied to INT96 data when
    converting to timestamps, for data written by Impala. This is necessary because Impala
    stores INT96 data with a different timezone offset than Hive & Spark. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.outputTimestampType</code></td>
  <td>INT96</td>
  <td>
    Sets which Parquet timestamp type to use when Spark writes data to Parquet files. INT96 is a non-standard but commonly used timestamp type in Parquet. TIMESTAMP_MICROS
    is a standard timestamp type in Parquet, which stores number of microseconds from the
    Unix epoch. TIMESTAMP_MILLIS is also standard, but with millisecond precision, which
    means Spark has to truncate the microsecond portion of its timestamp value. </td>
  <td>2.3.0</td>
</tr>
<tr>
  <td><code>spark.sql.parquet.compression.codec</code></td>
  <td>snappy</td>
  <td>
    Sets the compression codec used when writing Parquet files. If either <code>compression</code> or
    <code>parquet.compression</code> is specified in the table-specific options/properties, the precedence would be
    <code>compression</code>, <code>parquet.compression</code>, <code>spark.sql.parquet.compression.codec</code>. Acceptable values include:
    none, uncompressed, snappy, gzip, lzo, brotli, lz4, lz4_raw, zstd. Note that <code>brotli</code> requires <code>BrotliCodec</code> to be installed.