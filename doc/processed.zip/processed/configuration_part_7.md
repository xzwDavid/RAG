</td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.driver.log.localDir</code></td>
  <td>(none)</td>
  <td>
    Specifies a local directory to write driver logs and enable Driver Log UI Tab. </td>
  <td>4.0.0</td>
</tr>
<tr>
  <td><code>spark.driver.log.dfsDir</code></td>
  <td>(none)</td>
  <td>
    Base directory in which Spark driver logs are synced, if <code>spark.driver.log.persistToDfs.enabled</code>
    is true. Within this base directory, each application logs the driver logs to an application specific file. Users may want to set this to a unified location like an HDFS directory so driver log files can be persisted
    for later usage. This directory should allow any Spark user to read/write files and the Spark History Server
    user to delete files. Additionally, older logs from this directory are cleaned by the
    <a href="monitoring.html#spark-history-server-configuration-options">Spark History Server</a> if
    <code>spark.history.fs.driverlog.cleaner.enabled</code> is true and, if they are older than max age configured
    by setting <code>spark.history.fs.driverlog.cleaner.maxAge</code>. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.driver.log.persistToDfs.enabled</code></td>
  <td>false</td>
  <td>
    If true, spark application running in client mode will write driver logs to a persistent storage, configured
    in <code>spark.driver.log.dfsDir</code>. If <code>spark.driver.log.dfsDir</code> is not configured, driver logs
    will not be persisted. Additionally, enable the cleaner by setting <code>spark.history.fs.driverlog.cleaner.enabled</code>
    to true in <a href="monitoring.html#spark-history-server-configuration-options">Spark History Server</a>. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.driver.log.layout</code></td>
  <td>%d{yy/MM/dd HH:mm:ss.SSS} %t %p %c{1}: %m%n%ex</td>
  <td>
    The layout for the driver logs that are synced to <code>spark.driver.log.localDir</code> and <code>spark.driver.log.dfsDir</code>. If this is not configured,
    it uses the layout for the first appender defined in log4j2.properties. If that is also not configured, driver logs
    use the default layout. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.driver.log.allowErasureCoding</code></td>
  <td>false</td>
  <td>
    Whether to allow driver logs to use erasure coding. On HDFS, erasure coded files will not
    update as quickly as regular replicated files, so they make take longer to reflect changes
    written by the application. Note that even if this is true, Spark will still not force the
    file to use erasure coding, it will simply use file system defaults. </td>
  <td>3.0.0</td>
</tr>
<tr>
  <td><code>spark.decommission.enabled</code></td>
  <td>false</td>
  <td>
    When decommission enabled, Spark will try its best to shut down the executor gracefully.