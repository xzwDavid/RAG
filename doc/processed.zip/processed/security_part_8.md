</td>
    <td>ui,standalone,historyServer,rpc</td>
  </tr>
  <tr>
    <td><code>${ns}.keyStorePassword</code></td>
    <td>None</td>
    <td>Password to the key store.</td>
    <td>ui,standalone,historyServer,rpc</td>
  </tr>
  <tr>
    <td><code>${ns}.keyStoreType</code></td>
    <td>JKS</td>
    <td>The type of the key store.</td>
    <td>ui,standalone,historyServer</td>
  </tr>
  <tr>
    <td><code>${ns}.protocol</code></td>
    <td>None</td>
    <td>
      TLS protocol to use. The protocol must be supported by JVM. <br />The reference list of protocols can be found in the "Additional JSSE Standard Names"
      section of the Java security guide. For Java 17, the list can be found at
      <a href="https://docs.oracle.com/en/java/javase/17/docs/specs/security/standard-names.html#additional-jsse-standard-names">this</a>
      page. </td>
    <td>ui,standalone,historyServer,rpc</td>
  </tr>
  <tr>
    <td><code>${ns}.needClientAuth</code></td>
    <td>false</td>
    <td>
      Whether to require client authentication. </td>
    <td>ui,standalone,historyServer</td>
  </tr>
  <tr>
    <td><code>${ns}.trustStore</code></td>
    <td>None</td>
    <td>
      Path to the trust store file. The path can be absolute or relative to the directory in which
      the process is started. </td>
    <td>ui,standalone,historyServer,rpc</td>
  </tr>
  <tr>
    <td><code>${ns}.trustStorePassword</code></td>
    <td>None</td>
    <td>Password for the trust store.</td>
    <td>ui,standalone,historyServer,rpc</td>
  </tr>
  <tr>
    <td><code>${ns}.trustStoreType</code></td>
    <td>JKS</td>
    <td>The type of the trust store.</td>
    <td>ui,standalone,historyServer</td>
  </tr>
  <tr>
    <td><code>${ns}.openSSLEnabled</code></td>
    <td>false</td>
    <td>
      Whether to use OpenSSL for cryptographic operations instead of the JDK SSL provider. This setting requires the `certChain` and `privateKey` settings to be set. This takes precedence over the `keyStore` and `trustStore` settings if both are specified. If the OpenSSL library is not available at runtime, we will fall back to the JDK provider. </td>
    <td>rpc</td>
  </tr>
  <tr>
    <td><code>${ns}.privateKey</code></td>
    <td>None</td>
    <td>
      Path to the private key file in PEM format. The path can be absolute or relative to the 
      directory in which the process is started. This setting is required when using the OpenSSL implementation.