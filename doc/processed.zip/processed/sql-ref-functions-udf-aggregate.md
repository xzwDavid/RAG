

### Description

User-Defined Aggregate Functions (UDAFs) are user-programmable routines that act on multiple rows at once and return a single aggregated value as a result. This documentation lists the classes that are required for creating and registering UDAFs. It also contains examples that demonstrate how to define and register UDAFs in Scala and invoke them in Spark SQL. ### Aggregator[-IN, BUF, OUT]

A base class for user-defined aggregations, which can be used in Dataset operations to take all of the elements of a group and reduce them to a single value. ***IN*** - The input type for the aggregation. ***BUF*** - The type of the intermediate value of the reduction. ***OUT*** - The type of the final output result. * **bufferEncoder: Encoder[BUF]**

    Specifies the Encoder for the intermediate value type. * **finish(reduction: BUF): OUT**

    Transform the output of the reduction. * **merge(b1: BUF, b2: BUF): BUF**

    Merge two intermediate values. * **outputEncoder: Encoder[OUT]**

    Specifies the Encoder for the final output value type. * **reduce(b: BUF, a: IN): BUF**

     Aggregate input value `a` into current intermediate value. For performance, the function may modify `b` and return it instead of constructing new object for `b`. * **zero: BUF**

    The initial value of the intermediate result for this aggregation. ### Examples

#### Type-Safe User-Defined Aggregate Functions

User-defined aggregations for strongly typed Datasets revolve around the [Aggregator](api/scala/org/apache/spark/sql/expressions/Aggregator.html) abstract class. For example, a type-safe user-defined average can look like:
<div class="codetabs">
<div data-lang="scala"  markdown="1">
  {% include_example typed_custom_aggregation scala/org/apache/spark/examples/sql/UserDefinedTypedAggregation.scala%}
</div>
<div data-lang="java"  markdown="1">
  {% include_example typed_custom_aggregation java/org/apache/spark/examples/sql/JavaUserDefinedTypedAggregation.java%}
</div>
</div>

#### Untyped User-Defined Aggregate Functions

Typed aggregations, as described above, may also be registered as untyped aggregating UDFs for use with DataFrames. For example, a user-defined average for untyped DataFrames can look like:
<div class="codetabs">
<div data-lang="scala"  markdown="1">
  {% include_example untyped_custom_aggregation scala/org/apache/spark/examples/sql/UserDefinedUntypedAggregation.scala%}
</div>
<div data-lang="java"  markdown="1">
  {% include_example untyped_custom_aggregation java/org/apache/spark/examples/sql/JavaUserDefinedUntypedAggregation.java%}
</div>
<div data-lang="SQL"  markdown="1">
```sql
-- Compile and place UDAF MyAverage in a JAR file called `MyAverage.jar` in /tmp. CREATE FUNCTION myAverage AS 'MyAverage' USING JAR '/tmp/MyAverage.jar';

SHOW USER FUNCTIONS;
+