This also supports multiple <code>taskStatus</code> such as <code>?details=true&taskStatus=SUCCESS&taskStatus=FAILED</code> which will return all tasks matching any of specified task status. <br><code>?withSummaries=true</code> lists task metrics distribution and executor metrics distribution of each attempt. <br><code>?quantiles=0.0,0.25,0.5,0.75,1.0</code> summarize the metrics with the given quantiles. Query parameter quantiles takes effect only when <code>withSummaries=true</code>. Default value is <code>0.0,0.25,0.5,0.75,1.0</code>. <br>Example:
        <br><code>?details=true</code>
        <br><code>?details=true&taskStatus=RUNNING</code>
        <br><code>?withSummaries=true</code>
        <br><code>?details=true&withSummaries=true&quantiles=0.01,0.5,0.99</code>
    </td>
  </tr>
  <tr>
    <td><code>/applications/[app-id]/stages/[stage-id]/[stage-attempt-id]</code></td>
    <td>
      Details for the given stage attempt. <br><code>?details=true</code> lists all task data for the given stage attempt. <br><code>?taskStatus=[RUNNING|SUCCESS|FAILED|KILLED|PENDING]</code> lists only those tasks with the specified task status. Query parameter taskStatus takes effect only when <code>details=true</code>. This also supports multiple <code>taskStatus</code> such as <code>?details=true&taskStatus=SUCCESS&taskStatus=FAILED</code> which will return all tasks matching any of specified task status. <br><code>?withSummaries=true</code> lists task metrics distribution and executor metrics distribution for the given stage attempt. <br><code>?quantiles=0.0,0.25,0.5,0.75,1.0</code> summarize the metrics with the given quantiles. Query parameter quantiles takes effect only when <code>withSummaries=true</code>. Default value is <code>0.0,0.25,0.5,0.75,1.0</code>. <br>Example:
        <br><code>?details=true</code>
        <br><code>?details=true&taskStatus=RUNNING</code>
        <br><code>?withSummaries=true</code>
        <br><code>?details=true&withSummaries=true&quantiles=0.01,0.5,0.99</code>
    </td>
  </tr>
  <tr>
    <td><code>/applications/[app-id]/stages/[stage-id]/[stage-attempt-id]/taskSummary</code></td>
    <td>
      Summary metrics of all tasks in the given stage attempt. <br><code>?quantiles</code> summarize the metrics with the given quantiles. <br>Example: <code>?quantiles=0.01,0.5,0.99</code>
    </td>
  </tr>
  <tr>
    <td><code>/applications/[app-id]/stages/[stage-id]/[stage-attempt-id]/taskList</code></td>
    <td>
       A list of all tasks for the given stage attempt. <br><code>?offset=[offset]&amp;length=[len]</code> list tasks in the given range. <br><code>?sortBy=[runtime|-runtime]</code> sort the tasks. <br><code>?status=[running|success|killed|failed|unknown]</code> list only tasks in the state.